package cocheck;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Extracter {
   public static void main(String[] args) throws FileNotFoundException {
      Scanner reader = new Scanner(new FileInputStream("/media/MOHSENHD/1.Works/3.Research/0.Topics/1.Project/2.Atomicity/SVN/atomicity/Project/polyglot-2.5.1-src/COCheck/tests/src/Benchmarks.txt"));

      while (reader.hasNextLine()) {
         String s = reader.nextLine();
         if (s.contains("Example") || s.contains("Result:"))
         System.out.println(s);
      }
   }
}
