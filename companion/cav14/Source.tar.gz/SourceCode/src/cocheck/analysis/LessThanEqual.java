package cocheck.analysis;

public class LessThanEqual extends BinaryExp {

   public LessThanEqual(Exp operand1, Exp operand2) {
      super(operand1, operand2);
   }

   @Override
   public String operator() {
      return "<=";
   }

   @Override
   public <T> T accept(ExpVisitor.BinaryExpVisitor<T> visitor) {
      return visitor.visit(this);
      //needed to add the visit function in the declaration of visit for new classes
   }
}