package cocheck.analysis;

public interface ExpVisitor<T> {
   public T visit(Val val);

   public interface ValVisitor<T1> {
      public T1 visit(IntVal intVal);
      public T1 visit(BoolVal boolVal);
      public T1 visit(NullVal boolVal);
      //=== is this legal?
      public T1 visit(StringVal stringVal);
   }
   public T visit(Var var);
   public T visit(BinaryExp binaryExp);
   public interface BinaryExpVisitor<T1> {
      public T1 visit(Plus plus);
      public T1 visit(Minus minus);
      public T1 visit(Equality equality);
      public T1 visit(Inequality inequality);
      public T1 visit(LessThan lt);
      public T1 visit(LessThanEqual lte);
      public T1 visit(GreaterThan gt);
      public T1 visit(GreaterThanEqual gte);
   }
   public T visit(UMinus uMinus);

   public T visit(And and);
   public T visit(Or or);
   public T visit(Not not);
   public T visit(CallExp callExp);
}
