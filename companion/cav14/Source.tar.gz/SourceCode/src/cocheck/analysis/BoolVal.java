package cocheck.analysis;

public class BoolVal extends Val {
   public BoolVal(String boolVal) {
      super(boolVal);
   }

   @Override
   public String toString() {
      return val;
   }

   @Override
   public <T> T accept(ExpVisitor.ValVisitor<T> valVisitor) {
      return valVisitor.visit(this);
   }

}
