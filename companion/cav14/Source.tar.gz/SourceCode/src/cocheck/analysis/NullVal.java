package cocheck.analysis;

public class NullVal extends Val {
   public NullVal() {
      super("null");
   }

   @Override
   public String toString() {
      return "null";
   }

   @Override
   public <T> T accept(ExpVisitor.ValVisitor<T> valVisitor) {
      return valVisitor.visit(this);
   }

}
