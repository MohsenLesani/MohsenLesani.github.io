package cocheck.analysis;

public class StringVal extends Val {
   public StringVal(String stringVal) {
      super(stringVal);
   }

   @Override
   public String toString() {
      return val;
   }

   @Override
   public <T> T accept(ExpVisitor.ValVisitor<T> valVisitor) {
      return valVisitor.visit(this);
   }

}
