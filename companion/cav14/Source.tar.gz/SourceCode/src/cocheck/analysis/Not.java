package cocheck.analysis;

public class Not implements Exp {
   public Exp exp;

   public Not(Exp exp) {
      this.exp = exp;
   }

   public <T> T accept(ExpVisitor<T> expVisitor) {
      return expVisitor.visit(this);
   }

   @Override
   public String toString() {
      return "!(" + exp + ")";
   }
}
