package cocheck.analysis;

public class IntVal extends Val {
   public IntVal(String intVal) {
      super(intVal);
   }

   @Override
   public String toString() {
      return val;
   }

   @Override
   public <T> T accept(ExpVisitor.ValVisitor<T> valVisitor) {
      return valVisitor.visit(this);
   }
}
