package cocheck.analysis.step;


import cocheck.analysis.BinaryExp;
import cocheck.analysis.Exp;
import cocheck.analysis.Var;

public class Assignment implements Step {
   public Var left;
   public Exp right;

   public Assignment(Var left, Exp right) {
      this.left = left;
      this.right = right;
   }

   @Override
   public String toString() {
      return left + " = " + right;
   }
}
