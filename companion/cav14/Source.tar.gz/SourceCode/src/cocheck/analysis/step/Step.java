package cocheck.analysis.step;

public interface Step {
}
