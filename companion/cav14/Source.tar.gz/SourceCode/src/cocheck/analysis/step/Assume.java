package cocheck.analysis.step;


import cocheck.analysis.BinaryExp;
import cocheck.analysis.Exp;
import cocheck.analysis.Var;

public class Assume implements Step {
   public Exp exp;

   public Assume(Exp exp) {
      this.exp = exp;
   }

   @Override
   public String toString() {
      return "assume(" + exp + ")";
   }
}
