package cocheck.analysis.step;


import cocheck.analysis.*;

public class MethodCall implements Step {
   public Var receiver;
   public String name;
   public Varl[] args;
   public Var ret;

   public MethodCall(Var receiver, String name, Varl[] args, Var ret) {
      this.receiver = receiver;
      this.name = name;
      this.args = args;
      this.ret = ret;
   }

   public MethodCall(String receiver, String name, String[] args, String ret) {
      this.receiver = new Var(receiver);
      this.name = name;
      this.args = new Varl[args.length];
      for (int i = 0; i < args.length; i++) {
         String arg = args[i];
         if (arg.equals("null"))
            this.args[i] = new NullVal();
         if (isInt(arg))
            this.args[i] = new IntVal(arg);
         else if (isBool(arg))
            this.args[i] = new BoolVal(arg);
         else
            this.args[i] = new Var(arg);
      }
      this.ret = new Var(ret);
   }

   private boolean isInt(String s) {
      try {
         Integer.parseInt(s);
         return true;
      } catch (NumberFormatException e) {
         return false;
      }
   }

   private boolean isBool(String s) {
      return s.equals("true") || s.equals("false");
   }

   @Override
   public String toString() {
      String s = ret + " = " + receiver + "." + name + "(";
      for (int i = 0; i < args.length; i++) {
         String arg = args[i].toString();
         s += arg;
         if (i != args.length - 1)
            s += ", ";
      }
      s += ")";
      return s;
   }
}
