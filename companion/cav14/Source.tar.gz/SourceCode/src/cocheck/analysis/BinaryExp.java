package cocheck.analysis;

public abstract class BinaryExp implements Exp {
   public Exp operand1;
   public Exp operand2;

   public BinaryExp(Exp operand1, Exp operand2) {
      this.operand1 = operand1;
      this.operand2 = operand2;
   }

   public abstract String operator();

   @Override
   public String toString() {
      return operand1 + " " + operator() + " " + operand2;
   }

   public <T> T accept(ExpVisitor<T> expVisitor) {
      return expVisitor.visit(this);
   }

   public abstract <T> T accept(ExpVisitor.BinaryExpVisitor<T> visitor);

}
