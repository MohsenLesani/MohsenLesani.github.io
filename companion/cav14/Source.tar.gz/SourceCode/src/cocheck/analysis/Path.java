package cocheck.analysis;

import cocheck.analysis.step.Assignment;
import cocheck.analysis.step.Assume;
import cocheck.analysis.step.MethodCall;
import cocheck.analysis.step.Step;
import fj.F;
import fj.F2;
import fj.data.List;
import fj.data.Option;

import java.util.*;

public class Path {

//   public List<MethodCall> methodCalls;
//   public List<Assignment> expSts;
   private List<Step> steps = List.nil();
   private Option<Varl> retV = Option.none();
   private boolean isBreakPath = false;
   private boolean isContinuePath = false;

   public Path() {}

   public Path(List<Step> steps, Option<Varl> retV, boolean breakPath, boolean continuePath) {
      this.steps = steps;
      this.retV = retV;
      isBreakPath = breakPath;
      isContinuePath = continuePath;
   }

   public Path(List<Step> steps, Varl retV) {
      this.steps = steps;
      this.retV = Option.some(retV);
   }
   public Path(List<Step> steps, String retV) {
      this.steps = steps;
      this.retV = Option.<Varl>some(new Var(retV));
   }

   public Path(List<Step> steps) {
      this.steps = steps;
   }

   public Path(Step step) {
      this.steps = List.nil();
      this.steps = this.steps().cons(step);
   }

   public Path(Varl retV) {
      this.retV = Option.some(retV);
   }

   public List<Step> steps() {
      return steps;
   }

   public void setSteps(List<Step> steps) {
      this.steps = steps;
   }

   public Option<Varl> retV() {
      return retV;
   }

   public void setRetV(Option<Varl> retV) {
      this.retV = retV;
   }
   public void setRetV(Var retV) {
      this.retV = Option.<Varl>some(retV);
   }

   public boolean isReturnPath() {
      return retV.isSome();
   }

   public boolean isBreakPath() {
      return isBreakPath;
   }

   public void setBreakPath() {
      isBreakPath = true;
   }

   public boolean isContinuePath() {
      return isContinuePath;
   }

   public void setContinuePath() {
      isContinuePath = true;
   }

   public boolean isNormalPath() {
      return !isContinuePath && !isBreakPath && !isReturnPath();
   }

   static class Counter {
      Map<String, Integer> map = new HashMap<String, Integer>();
      public String add(String s) {
         Integer counter = map.get(s);
         if (counter == null) {
            map.put(s, 0);
         } else {
            map.put(s, counter + 1);
         }
         return get(s);
      }
      public String get(String s) {
         Integer counter = map.get(s);
         if (counter == null || counter == 0) {
            return "";
         } else {
            return String.valueOf(counter);
         }
      }
   }

   class SSAExp implements ExpVisitor<Exp> {
      Counter counter = new Counter();

      public SSAExp() {
      }

      public Var add(Var v) {
         counter.add(v.name);
         return (Var) visit(v);
      }

      public Exp translate(Exp e) {
         return visitDispatch(e);
      }

      private Exp visitDispatch(Exp e) {
         return e.accept(this);
      }

      public Exp visit(Val val) {
         return val;
      }

      public Exp visit(Var var) {
         String num = counter.get(var.name);
         //return new Var(var.name);
         //9-17-13
         //The below code was causing an error with the newSt that used a prev var declared beforehand
         //Why cant we use the same var name? since it is being passed around...
         ///*
         if (num.equals(""))
            return new Var(var.name);
         else
            return new Var(var.name + "^" + counter.get(var.name));
         //*/
      }

      class BExpVisitor implements BinaryExpVisitor<Exp> {
         private Exp visitDispatch(BinaryExp e) {
            return e.accept(this);
         }

         public Exp visit(Plus plus) {
            return new Plus(
                  SSAExp.this.visitDispatch(plus.operand1),
                  SSAExp.this.visitDispatch(plus.operand2));
         }

         public Exp visit(Minus minus) {
            return new Minus(
                  SSAExp.this.visitDispatch(minus.operand1),
                  SSAExp.this.visitDispatch(minus.operand2));
         }

         public Exp visit(Equality equality) {
            return new Equality(
                  SSAExp.this.visitDispatch(equality.operand1),
                  SSAExp.this.visitDispatch(equality.operand2));
         }

         public Exp visit(Inequality inequality) {
            return new Inequality(
                  SSAExp.this.visitDispatch(inequality.operand1),
                  SSAExp.this.visitDispatch(inequality.operand2));
         }
         //---------------------------------------
         public Exp visit(LessThan lt) {
             return new Inequality(
                   SSAExp.this.visitDispatch(lt.operand1),
                   SSAExp.this.visitDispatch(lt.operand2));
          }
         public Exp visit(LessThanEqual lte) {
             return new Inequality(
                   SSAExp.this.visitDispatch(lte.operand1),
                   SSAExp.this.visitDispatch(lte.operand2));
          }
         public Exp visit(GreaterThan gt) {
             return new Inequality(
                   SSAExp.this.visitDispatch(gt.operand1),
                   SSAExp.this.visitDispatch(gt.operand2));
          }
         public Exp visit(GreaterThanEqual gte) {
             return new Inequality(
                   SSAExp.this.visitDispatch(gte.operand1),
                   SSAExp.this.visitDispatch(gte.operand2));
          }
         //---------------------------------------
      }
      BExpVisitor bExpVisitor = new BExpVisitor();
      public Exp visit(BinaryExp binaryExp) {
         return bExpVisitor.visitDispatch(binaryExp);
      }

      public Exp visit(UMinus minus) {
         return new Not(
               visitDispatch(minus.exp));
      }

      public Exp visit(And and) {
         return new And(
               visitDispatch(and.exp1),
               visitDispatch(and.exp2));
      }

      public Exp visit(Or or) {
         return new And(
               visitDispatch(or.exp1),
               visitDispatch(or.exp2));
      }

      public Exp visit(Not not) {
         return new Not(
               visitDispatch(not.exp));
      }

      public Exp visit(CallExp callExp) {
         Varl[] args = callExp.args;
         Varl[] newArgs = new Varl[args.length];
         for (int i = 0; i < args.length; i++) {
            Varl arg = args[i];
            newArgs[i] = (Varl) visitDispatch(arg);
         }

         return new CallExp(
            callExp.receiver,
            callExp.name,
            newArgs
         );
      }
   }

   final SSAExp ssa = new SSAExp();

   public Path makeSSA() {
      List<Step> newSteps = steps.foldLeft(
         new F2<List<Step>, Step, List<Step>>() {
            @Override
            public List<Step> f(List<Step> steps, Step step) {
               Step newStep = null;
               if (step instanceof MethodCall) {
                  MethodCall methodCall = (MethodCall) step;

                  Varl[] args = methodCall.args;
                  Varl[] newArgs = new Varl[args.length];
                  for (int i = 0; i < args.length; i++) {
                     Varl arg = args[i];
                     newArgs[i] = (Varl) ssa.translate(arg);
                  }

                  Var newRetV = ssa.add(methodCall.ret);

                  newStep = new MethodCall(methodCall.receiver, methodCall.name, newArgs, newRetV);
               } else if (step instanceof Assignment) {

//                  System.out.println(step);

                  Assignment assignment = (Assignment) step;
                  Exp newRight = ssa.translate(assignment.right);

                  Var newLeft = ssa.add(assignment.left);

                  newStep = new Assignment(newLeft, newRight);

               } else if (step instanceof Assume) {
                  Assume assume = (Assume) step;
                  Exp exp = ssa.translate(assume.exp);
                  newStep = new Assume(exp);
               } else {
            	   System.out.println("step was a different instance... " + step.toString());
               }

               return steps.snoc(newStep);
            }
         },
         List.<Step>nil()
      );

      Option<Varl> newRetv = retV.map(
         new F<Varl, Varl>() {
            @Override
            public Varl f(Varl varl) {
               return (Varl) ssa.translate(varl);
            }
         }
      );

      return new Path(newSteps, newRetv, isBreakPath, isContinuePath);
   }

   public Exp makeSSA(Exp exp) {
      return ssa.translate(exp);
   }

   public int getMethodCount() {
      int i = 0;
      for (Step step : steps) {
         if (step instanceof MethodCall)
            i += 1;
      }
      return i;
   }

   public static Path sequence(Path path1, Path path2) {
//         return new Path(path1.steps, path1.retV, path1.isBreakPath, path1.isContinuePath);
      return new Path(
         path1.steps.append(path2.steps),
         path2.retV,
         path2.isBreakPath,
         path2.isContinuePath
      );
   }

   public static java.util.List<Path> sequence(
         Path path1,
         java.util.List<Path> paths2) {
      java.util.List<Path> paths = new LinkedList<Path>();

      for (Path path2 : paths2) {
         if (path1.isBreakPath() || path1.isContinuePath() || path1.isReturnPath()) {
            paths.add(path1);
            continue;
         }
         Path path = sequence(path1, path2);
         paths.add(path);
      }
      return paths;
   }

   public static java.util.List<Path> sequence(
         java.util.List<Path> paths1,
         Path path2) {
      java.util.List<Path> paths = new LinkedList<Path>();

      for (Path path1 : paths1) {
         if (path1.isBreakPath() || path1.isContinuePath() || path1.isReturnPath()) {
            paths.add(path1);
            continue ;
         }
         Path path = sequence(path1, path2);
         paths.add(path);
      }
      return paths;
   }

   public static java.util.List<Path> sequence(
         java.util.List<Path> paths1,
         java.util.List<Path> paths2) {
      java.util.List<Path> paths = new LinkedList<Path>();

      Outer:
      for (Path path1 : paths1) {
         for (Path path2 : paths2) {
            if (path1.isBreakPath() || path1.isContinuePath() || path1.isReturnPath()) {
               paths.add(path1);
               continue Outer;
            }
            Path path = sequence(path1, path2);
            paths.add(path);
         }
      }
      return paths;
   }

}




