package cocheck.analysis;

public interface Varl extends Exp {
}
