package cocheck.analysis;

public class UMinus implements Exp {
   public Exp exp;

   public UMinus(Exp exp) {
      this.exp = exp;
   }

   public <T> T accept(ExpVisitor<T> expVisitor) {
      return expVisitor.visit(this);
   }

   @Override
   public String toString() {
      return "-(" + exp + ")";
   }
}


