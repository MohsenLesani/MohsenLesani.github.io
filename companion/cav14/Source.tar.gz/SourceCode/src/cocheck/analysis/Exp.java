package cocheck.analysis;

public interface Exp {
   public <T> T accept(ExpVisitor<T> expVisitor);
}
