package cocheck.analysis;

public class Minus extends BinaryExp {
   public Minus(Exp operand1, Exp operand2) {
      super(operand1, operand2);
   }

   @Override
   public String operator() {
      return "-";
   }

   @Override
   public <T> T accept(ExpVisitor.BinaryExpVisitor<T> visitor) {
      return visitor.visit(this);
   }

}
