package cocheck.analysis;

public abstract class Val implements Varl {
   public String val;

   public Val(String val) {
      this.val = val;
   }

   public <T> T accept(ExpVisitor<T> expVisitor) {
      return expVisitor.visit(this);
   }

   public abstract <T> T accept(ExpVisitor.ValVisitor<T> valVisitor);

   @Override
   public String toString() {
      return val;
   }
}
