package cocheck.analysis;

public class CallExp implements Exp {
   public Var receiver;
   public String name;
   public Varl[] args;

   public CallExp(Var receiver, String name, Varl[] args) {
      this.receiver = receiver;
      this.name = name;
      this.args = args;
   }

   public CallExp(String receiver, String name, String[] args) {
      this.receiver = new Var(receiver);
      this.name = name;
      this.args = new Varl[args.length];
      for (int i = 0; i < args.length; i++) {
         String arg = args[i];
         if (arg.equals("null"))
            this.args[i] = new NullVal();
         if (isInt(arg))
            this.args[i] = new IntVal(arg);
         else if (isBool(arg))
            this.args[i] = new BoolVal(arg);
         else
            this.args[i] = new Var(arg);
      }
   }

   public CallExp(String receiver, String name, Varl[] args) {
      this.receiver = new Var(receiver);
      this.name = name;
      this.args = args;
   }

   public <T> T accept(ExpVisitor<T> expVisitor) {
      return expVisitor.visit(this);
   }

   private boolean isInt(String s) {
      try {
         Integer.parseInt(s);
         return true;
      } catch (NumberFormatException e) {
         return false;
      }
   }

   private boolean isBool(String s) {
      return s.equals("true") || s.equals("false");
   }

   @Override
   public String toString() {
      String s = receiver.toString() + "." + name + "(";
      for (int i = 0; i < args.length; i++) {
         Varl arg = args[i];
         s += arg.toString();
         if (i != args.length - 1)
            s += " ";
      }
      s += ")";
      return s;
   }
}
