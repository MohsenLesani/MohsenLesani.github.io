package cocheck.analysis;

public class Or implements Exp {
   public Exp exp1;
   public Exp exp2;

   public Or(Exp exp1, Exp exp2) {
      this.exp1 = exp1;
      this.exp2 = exp2;
   }

   public <T> T accept(ExpVisitor<T> expVisitor) {
      return expVisitor.visit(this);
   }

   @Override
   public String toString() {
      return exp1 + " || " + exp2;
   }

}
