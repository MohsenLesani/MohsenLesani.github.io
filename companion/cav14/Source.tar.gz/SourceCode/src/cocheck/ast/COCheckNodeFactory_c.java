package cocheck.ast;

import polyglot.ast.*;
import polyglot.ext.jl5.ast.JL5NodeFactory_c;

/**
 * NodeFactory for COCheck extension.
 */
public class COCheckNodeFactory_c extends JL5NodeFactory_c implements COCheckNodeFactory {
    // TODO:  Implement factory methods for new AST nodes.
    // TODO:  Override factory methods for overriden AST nodes.
    // TODO:  Override factory methods for AST nodes with new extension nodes.
}
