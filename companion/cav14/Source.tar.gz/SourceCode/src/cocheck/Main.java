package cocheck;

import java.io.File;

/**
 * Main is the main program of the compiler extension.
 * It simply invokes Polyglot's main, passing in the extension's
 * ExtensionInfo.
 */

public class Main {

   public static void main(String[] args) {
      polyglot.main.Main polyglotMain = new polyglot.main.Main();

      try {
         File f = new File(args[0]);
         String filename = f.getName();
         if (filename.indexOf(".") > 0) {
             filename = filename.substring(0, filename.lastIndexOf("."));
         }
         AtomicityVisitor.fileName = filename;
         polyglotMain.start(args, new cocheck.ExtensionInfo());
      }
      catch (polyglot.main.Main.TerminationException e) {
         System.err.println(e.getMessage());
         System.exit(1);
      }
   }

}

