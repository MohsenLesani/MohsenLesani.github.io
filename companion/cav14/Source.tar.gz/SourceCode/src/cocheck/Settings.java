package cocheck;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class Settings {

   // --------------------------------------------------------
   // // To be updated
//   public static final boolean log = true;
   public static final boolean log = false;

   public static final String rootPath =
//         "/Users/lorenzo/Dropbox/research/Linearize-Mohsen/svn/atomicity/Project/polyglot-2.5.1-src/COCheck/";
       "/media/MOHSENHD/1.Works/3.Research/0.Topics/1.Project/2.Atomicity/SVN/atomicity/Project/polyglot-2.5.1-src/COCheck/";
   public static final String z3Path = 
//      "/Users/lorenzo/Dropbox/research/Linearize-Mohsen/z3-4.3.2.121e83b6b796-x64-osx-10.8.2/bin/";
      "/media/MOHSENHD/Prog/Z3/Current/bin/";

   // --------------------------------------------------------
   // Not needed to be updated
   public static final String testDir =
         rootPath + "tests/";
   public static final String processDir =
         rootPath + "tests/process/";

   static {
      try {
         PrintWriter writer = new PrintWriter(new FileOutputStream(processDir + "RunScript.sh"));
         writer.println(
               "#!/bin/sh\n" +
               "\n" +
               z3Path + "z3 -smt2 $1 | tee $2\n"
         );
         writer.close();

      } catch (FileNotFoundException e) {
         e.printStackTrace();
      }
   }
   // --------------------------------------------------------
}

