package cocheck;


import cocheck.analysis.*;
import cocheck.analysis.step.Assignment;
import cocheck.analysis.step.Assume;
import cocheck.analysis.step.MethodCall;
import cocheck.analysis.step.Step;
import fj.F;
import fj.data.Option;
import lesani.collection.Pair;
import lesani.compiler.texttree.Printable;
import lesani.compiler.texttree.Snippet;
import lesani.compiler.texttree.Text;
import lesani.compiler.texttree.seq.TextFact;
import lesani.compiler.texttree.seq.TextSeq;
import polyglot.ast.*;
import polyglot.ext.jl5.ast.*;
import polyglot.visit.NodeVisitor;

import java.io.*;
import java.util.*;


public class AtomicityVisitor extends NodeVisitor {

   public static final boolean log = Settings.log;

   public static String fileName = "";
   private String processDir = Settings.processDir;

//   private static final boolean CHECK_ASSERTION_CONSISTENCY = true;
   private static final boolean CHECK_ASSERTION_CONSISTENCY = false;
   private static final int WAIT_SEC = 7;

//   private static final Var DUMMY_RECEIVER = new Var("DummyReceiver");

   private Node root;
   private String[] baseObject;
   private String methodName;
   private boolean baseObjectIsSet = false;

   class Param {
      String name;
      boolean isArray;

      Param(String name, boolean array) {
         this.name = name;
         isArray = array;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) return true;
         if (o == null || getClass() != o.getClass()) return false;

         Param param = (Param) o;

         if (isArray != param.isArray) return false;
         if (name != null ? !name.equals(param.name) : param.name != null) return false;

         return true;
      }

      @Override
      public int hashCode() {
         int result = name != null ? name.hashCode() : 0;
         result = 31 * result + (isArray ? 1 : 0);
         return result;
      }
   }

   private Set<Param> params;

//   private Integer functionCount = 0;
//   private Integer receiversIgnored = 0;
//   private Integer functionsIgnored = 0;
//   private ArrayList<String> AllIgnoredFunctions = new ArrayList<String>();
//   private boolean ignoreStep = false;
//   private String dummyFunctionString = "DUMMY";


   private java.util.List<Path> paths = new LinkedList<Path>();

   class PurityPath {
      public Path path;
      public java.util.List<Path> nextPaths;

      PurityPath(Path path, List<Path> nextPaths) {
         this.path = path;
         this.nextPaths = nextPaths;
      }
   }
   private java.util.List<PurityPath> purityPaths = new LinkedList<PurityPath>();

   //   private Set<String> accessorMethods = new HashSet<String>();
   private Set<String> mutatorMethods = new HashSet<String>();

   private TextFact textFact = new TextFact();

   private Set<String> literals = new HashSet<String>();

   private boolean inside = false;
   private Set<String> statics = new HashSet<String>();
   private String result;

   private static boolean resultCounted = false;

   public static boolean annotatedAtomic = false;
   public static boolean verifiedAtomic = false;

   class RefObject {
      public String receiver;
      public String name;

      RefObject(String receiver, String name) {
         this.receiver = receiver;
         this.name = name;
      }
   }
   private Map<Var, RefObject> varToFieldAccess =
         new HashMap<Var, RefObject>();

   class MethodSig {
      public String object;
      public String method;
      public int argCount;
      public boolean argFunctional = false;

      MethodSig(String object, String method) {
         this.object = object;
         this.method = method;
      }

      MethodSig(String object, String method, int argCount) {
         this.object = object;
         this.method = method;
         this.argCount = argCount;
      }

      @Override
      public boolean equals(Object o) {
         if (this == o) return true;
         if (o == null || getClass() != o.getClass()) return false;

         MethodSig methodSig = (MethodSig) o;

         if (method != null ? !method.equals(methodSig.method) : methodSig.method != null)
            return false;
         if (object != null ? !object.equals(methodSig.object) : methodSig.object != null)
            return false;

         return true;
      }

      @Override
      public int hashCode() {
         int result = object != null ? object.hashCode() : 0;
         result = 31 * result + (method != null ? method.hashCode() : 0);
         return result;
      }

      public void setArgFunctional() {
         argFunctional = true;
      }

      @Override
      public String toString() {
         return object + "." + method + "(" + argCount + "), " + argFunctional;
      }
   }
   private Set<MethodSig> funMethods = new HashSet<MethodSig>();


   class UnSupportedException extends RuntimeException {};

   public AtomicityVisitor() {
//      System.out.println("In Constructor");
//      // For Map
//      accessorMethods.add("get");
//      accessorMethods.add("containsKey");
//      // For Set
//      accessorMethods.add("contains");

      // For map
      mutatorMethods.add("putIfAbsent");
      mutatorMethods.add("put");
      mutatorMethods.add("replace");
      mutatorMethods.add("add");
      mutatorMethods.add("remove");
      // For set
      mutatorMethods.add("addIfAbsent");
      mutatorMethods.add("add");
      mutatorMethods.add("remove");

      //statics.add("this");
      statics.add("Sys");

      resultCounted = false;
      Var.reset();
   }

   private String printBaseObject() {
      String r = "";
      for (int i = 0; i < baseObject.length; i++) {
         String s = baseObject[i];
         r += s;
         if (i != baseObject.length - 1)
            r += ".";
      }
      return r;
   }

   // Note: What polyglot has is not really visitor pattern.
   @Override
   public NodeVisitor enter(Node n) {
//      System.out.println("In enter " + n);

      if (n instanceof JL5MethodDecl_c && !resultCounted) {
         root = n;
         JL5MethodDecl_c method = (JL5MethodDecl_c) n;
         methodName = method.name();

         for (AnnotationElem annotationElem : method.annotationElems()) {
            String annotName = annotationElem.typeName().name();

//            System.out.println(annotName);

            if (annotName.equals("SetObject")) {
               baseObjectIsSet = true;
            } else if (annotName.equals("BaseObject")) {
               String theValue = annotationElem.elements().get(0).
                     value().constantValue().toString().replace("\"", "");
//               System.out.println(theValue);
               baseObject = theValue.split("\\.");
//               System.out.println(printBaseObject());
            } else if (annotName.equals("Functional") || annotName.equals("ArgFunctional")) {
               String oName = null;
               String mName = null;
               for (ElementValuePair elementValuePair : annotationElem.elements()) {
                  if (elementValuePair.name().equals("object"))
                     oName = elementValuePair.value().constantValue().toString().
                           replace("\"", "");
                  else if (elementValuePair.name().equals("method"))
                     mName = elementValuePair.value().constantValue().toString().
                           replace("\"", "");
               }
               MethodSig sig = new MethodSig(oName, mName);
               if (annotName.equals("ArgFunctional"))
                  sig.setArgFunctional();
               funMethods.add(sig);
//               System.out.println(funMethods);
            } else if (annotName.equals("Static")) {
               String theStatic = annotationElem.elements().get(0).value().
                     constantValue().toString().replace("\"", "");
               statics.add(theStatic);
            } else if (annotName.equals("Result")) {
               result = annotationElem.elements().get(0).value().
                     constantValue().toString().replace("\"", "");
               if (result.equals("+"))
                  annotatedAtomic = true;
               else if (result.equals("-"))
                  annotatedAtomic = false;
               else {
                  System.out.println("Invalid result annotation at " + fileName + ".");
                  //throw new UnSupportedException();
                  System.exit(1);
               }
            }
         }

         if (baseObject == null) {
            //System.out.println("Base object annotation missing.
            // The first object will be taken as the base object.");
            System.out.println("Base object annotation missing at " + fileName + ".");
            System.exit(1);
            //throw new UnSupportedException();
         }

         if (result == null) {
            System.out.println("Result annotation missing at " + fileName + ".");
            System.exit(1);
            //throw new UnSupportedException();
         }

//            System.out.println(baseObject);
//            for (ObjectMethod funcMethod : funMethods) {
//               System.out.println(funcMethod.object + "." + funcMethod.method);
//            }

         try {
            params = new HashSet<Param>();
            final java.util.List<Formal> formals = method.formals();
            for (Formal formal : formals) {
               String name = formal.name();
               boolean isArray = formal.type() instanceof ArrayTypeNode_c;
//               if (isArray && !statics.contains(name)) {
//                  System.out.println("Array not annotated static.");
//                  throw new UnSupportedException();
//               }

               params.add(new Param(name, isArray));
            }
   //         final HashList<Path> paths = new HashList<Path>();
   //         Path path = new Path();
   //         paths.add(path);

            /*
            for (AnnotationExpr ann: n.getAnnotations()) {
                System.out.println(ann.toString());
            }
            */

            if (log)
               System.out.println("Computing paths ...");

            paths = (java.util.List<Path>) visitDispatch(method.body());
            java.util.List<Path> toRemove = new LinkedList<Path>();
            for (Path path : paths) {
               if (path.steps().isEmpty()) {
                  toRemove.add(path);
   //               System.out.println("Removed empty path");
               }
            }
            for (Path path : toRemove)
               paths.remove(path);

         } catch (UnSupportedException e) {
            recordResult(false);
         }
      }
      return this;
   }

   private Object visitDispatch(Node n) {

      if (n instanceof Block_c) {
         Block_c block = (Block_c) n;
         return visit(block);
      } if (n instanceof While_c) {
         While_c theWhile = (While_c) n;
         return visit(theWhile);
      } if (n instanceof Do_c) {
         Do_c theDo = (Do_c) n;
         return visit(theDo);
      } if (n instanceof For_c) {
         For_c theFor = (For_c) n;
         return visit(theFor);
      } if (n instanceof ExtendedFor_c) {
         ExtendedFor_c theFor = (ExtendedFor_c) n;
         return visit(theFor);
      } else if (n instanceof If_c) {
         If_c theIf = (If_c) n;
         return visit(theIf);
      } else if (n instanceof Return_c) {
         Return_c theReturn = (Return_c) n;
         return visit(theReturn);
      } else if (n instanceof Branch_c) {
         Branch_c branch = (Branch_c) n;
         return visit(branch);
      } else if (n instanceof JL5LocalDecl_c) {
         JL5LocalDecl_c localDecl = (JL5LocalDecl_c) n;
         return visit(localDecl);
      } else if (n instanceof Eval_c) {
         Eval_c e = (Eval_c) n;
         return visit(e);
      } else if (n instanceof JL5Call_c) {
         JL5Call_c call = (JL5Call_c) n;
         return visit(call);
      } else if (n instanceof JL5Binary_c) {
         JL5Binary_c exp = (JL5Binary_c) n;
         return visit(exp);
      } else if (n instanceof JL5Unary_c) {
         JL5Unary_c exp = (JL5Unary_c) n;
         return visit(exp);
      } else if (n instanceof IntLit_c) {
         IntLit_c intLit = (IntLit_c) n;
         return visit(intLit);
      } else if (n instanceof NullLit_c) {
         NullLit_c nullLit = (NullLit_c) n;
         return visit(nullLit);
      } else if (n instanceof BooleanLit_c) {
         BooleanLit_c boolLit = (BooleanLit_c) n;
         return visit(boolLit);
      } else if (n instanceof JL5ClassLit_c) {
         JL5ClassLit_c lit = (JL5ClassLit_c) n;
         return visit(lit);
      } else if (n instanceof Id_c) {
         Id_c id = (Id_c) n;
         return visit(id);
      } else if (n instanceof AmbExpr_c) {
         AmbExpr_c e = (AmbExpr_c) n;
         return visit(e);
      } else if (n instanceof AmbReceiver_c) {
         AmbReceiver_c receiver = (AmbReceiver_c) n;
         return visit(receiver);
      } else if (n instanceof JL5New_c) {
         JL5New_c id_new = (JL5New_c) n;
         return visit(id_new);
      } else if (n instanceof Throw_c) {
         Throw_c theThrow = (Throw_c) n;
         return visit(theThrow);
      } else if (n instanceof JL5Conditional_c) {
         JL5Conditional_c theCond = (JL5Conditional_c) n;
         return visit(theCond);
      } else if (n instanceof JL5Special_c) {
         JL5Special_c special = (JL5Special_c) n;
         return visit(special);
      } else if (n instanceof JL5Field_c) {
         //System.out.println("Field AST:" + n.toString());
         JL5Field_c field = (JL5Field_c) n;
         return visit(field);
      } else if (n instanceof StringLit_c) {
//         System.out.println("String literal AST:" + n.toString());
         StringLit_c string = (StringLit_c) n;
         return visit(string);
      } else if (n instanceof CharLit_c) {
//         System.out.println("String literal AST:" + n.toString());
         CharLit_c charLit = (CharLit_c) n;
         return visit(charLit);
      } else if (n instanceof ArrayAccess_c) {
//         System.out.println("String literal AST:" + n.toString());
         ArrayAccess_c arrayAccess = (ArrayAccess_c) n;
         return visit(arrayAccess);
      } else if (n instanceof Cast_c) {
         Cast_c cast_stmt = (Cast_c) n;
         return visitDispatch(cast_stmt.expr());
      } else if (n instanceof Synchronized_c) {
         Synchronized_c sStmt = (Synchronized_c) n;
         return visit(sStmt);
      } else if (n instanceof Try_c) {
         Try_c theTry = (Try_c) n;
         return visit(theTry);
      } else if (n instanceof polyglot.ast.Assert_c) {
         Assert_c assertStmt = (Assert_c) n;
         return visit(assertStmt);
      } else if (n instanceof polyglot.ast.Instanceof_c) {
         Instanceof_c iStmt = (Instanceof_c) n;
         return visit(iStmt);
      } else {
         if (n != null) {
            //System.out.println("-----------------------------");
            System.out.println("Unsupported AST type:");
            System.out.println(n.getClass());
            System.out.println(n);
            //System.out.println("-----------------------------");
            throw new UnSupportedException();
         }
         return null;
      }
   }

   // ------------------------------------------------------------
   // Statements

   private java.util.List<Path> visit(Block_c block) {

      // paths(s1; s2) = paths(s1) X paths(s2)
      // Note that if a path of s1 ends in a
      // return, break or continue, then paths
      // of s2 are not appended to it.

      final java.util.List<Stmt> statements = block.statements();
      java.util.List<Path> paths = new LinkedList<Path>();
      paths.add(new Path());
      for (Stmt stmt : statements) {
//         System.out.println(stmt);
         //System.out.println(stmt.toString() + "====\n");
         java.util.List<Path> newPaths = (java.util.List<Path>)visitDispatch(stmt);
         //System.out.println("Doesnt come back here");
         paths = Path.sequence(paths, newPaths);
      }
      return paths;
   }

   private java.util.List<Path> visit(While_c theWhile) {
      // paths(while b s) =
      //   assume(not b)
      //   assume(b) X paths(s) X assume(not b)
      // assume(not b) is not added to breaking and returning paths of s.

      // ppaths(while b s) =
      //   assume(b) X paths(s)
      // paths of s that are not breaking or returning
      // If a path of s ends in a continue, it is added to purity paths.

     java.util.List<Path> allPaths = new LinkedList<Path>();
      java.util.List<Path> purityPaths = new LinkedList<Path>();

      Stmt stmt = theWhile.body();
      java.util.List<Path> bodyPaths = (java.util.List<Path>)visitDispatch(stmt);
      boolean insideAmI = inside;
      inside = true;
      Pair<java.util.List<Path>, Exp> res =
            (Pair<java.util.List<Path>, Exp>) visitDispatch(theWhile.cond());
      inside = insideAmI;

      java.util.List<Path> condPaths = res.element1;
      Exp cond = res.element2;

      java.util.List<Path> truePaths =
            Path.sequence(
                  condPaths,
                  new Path(new Assume(cond)));

      java.util.List<Path> falsePaths =
            Path.sequence(
                  condPaths,
                  new Path(new Assume(new Not(cond))));

      // The condition fails at the beginning
      allPaths.addAll(falsePaths);

      for (Path bodyPath : bodyPaths) {
         if (bodyPath.isNormalPath()) {
            java.util.List<Path> loopPaths =
               Path.sequence(
                     Path.sequence(
                           truePaths,
                           bodyPath
                     ),
                     falsePaths
               );
            allPaths.addAll(loopPaths);
            java.util.List<Path> loopingPaths =
                  Path.sequence(
                        truePaths,
                        bodyPath
                  );
            purityPaths.addAll(loopingPaths);
         } else if (bodyPath.isBreakPath() || bodyPath.isReturnPath()) {
            java.util.List<Path> outPaths =
               Path.sequence(
                     truePaths,
                     bodyPath
               );
//            if (bodyPath.isReturnPath())
//               outPath.setRetV(bodyPath.retV());
            allPaths.addAll(outPaths);
         } else if (bodyPath.isContinuePath()) {
            java.util.List<Path> loopingPaths =
               Path.sequence(
                     truePaths,
                     bodyPath
               );
            purityPaths.addAll(loopingPaths);
         }
         // not breaking and not continue
         // Only returning remains returning.
      }

      for (Path purityPath : purityPaths)
         this.purityPaths.add(new PurityPath(purityPath, allPaths));

      return allPaths;
   }



   private java.util.List<Path> visit(Do_c thDo) {

      // paths(do s while (b)) =
      //   paths(s) X assume(not b)
      // assume(not b) is not added to breaking and returning paths of s.

      // ppaths(do s while (b)) =
      //   paths(s) X assume(b)
      // If a path of s ends in a continue, it is added to purity paths.

      java.util.List<Path> allPaths = new LinkedList<Path>();
      java.util.List<Path> purityPaths = new LinkedList<Path>();

      Stmt stmt = thDo.body();
      java.util.List<Path> bodyPaths = (java.util.List<Path>)visitDispatch(stmt);
      boolean insideAmI = inside;
      inside = true;
      Pair<java.util.List<Path>, Exp> res =
            (Pair<java.util.List<Path>, Exp>) visitDispatch(thDo.cond());
      inside = insideAmI;

      java.util.List<Path> condPaths = res.element1;
      Exp cond = res.element2;

      java.util.List<Path> truePaths =
            Path.sequence(
                  condPaths,
                  new Path(new Assume(cond)));

      java.util.List<Path> falsePaths =
            Path.sequence(
                  condPaths,
                  new Path(new Assume(new Not(cond))));

      for (Path bodyPath : bodyPaths) {
         if (bodyPath.isNormalPath()) {
            java.util.List<Path> loopPaths =
               Path.sequence(
                  bodyPath,
                  falsePaths
               );
            allPaths.addAll(loopPaths);

            java.util.List<Path> loopingPaths =
                  Path.sequence(
                     bodyPath,
                     truePaths
                  );
            purityPaths.addAll(loopingPaths);
         } else if (bodyPath.isBreakPath() || bodyPath.isReturnPath()) {
            allPaths.add(bodyPath);
         } else if (bodyPath.isContinuePath()) {
            purityPaths.add(bodyPath);
         }
      }

      for (Path purityPath : purityPaths)
         this.purityPaths.add(new PurityPath(purityPath, allPaths));

      return allPaths;
   }

   private java.util.List<Path> visit(If_c theIf) {
      // paths(if b s1 else s2) =
      //    assume(b) X paths(s1)
      //    assume(not b) X paths (s2)
      // If there is no else branch,
      //    assume(not b) is the only step for it.

      java.util.List<Path> pathsRet = new LinkedList<Path>();

      boolean insideAmI = inside;
      inside = true;
      // We want method calls in conditions to come before the condition.
      Pair<java.util.List<Path>, Exp> res =
         (Pair<java.util.List<Path>, Exp>) visitDispatch(theIf.cond());
      inside = insideAmI;

      java.util.List<Path> prePaths = res.element1;
      Exp exp = res.element2;

      Stmt thenStmt = theIf.consequent();
//      System.out.println("then: " + thenStmt);
      java.util.List<Path> thenPathsRet = (java.util.List<Path>) visitDispatch(thenStmt);
      thenPathsRet = Path.sequence(new Path(new Assume(exp)), thenPathsRet);
      pathsRet.addAll(thenPathsRet);

      Stmt elseStmt = theIf.alternative();
//      System.out.println("else: " + elseStmt);

      if (elseStmt != null) {
         java.util.List<Path> elsePathsRet = (java.util.List<Path>) visitDispatch(elseStmt);
         elsePathsRet = Path.sequence(new Path(new Assume(new Not(exp))), elsePathsRet);
         pathsRet.addAll(elsePathsRet);
      } else {
         Path path = new Path(new Assume(new Not(exp)));
         pathsRet.add(path);
      }

      return Path.sequence(prePaths, pathsRet);
   }

   private java.util.List<Path> visit(JL5LocalDecl_c localDecl) {
      Var left = new Var(localDecl.id().id());
      Expr init = localDecl.init();
//      boolean insideAmI = inside;
//      inside = true;
      if (init != null) {
         Pair<java.util.List<Path>, Exp> res =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(init);
         java.util.List<Path> prePaths = res.element1;
         Exp exp = res.element2;
   //      inside = insideAmI;

         return Path.sequence(prePaths, makeExpStmt(left, exp));
      } else {
         LinkedList<Path> paths = new LinkedList<Path>();
         paths.add(new Path());
         return paths;
      }
   }

   private java.util.List<Path> visit(Eval_c e) {
      Expr expr = e.expr();
      if (expr instanceof Assign_c) {

         Assign_c assign = (Assign_c) expr;
         Pair<java.util.List<Path>, Exp> lRes =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(assign.left());

         Exp lExp = lRes.element2;
         Var left = expectVar(lExp);

//         boolean insideAmI = inside;
//         inside = true;
         Pair<java.util.List<Path>, Exp> res =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(assign.right());
         java.util.List<Path> prePaths = res.element1;
         Exp exp = res.element2;
//         inside = insideAmI;

         return Path.sequence(prePaths, makeExpStmt(left, exp));

      } else if (expr instanceof JL5Call_c) {

         Var left = Var.freshVar();

         boolean insideAmI = inside;
         inside = true;
         Pair<java.util.List<Path>, Exp> res =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(expr);
         java.util.List<Path> prePaths = res.element1;
         Exp exp = res.element2;
         inside = insideAmI;

         return Path.sequence(prePaths, makeExpStmt(left, exp));

      } else
         throw new RuntimeException(
            "Non-assignment expression statement: " + expr + " of type " + expr.getClass()
         );
   }

   private java.util.List<Path> makeExpStmt(Var left, Exp exp) {
//      System.out.println(exp);
      if (exp instanceof CallExp) {
//         System.out.println("MethodCall");
         CallExp callExp = (CallExp) exp;
         MethodCall methodCall =
               new MethodCall(callExp.receiver, callExp.name, callExp.args, left);
         java.util.List<Path> newPaths = new LinkedList<Path>();
         Path newPath = new Path();
         newPath.setSteps(newPath.steps().cons(methodCall));
         newPaths.add(newPath);
         return newPaths;
      } else {
//         System.out.println("Assignment");
         Assignment assignment = new Assignment(left, exp);
         java.util.List<Path> newPaths = new LinkedList<Path>();
         Path newPath = new Path();
         newPath.setSteps(newPath.steps().cons(assignment));
         newPaths.add(newPath);
         return newPaths;
      }
   }

   private java.util.List<Path> visit(Return_c theReturn) {
      java.util.List<Path> newPaths = new LinkedList<Path>();
      Expr expr = theReturn.expr();
      Varl varl;
      java.util.List<Path> prePaths = null;
      if (expr == null)
         varl = new NullVal();
      else {
         boolean insideAmI = inside;
         inside = true;
         Pair<java.util.List<Path>, Exp> res =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(expr);
         prePaths = res.element1;
         Exp exp = res.element2;
         inside = insideAmI;
         varl = expectVarl(exp);
      }
      Path newPath = new Path(varl);
      newPaths.add(newPath);
      if (prePaths == null)
         return newPaths;
      else
         return Path.sequence(prePaths, newPaths);
   }

   private java.util.List<Path> visit(Throw_c theThrow) {
      java.util.List<Path> newPaths = new LinkedList<Path>();
      Varl varl = new NullVal();
      Path newPath = new Path(varl);
      newPaths.add(newPath);
      return newPaths;
   }

   private java.util.List<Path> visit(Branch_c branch) {
      Path path = new Path();
      java.util.List<Path> paths = new LinkedList<Path>();
      paths.add(path);

      if (branch.kind() == Branch.BREAK)
         path.setBreakPath();
      else if (branch.kind() == Branch.CONTINUE)
         path.setContinuePath();

      return paths;
   }



   // ------------------------------------------------------------
   // Expressions

   private Pair<java.util.List<Path>, Exp> visit(JL5Unary_c exp) {
      Unary.Operator operator = exp.operator();
      boolean insideAmI = inside;
      inside = true;
      Pair<java.util.List<Path>, Exp> res =
            (Pair<java.util.List<Path>, Exp>) visitDispatch(exp.expr());
      Exp operand = res.element2;
      java.util.List<Path> paths = res.element1;
      inside = insideAmI;

      if (operator == Unary.NOT) {
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            new Not(operand)
         );
      } else if (operator == Unary.NEG) {
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            new UMinus(operand)
         );
      } else {
         System.out.println("new operator type: " + operator);
         return null;
      }
   }


   private Pair<java.util.List<Path>, Exp> visit(JL5Binary_c binexp) {
      final Binary.Operator operator = binexp.operator();
      boolean insideAmI = inside;
      inside = true;

      Pair<java.util.List<Path>, Exp> res1 =
            (Pair<java.util.List<Path>, Exp>)visitDispatch(binexp.left());
      Pair<java.util.List<Path>, Exp> res2 =
            (Pair<java.util.List<Path>, Exp>)visitDispatch(binexp.right());

      java.util.List<Path> paths1 = res1.element1;
      Exp exp1 = res1.element2;
      java.util.List<Path> paths2 = res2.element1;
      Exp exp2 = res2.element2;
      java.util.List<Path> paths = Path.sequence(paths1, paths2);
      inside = insideAmI;
      Exp exp;
      if (operator == Binary.ADD) {
         exp = new Plus(exp1, exp2);
      } else if (operator == Binary.SUB) {
         exp = new Minus(exp1, exp2);
      } else if (operator == Binary.EQ) {
         exp = new Equality(exp1, exp2);
      } else if (operator == Binary.NE) {
         exp = new Inequality(exp1, exp2);
      } else if (operator == Binary.LE) {
         exp = new LessThanEqual(exp1, exp2);
      } else if (operator == Binary.GE) {
         exp = new GreaterThanEqual(exp1, exp2);
      } else if (operator == Binary.GT) {
         exp = new GreaterThan(exp1, exp2);
      } else if (operator == Binary.LT) {
         exp = new LessThan(exp1, exp2);
      } else if (operator == Binary.COND_AND) {
         exp = new And(exp1, exp2);
      } else if (operator == Binary.COND_OR) {
         exp = new Or(exp1, exp2);
      } else {
         System.out.println("new operator type:" + operator);
         return null;
      }

      if (insideAmI) {
         Var var = Var.freshVar();
         java.util.List<Path> last = makeExpStmt(var, exp);
         paths = Path.sequence(paths, last);
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            var
         );
      } else {
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            exp
         );
      }
   }

   private Pair<java.util.List<Path>, Exp> visit(Instanceof_c iStmt) {
      LinkedList<Path> paths = new LinkedList<Path>();
      Var var = Var.freshVar();
      // So that the var is written once.
      paths.add(new Path(new Assignment(var, var)));
      return new Pair<java.util.List<Path>, Exp>(
         paths,
         var
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(IntLit_c intLit) {
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new IntVal(intLit.toString())
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(BooleanLit_c boolLit) {
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new BoolVal(boolLit.toString())
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(JL5ClassLit_c lit) {
      String name = lit.toString().replace("{amb}", "");
      literals.add("Literal_" + name);
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new StringVal(name)
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(StringLit_c string) {
      literals.add("Literal_" +
            string.toString().replace(" ", "_").replace("\"", ""));
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new StringVal(string.toString())
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(CharLit_c charLit) {
      literals.add("Literal_" +
            charLit.toString().replace("'", ""));
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new StringVal(charLit.toString().replace("'", ""))
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(NullLit_c nullLit) {
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new NullVal()
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(Id_c id) {
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new Var(id.id())
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(AmbExpr_c e) {
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new Var(e.name())
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(JL5Call_c call) {
      java.util.List<Path> paths = new LinkedList<Path>();
      paths.add(new Path());

      Receiver receiver = call.target();
      String name = call.name();

      Var r;
      if (receiver == null) {
         r = new Var("this");
         if (!funMethods.contains(new MethodSig("this", name)) &&
             !equalBaseObject(r, baseObject)) {
            if (log) {
               System.out.println("Multiple receiver objects.");
               System.out.println("At Method call: " +
                     call.toString().replace("{amb}", ""));
               System.out.println("The current receiver is: None");
               System.out.println("The base object is: " + printBaseObject());
            }
            //System.exit(1);
            throw new UnSupportedException();
         }


      } else {
         boolean insideAmI = inside;
         inside = true;

         Pair<java.util.List<Path>, Exp> res1 =
               (Pair<java.util.List<Path>, Exp>)visitDispatch(receiver);

         java.util.List<Path> prePaths = res1.element1;
         Exp exp = res1.element2;
         inside = insideAmI;

         paths = Path.sequence(prePaths, paths);
         r = expectVar(exp);

         String rec = r.toString();

         if (!(
            equalBaseObject(r, baseObject) ||
            funMethods.contains(new MethodSig(rec, name)) ||
            name.equals("equals")
         )) {
            if (log) {
               System.out.println("Multiple receiver objects.");
               System.out.println("At Method call: " +
                     call.toString().replace("{amb}", ""));
               System.out.println("The current receiver is: " + rec);
               System.out.println("The base object is: " + printBaseObject());
            }
            //System.exit(1);
            throw new UnSupportedException();
         }
      }

      boolean insideAmI = inside;
      inside = true;

      java.util.List<Expr> exprs = call.arguments();
      Varl[] args = new Varl[exprs.size()];
      for (int i = 0; i < exprs.size(); i++) {
         Expr expr = exprs.get(i);
         Pair<java.util.List<Path>, Exp> res =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(expr);
         java.util.List<Path> pathsRes = res.element1;
         Exp expArg = res.element2;

         paths = Path.sequence(paths, pathsRes);

         args[i] = expectVarl(expArg);
      }
      CallExp callExp = new CallExp(r, name, args);

      for (MethodSig funMethod : funMethods) {
         if (funMethod.object.equals(r.name) && funMethod.method.equals(name) &&
             !name.equals("equals"))
            funMethod.argCount = args.length;
      }

      inside = insideAmI;
      if (insideAmI) {
         Var var = Var.freshVar();
         java.util.List<Path> last = makeExpStmt(var, callExp);
         paths = Path.sequence(paths, last);
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            var
         );
      } else {
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            callExp
         );
      }
   }

   private boolean equalBaseObject(Var var, String[] baseObject) {
      // Currently this works for baseobjects of the form "o1.o2" but can be extended
      // to arbitrary number of dereferences.
      RefObject refObject = varToFieldAccess.get(var);
      if (refObject == null) {
         return baseObject.length == 1 &&
                var.name.equals(baseObject[0]);
      }

      return refObject.receiver.equals(baseObject[0]) &&
             refObject.name.equals(baseObject[1]);
   }

   private Pair<java.util.List<Path>, Exp> visit(AmbReceiver_c receiver) {
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new Var(receiver.name())
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(JL5Conditional_c theCond) {

      Var fVar = Var.freshVar();

      java.util.List<Path> pathsRet = new LinkedList<Path>();

      boolean insideAmI = inside;
      inside = true;
      Pair<java.util.List<Path>, Exp> res =
            (Pair<java.util.List<Path>, Exp>) visitDispatch(theCond.cond());
      inside = insideAmI;

      java.util.List<Path> prePaths = res.element1;
      Exp exp = res.element2;

      Expr thenExpr = theCond.consequent();
      insideAmI = inside;
      inside = true;
      Pair<java.util.List<Path>, Exp> thenPathsRet =
            (Pair<java.util.List<Path>, Exp>) visitDispatch(thenExpr);
      inside = insideAmI;
      java.util.List<Path> thenPaths = new LinkedList<Path>();
//      Step step;
//      if (thenPathsRet.element2 instanceof CallExp) {
//         CallExp cExp = (CallExp)thenPathsRet.element2;
//         new Path(new MethodCall(fVar, cExp.name, cExp.args);
//      } else
//         step = new Assignment(fVar, thenPathsRet.element2);
      for (Path path : thenPathsRet.element1) {
         Path newPath =
            Path.sequence(
               Path.sequence(
                  new Path(new Assume(exp)),
                  path
               ),
               new Path(new Assignment(fVar, thenPathsRet.element2))
            );
         thenPaths.add(newPath);
      }
      pathsRet.addAll(thenPaths);

      Expr elseExpr = theCond.alternative();
      if (elseExpr != null) {
         insideAmI = inside;
         inside = true;
         Pair<java.util.List<Path>, Exp> elsePathsRet =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(elseExpr);
         inside = insideAmI;
         java.util.List<Path> elsePaths = new LinkedList<Path>();
         for (Path path : elsePathsRet.element1) {
            Path newPath =
               Path.sequence(
                  Path.sequence(
                     new Path(new Assume(new Not(exp))),
                     path
                  ),
                  new Path(new Assignment(fVar, elsePathsRet.element2))
               );
            elsePaths.add(newPath);
         }
         pathsRet.addAll(elsePaths);
      } else {
         Path path = new Path();
         path.setSteps(path.steps().cons(new Assume(new Not(exp))));
         pathsRet.add(path);
      }

      return new Pair<java.util.List<Path>, Exp>(
         Path.sequence(prePaths, pathsRet),
         fVar
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(JL5Special_c special) {
      java.util.LinkedList<Path> empty = new java.util.LinkedList<Path>();
      empty.add(new Path());
      return new Pair<java.util.List<Path>, Exp>(
         empty,
         new Var(special.kind().toString())
      );
   }

   private Pair<java.util.List<Path>, Exp> visit(ArrayAccess_c arrayAccess) {
      Expr array = arrayAccess.array();
      Expr index = arrayAccess.index();

      java.util.List<Path> paths = new java.util.LinkedList<Path>();
      paths.add(new Path());

      boolean insideAmI = inside;
      inside = true;
      Pair<java.util.List<Path>, Exp> arrayRes =
         (Pair<java.util.List<Path>, Exp>) visitDispatch(array);
      java.util.List<Path> arrayPaths = arrayRes.element1;
      Exp arrayExp = arrayRes.element2;
      Varl arrayVarl = expectVarl(arrayExp);
      inside = insideAmI;

      insideAmI = inside;
      inside = true;
      Pair<java.util.List<Path>, Exp> indexRes =
         (Pair<java.util.List<Path>, Exp>) visitDispatch(index);
      java.util.List<Path> indexPaths = indexRes.element1;
      Exp indexExp = indexRes.element2;
      Varl indexVarl = expectVarl(indexExp);
      inside = insideAmI;

//      funMethods.add(new MethodSig("Sys", arrayVarl.toString(), 1));
      CallExp callExp = new CallExp("Sys", arrayVarl.toString(), new Varl[] {indexVarl});

      paths = Path.sequence(paths, arrayPaths);
      paths = Path.sequence(paths, indexPaths);

      if (insideAmI) {
         Var var = Var.freshVar();
         java.util.List<Path> last = makeExpStmt(var, callExp);
         paths = Path.sequence(paths, last);

         return new Pair<java.util.List<Path>, Exp>(
            paths,
            var
         );
      } else {
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            callExp
         );
      }
   }

   private Pair<java.util.List<Path>, Exp> visit(JL5New_c newSt) {
//      functionCount++;
//      System.out.println("Visited JL5new " + newSt.toString() + "_newSt_DUMMY" + "f" + functionCount);
//      return new CallExp(newSt.toString() + "_newSt_" + dummyFunctionString, dummyFunctionString, new String[]{});
      String typeName = newSt.objectType().name();
      String methodName = "new";

      java.util.List<Path> paths = new java.util.LinkedList<Path>();
      paths.add(new Path());

      boolean insideAmI = inside;
      inside = true;

      java.util.List<Expr> exprs = newSt.arguments();
      Varl[] args = new Varl[exprs.size()];
      for (int i = 0; i < exprs.size(); i++) {
         Expr expr = exprs.get(i);

         Pair<java.util.List<Path>, Exp> res =
               (Pair<java.util.List<Path>, Exp>) visitDispatch(expr);
         java.util.List<Path> pathsRes = res.element1;
         Exp expArg = res.element2;

         paths = Path.sequence(paths, pathsRes);

         args[i] = expectVarl(expArg);
      }
      inside = insideAmI;

      funMethods.add(new MethodSig("Sys", typeName + "_" + methodName, args.length));

      CallExp callExp = new CallExp("Sys", typeName + "_" + methodName, args);

      if (insideAmI) {
         Var var = Var.freshVar();
         java.util.List<Path> last = makeExpStmt(var, callExp);
         paths = Path.sequence(paths, last);

         return new Pair<java.util.List<Path>, Exp>(
            paths,
            var
         );
      } else {
         return new Pair<java.util.List<Path>, Exp>(
            paths,
            callExp
         );
      }
   }

   private Pair<java.util.List<Path>, Exp> visit(JL5Field_c field) {
//      System.out.println("Visited JL5Field this_" + id.id());
      Pair<java.util.List<Path>, Exp> recRes =
            (Pair<java.util.List<Path>, Exp>) visitDispatch(field.target());

      java.util.List<Path> prePaths = recRes._1();
      Exp exp = recRes._2();

      Var recVar = expectVar(exp);
      Var var = Var.freshVar();
      CallExp callExp = new CallExp(recVar, field.name(), new Varl[]{});
      java.util.List<Path> paths = makeExpStmt(var, callExp);
      java.util.List<Path> retPaths = Path.sequence(prePaths, paths);

      funMethods.add(new MethodSig(recVar.name, field.name(), 0));

      if (!(funMethods.contains(new MethodSig(recVar.name, field.name())) ||
         Var.isGenVar(recVar))) {
         if (log) {
            System.out.println("Multiple base objects. Field Access: " + field);
            System.out.println("BaseReceiver: " + printBaseObject());
            System.out.println("CurrentReceiver: " + recVar.name);
         }
         //System.exit(1);
         throw new UnSupportedException();
      }

      varToFieldAccess.put(var, new RefObject(recVar.name, field.name()));

      return new Pair<java.util.List<Path>, Exp>(
         retPaths,
         var
      );
   }

//   private Pair<java.util.List<Path>, Exp> visit(Empty_c empty) {
//      System.out.println("===" + empty + "===");
//      System.out.println("Visited Empty_c empty_" + empty);
//      return new Var("empty_" + empty);
//   }
//
   private java.util.List<Path> visit(Assert_c assert_stmt) {
      LinkedList<Path> paths = new LinkedList<Path>();
      paths.add(new Path());
      return paths;
   }

//
//   private Pair<java.util.List<Path>, Exp> visit(Cast_c cast_stmt) {
//      System.out.println("===" + cast_stmt + "===");
//      return new Var("cast_" + cast_stmt);
//   }

   private java.util.List<Path> visit(ExtendedFor_c theFor) {
      //Not finished, but should be similar to If
      visitDispatch(theFor.expr());
      visitDispatch(theFor.body());

      System.out.println("Unsupported AST type: Extended for loop");
      throw new UnSupportedException();
   }

   private java.util.List<Path> visit(For_c theFor) {
      //Not finished, but should be similar to If


      visitDispatch(theFor.body());
      System.out.println("Unsupported AST type: Extended for loop");
      throw new UnSupportedException();
   }

   private java.util.List<Path> visit(Synchronized_c synch) {
      //Not finished, but should be similar to If


      visitDispatch(synch.body());
      System.out.println("Unsupported AST type: Synchrinized block");
      throw new UnSupportedException();
   }
   private java.util.List<Path> visit(Try_c theTry) {
      //Not finished, but should be similar to If


      visitDispatch(theTry.tryBlock());
      List<Catch> cathes = theTry.catchBlocks();
      for (Catch cathe : cathes)
         visitDispatch(cathe.body());
      visitDispatch(theTry.finallyBlock());
      System.out.println("Unsupported AST type: try/catch/finally");
      throw new UnSupportedException();

		/*
		   java.util.List<Path> pathsRet = new LinkedList<Path>();
	      Exp exp = (Exp) visitDispatch(theIf.cond());

	      Stmt thenStmt = theIf.consequent();
	      java.util.List<Path> thenPathsRet = (java.util.List<Path>) visitDispatch(thenStmt);
	      java.util.List<Path> thenPaths = new LinkedList<Path>();
	      for (Path path : thenPathsRet) {
	         Path newPath = new Path(path.steps().cons(new Assume(exp)),
	               path.retV(), path.isBreakPath(), path.isContinuePath());
	         thenPaths.add(newPath);
	      }
	      pathsRet.addAll(thenPaths);

	      Stmt elseStmt = theIf.alternative();
	      if (elseStmt != null) {
	         java.util.List<Path> elsePathsRet = (java.util.List<Path>) visitDispatch(elseStmt);
	         java.util.List<Path> elsePaths = new LinkedList<Path>();
	         for (Path path : elsePathsRet) {
	            Path newPath = new Path(path.steps().cons(new Assume(new Not(exp))),
	                  path.retV(), path.isBreakPath(), path.isContinuePath());
	            elsePaths.add(newPath);
	         }
	         pathsRet.addAll(elsePaths);
	      } else {
	         Path path = new Path();
	         path.setSteps(path.steps().cons(new Assume(new Not(exp))));
	         pathsRet.add(path);
	      }
	      return pathsRet;
		*/
   }


   private Var expectVar(Exp exp) {
      if (exp instanceof Var) {
         return (Var) exp;
      } else
         throw new RuntimeException("Var expected but " + exp.getClass() + " found.");

   }
   private Varl expectVarl(Exp exp) {
//      if (exp == null)
//         return null;
      if (exp instanceof Var) {
         return (Var) exp;
      } else if (exp instanceof Val) {
         return (Val) exp;
      } else
         System.out.println(exp);
         throw new RuntimeException("Var or Val expected but " +
               exp + " of class " + exp.getClass() + " found.");
   }


   // ------------------------------------------------------------


   public static int pathCount = 0;
   public static int purityPathCount = 0;
   @Override
   public Node leave(Node old, Node n, NodeVisitor v) {
      if (n == root && !resultCounted) {
         purityPathCount = purityPaths.size();
         pathCount = paths.size();
         if (log) {
            System.out.println("Computed " + purityPaths.size() + " Purity Paths.");

            System.out.println("Computed " + paths.size() + " Paths.");

         }
         //System.out.println("Transforming to SSA form");

         boolean b;
         try {
            b = checkPurityPaths();
            if (b)
               b = checkPaths();
         } catch (UnSupportedException e) {
            b = false;
         }

         recordResult(b);
         resultCounted = false;
      }
      return super.leave(old, n, v);
   }

   private void recordResult(boolean b) {
      verifiedAtomic = b;
      if (b) {
         if (log)
            System.out.println(fileName + " is atomic.");
//         if (result.equals("-"))
//            falsePositives.add(fileName);
      } else {
         if (log)
            System.out.println(fileName + " is not verified to be atomic.");
//         if (result.equals("+"))
//            falseNegatives.add(fileName);
      }
      resultCounted = true;
   }

   private void SSAPaths() {
      java.util.List<Path> newPaths = new LinkedList<Path>();
      for (Path path : paths) {
//         path.setSteps(path.steps().reverse());
         Path newPath = path.makeSSA();
         newPaths.add(newPath);
      }
      paths = newPaths;
   }

   private void SSAPurityPaths() {
      java.util.List<Path> newPaths = new LinkedList<Path>();
      for (PurityPath path : purityPaths) {
//         path.setSteps(path.steps().reverse());
         path.path = path.path.makeSSA();
         //newPaths.add(newPath);
      }
      //purityPaths = newPaths;
   }

   private void printPaths() {
      int i = 1;
      for (Path path : paths) {
         if (log) {
            System.out.println("----------------------------------");
            System.out.println("Path " + i + ":");
         }
         printPath(path);
         i += 1;
      }
      if (log)
         System.out.println("----------------------------------");
   }

   private void printPurityPaths() {
      int i = 1;
      for (PurityPath path : purityPaths) {
         if (log) {
            System.out.println("----------------------------------");
            System.out.println("Purity Path " + i + ":");
         }
         printPath(path.path);
         i += 1;
      }
      if (log)
         System.out.println("----------------------------------");
   }

   private void printPath(Path path) {
      int j = 0;
      for (Step step : path.steps()) {
         if (log)
            System.out.println("\t" + j + ": " + step);
         j = j + 1;
      }
      path.retV().map(
         new F<Varl, Object>() {
               @Override
               public Object f(Varl varl) {
                  if (log)
                     System.out.println("\treturn " + varl);
                  return null;
               }
           }
      );
   }

   // ------------------------------------------------------------
   private boolean checkPurityPaths() {

      if (purityPaths.size() == 0)
         return true;

      printPurityPaths();

      if (log)
         System.out.println("Checking Paths for purity:");

      int i = 1;
      boolean b = true;
      for (PurityPath puritypath : purityPaths) {
         if (log) {
            System.out.println("\tChecking purity path " + i);
            //System.out.println("\t\t...");

            System.out.println("\t\tChecking for no carry to the next iteration");
            System.out.println("\t\t...");
         }
         b = checkNoLeakageToNextIter(puritypath);
         if (b) {
            if (log) {
               System.out.println("\t\tChecking that methods are accessors");
               System.out.println("\t\t...");
            }
            SSAPurityPaths();
            b = checkAccessorMethods(puritypath, i);
         }

         if (!b) {
            if (log)
               System.out.println("\t\tFailed\n");
            return false;
         } else {
            if (log)
               System.out.println("\t\tPassed\n");
         }

         i += 1;
      }
      return b;
   }


   private boolean checkAccessorMethods(PurityPath puritypath, int i) {

      Path path = puritypath.path;
      String name = fileName + "_p" + i;

      TextSeq seq2 = textFact.newText();
      Text prelude = genPrelude();
      seq2.add(prelude);
      Text text2 = genPurityPath(path, i);
      seq2.add(text2);
      Text text3 = genPurityConjecture(path);
      seq2.add(text3);
      Text text = seq2.get();

      try {
         return !isSat(text, name, WAIT_SEC);
      } catch (TimeoutException e) {
         //System.out.println("The path was not verified in " + WAIT_SEC + " seconds.");
         return false;
      }
   }


   private boolean checkNoLeakageToNextIter(PurityPath puritypath) {
      Path path = puritypath.path;
      Set<Var> writtenVars = getWrittenVars(path);
//      System.out.println("-----------------------------");
//      printPath(path);
//      System.out.println("WrittenVars = " + writtenVars);
//      System.out.println("-----------------------------");
      for (Path nextPath : puritypath.nextPaths) {
         Set<Var> readVars = getReadVars(nextPath);
//         System.out.println("-----------------------------");
//         printPath(nextPath);
//         System.out.println("ReadVars = " + readVars);
//         System.out.println("-----------------------------");
         for (Var readVar : readVars)
            if (writtenVars.contains(readVar)) {
               System.out.println("\t\tFound carried variable: " + readVar);
               return false;
            }
      }
      return true;
   }


   private Set<Var> getObjectWrittenVars(Path path) {
      Set<Var> vars = new HashSet<Var>();
      for (Step step : path.steps()) {
         if (step instanceof MethodCall) {
            MethodCall call = (MethodCall) step;
            if (call.name.equals("get") || call.name.equals("putIfAbsent"))
               vars.add(call.ret);
         }
         //} else if (step instanceof Assignment) {
         //    // Do nothing
         //} else if (step instanceof Assume) {
         //   // Do nothing
         //}
      }
      return vars;
   }


   private Set<Var> getWrittenVars(Path path) {
      Set<Var> vars = new HashSet<Var>();
      for (Step step : path.steps()) {
         if (step instanceof MethodCall) {
            MethodCall call = (MethodCall) step;
            vars.add(call.ret);
         } else if (step instanceof Assignment) {
            Assignment assign = (Assignment) step;
            vars.add(assign.left);
         } else if (step instanceof Assume) {
            // Do nothing
         }
      }
      return vars;
   }

   class MathExpVisitor implements ExpVisitor {
      Set<Var> vars = new HashSet<Var>();

      MathExpVisitor(Set<Var> vars) {
         this.vars = vars;
      }

      private Object visitDispatch(Exp exp) {
         return exp.accept(this);
      }

      public Object visit(Val val) {
         return null;
      }

      public String visit(Var var) {
         return null;
      }

      public String visit(BinaryExp binaryExp) {
         if (binaryExp instanceof Plus || binaryExp instanceof Minus) {
            Exp op1 = binaryExp.operand1;
            Exp op2 = binaryExp.operand2;

            if (op1 instanceof Var)
               vars.add((Var)op1);
            if (op2 instanceof Var)
               vars.add((Var)op2);
         }
         return null;
      }

      public String visit(UMinus minus) {
         return null;
      }

      public String visit(And and) {
         return null;
      }

      public String visit(Or or) {
         return null;
      }

      public String visit(Not not) {
         return null;
      }

      public String visit(CallExp callExp) {
         return null;
      }
   }

   /*
   private Set<Var> getMathVars(Path path) {
      final Set<Var> vars = new HashSet<Var>();
      MathExpVisitor visitor = new MathExpVisitor(vars);
      for (Step step : path.steps()) {
         if (step instanceof MethodCall) {
//            Do nothing
         } else if (step instanceof Assignment) {
            Assignment assign = (Assignment) step;
            visitor.visitDispatch(assign.right);
         } else if (step instanceof Assume) {
//            Do nothing
         }
      }
      return vars;
   }

   private Set<Var> getMathVars(Exp exp) {
      final Set<Var> vars = new HashSet<Var>();
      MathExpVisitor visitor = new MathExpVisitor(vars);

      visitor.visitDispatch(exp);
      return vars;
   }
   */

   private Set<Var> getReadVars(Path path) {
      final Set<Var> writtenVars = new HashSet<Var>();
      final Set<Var> readVars = new HashSet<Var>();
      class ReadExpVisitor implements ExpVisitor {
         public Object visitDispatch(Exp exp) {
            return exp.accept(this);
         }
         @Override
         public Object visit(Val val) {
            return null;
         }

         @Override
         public Object visit(Var var) {
            if (!writtenVars.contains(var))
               readVars.add(var);
            return null;
         }

         @Override
         public Object visit(BinaryExp binaryExp) {
            visitDispatch(binaryExp.operand1);
            visitDispatch(binaryExp.operand2);
            return null;
         }

         @Override
         public Object visit(UMinus minus) {
            visitDispatch(minus.exp);
            return null;
         }

         @Override
         public Object visit(And and) {
            visitDispatch(and.exp1);
            visitDispatch(and.exp2);
            return null;
         }

         @Override
         public Object visit(Or or) {
            visitDispatch(or.exp1);
            visitDispatch(or.exp2);
            return null;
         }

         @Override
         public Object visit(Not not) {
            visitDispatch(not.exp);
            return null;
         }

         @Override
         public Object visit(CallExp callExp) {
            visitDispatch(callExp.receiver);
            for (Varl arg : callExp.args) {
               visitDispatch(arg);
            }
            return null;
         }
      };
      ReadExpVisitor visitor = new ReadExpVisitor();

      for (Step step : path.steps()) {
         if (step instanceof MethodCall) {
            MethodCall call = (MethodCall) step;
            visitor.visitDispatch(call.receiver);
            for (Varl arg : call.args)
               visitor.visitDispatch(arg);
            writtenVars.add(call.ret);
         } else if (step instanceof Assignment) {
            Assignment assign = (Assignment) step;
            visitor.visitDispatch(assign.right);
            writtenVars.add(assign.left);

         } else if (step instanceof Assume) {
            Assume assume = (Assume) step;
            visitor.visitDispatch(assume.exp);
         }
      }
      return readVars;
   }

   // ------------------------------------------------------------
   private boolean checkPaths() {

      if (paths.size() == 0)
         return true;

      SSAPaths();

      printPaths();

      if (log)
         System.out.println("Checking Paths:");

      Text sharedAssertions = genSharedAssertions();

      if (CHECK_ASSERTION_CONSISTENCY) {
         checkConsistency(sharedAssertions, methodName);
      }

      int i = 1;
      for (Path path : paths) {
         if (log)
            System.out.println("\tChecking path " + i);
         //reset ignoreStep
//         ignoreStep = false;

//         boolean b = checkNonNullityOfMath(path, i);
//         if (!b)
//            return false;

         String name = fileName + "_" + i;

         TextSeq seq2 = textFact.newText();
         seq2.add(sharedAssertions);
         Text text2 = genPathUnderTest(path, i);
         seq2.add(text2);
         Text text3 = genConjecture(path);
         seq2.add(text3);
         Text text = seq2.get();

         if (log)
            System.out.println("\t\t...");
         try {
            boolean sat = isSat(text, name, WAIT_SEC);
            if (sat) {
               if (log)
                  System.out.println("\t\tFailed\n");
               return false;
            } else {
               if (log)
                  System.out.println("\t\tPassed\n");
            }
         } catch (TimeoutException e) {
            //System.out.println("The path was not verified in " + WAIT_SEC + " seconds.");
            if (log)
               System.out.println("\t\tFailed\n");
            return false;
         }

         i += 1;
      }
      return true;
   }


   private void checkConsistency(Text sharedAssertions, String methodName) {
      TextSeq seq1 = textFact.newText();
      seq1.add(sharedAssertions);
      seq1.add("(check-sat)\n");
      Text assertions = seq1.get();

      if (CHECK_ASSERTION_CONSISTENCY) {
         if (log)
            System.out.print("\tChecking consistency of assertions ... ");
         try {
//            String name = methodName + "_" + "const";
            String name = fileName + "_" + "x";
            boolean sat = isSat(assertions, name, WAIT_SEC);
            if (sat)
               if (log)
                  System.out.println("passed.");
            else {
               if (log)
                  System.out.println("failed.");
               System.exit(1);
            }
         } catch (RuntimeException e) {
            //System.out.println("No inconsistency found in " + WAIT_SEC + " seconds. ");
         }
      }
   }

   // ------------------------------------------------------------
   private Text genSharedAssertions() {
      TextSeq seq = textFact.newText();

      Text prelude = genPrelude();
      seq.add(prelude);

      Text execInsOuts = genExecInsOuts();
      seq.add(execInsOuts);
      int i = 1;
      for (Path path : paths) {
         //reset ignoreStep
//         ignoreStep = false;

         Text pathExec = genPathAlter(path, i);
         seq.add(pathExec);
         i += 1;
      }

      return seq.get();
   }

   private Text genPrelude() {
      TextSeq seq = textFact.newText();
      seq.add(
            "; ================================================================\n" +
                  "; Prelude {\n" +
                  "\t; Settings\n" +
                  "\t;(set-option :mbqi true)\n" +
                  "\t(set-option :smt.macro-finder true)\n" +
                  "\t(set-option :smt.pull-nested-quantifiers true)\n" +
                  "\t;(set-option :produce-unsat-cores true)\n" +
                  "\n" +
                  "\t; General definitions\n" +
                  "\t(declare-datatypes (T1 T2)\n" +
                  "\t   (\n" +
                  "\t      (Pair\n" +
                  "\t         (newPair (first T1) (second T2))\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +
                  "\t;--------------------------------------------------------------\n" +
                  "\t; Definitions\n" +
                  "\t\n" +
                  "\t(define-sort State () (Int))\n" +
                  "\t(define-sort Var () (Int))\n" +
                  "\t(define-sort String () (Int))\n" +
                  "\t(declare-datatypes ()\n" +
                  "\t   (\n" +
                  "\t      (Val\n" +
                  "\t         null\n" +
                  "\t         (newInt (intVal Int))\n" +
                  "\t         (newBool (boolVal Bool))\n" +
                  "\t         (newString (StringVal String))\n" +
                  "\t      )\n" +
                  "\t      (Varl\n" +
                  "\t         (newVar (unvar Var))\n" +
                  "\t         (newVal (unval Val))\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +
//         "\t(assert\n" +
//         "\t   (forall ((v1 Val) (v2 Val))\n" +
//         "\t      (=>\n" +
//         "\t         (= (intVal v1) (intVal v2))\n" +
//         "\t         (= v1 v2)\n" +
//         "\t      )\n" +
//         "\t   )\n" +
//         "\t)\n" +
//         "\t\n" +
//         "\t(assert\n" +
//         "\t   (forall ((v1 Val) (v2 Val))\n" +
//         "\t      (=>\n" +
//         "\t         (= (boolVal v1) (boolVal v2))\n" +
//         "\t         (= v1 v2)\n" +
//         "\t      )\n" +
//         "\t   )\n" +
//         "\t)\n" +
//         "\t\n" +
                  "\t(declare-fun f (State Val) (Val))\n" +
                  "\t(declare-fun valOfVar (Var) Val)\n" +
                  "\t(define-fun valOfVal ((v Val)) Val\n" +
                  "\t   v\n" +
                  "\t)\n" +
                  "\t(define-fun valOfVarl ((v Varl)) Val\n" +
                  "\t   (ite\n" +
                  "\t      (is-newVar v)\n" +
                  "\t      (valOfVar (unvar v))\n" +
                  "\t      (valOfVal (unval v))\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +
                  "\t;--------------------------------------------------------------\n" +
                  "\t; Method Properties\n" +
                  "\t\n" +

                  "\t(declare-fun get (State Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s State) (k Val) (s^ State) (v Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (get s k) (newPair s^ v))\n" +
                  "\t         (and\n" +
                  "\t            (= s s^)\n" +
                  "\t            (= v (f s k))\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +

//         "\t(declare-fun containsKey (State Val) (Pair State Val))\n" +
//         "\t(assert\n" +
//         "\t   (forall ((s State) (k Val) (s^ State) (v Val))\n" +
//         "\t      (=>\n" +
//         "\t         (= (containsKey s k) (newPair s^ v))\n" +
//         "\t         (= s s^)\n" +
//         "\t      )\n" +
//         "\t   )\n" +
//         "\t)\n" +
//         "\t\n" +
                  "\t(declare-fun put (State Val Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s1 State) (k Val) (v Val) (s2 State) (v^ Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (put s1 k v) (newPair s2 v^))\n" +
                  "\t         (and\n" +
                  "\t            (= v^ (f s1 k))\n" +
                  "\t            (= (f s2 k) v)\n" +
//                  "\t            (forall ((k^ Val)) (=> (not (= k^ k)) (= (f s2 k^) (f s1 k^))))\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +

                  "\t(declare-fun putIfAbsent (State Val Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s1 State) (k Val) (v Val) (s2 State) (v^ Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (putIfAbsent s1 k v) (newPair s2 v^))\n" +
                  "\t         (and\n" +
                  "\t            (= v^ (f s1 k))\n" +
                  "\t            (or\n" +
                  "\t               (and\n" +
                  "\t                  (= (f s1 k) null)\n" +
                  "\t                  (= (f s2 k) v)\n" +
                  "\t                  (forall ((k^ Val)) (=> (not (= k^ k)) (= (f s2 k^) (f s1 k^))))\n" +
                  "\t               )\n" +
                  "\t               (and\n" +
                  "\t                  (not (= (f s1 k) null))\n" +
                  "\t                  (= s1 s2)\n" +
                  "\t               )\n" +
                  "\t            )\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +

                  "\t(declare-fun replace (State Val Val Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s1 State) (k Val) (v Val) (v^ Val) (s2 State) (b Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (replace s1 k v v^) (newPair s2 b))\n" +
                  "\t         (or\n" +
                  "\t            (and\n" +
                  "\t               (not (= (f s1 k) null))\n" +
                  "\t               (= (f s1 k) v)\n" +
                  "\t               (= (f s2 k) v^)\n" +
                  "\t               (forall ((k^ Val)) (=> (not (= k^ k)) (= (f s2 k^) (f s1 k^))))\n" +
                  "\t               (= b (newBool true))\n" +
                  "\t            )\n" +
                  "\t            (and\n" +
                  "\t               (= (f s1 k) null)\n" +
                  "\t               (= s1 s2)\n" +
                  "\t               (= b (newBool false))\n" +
                  "\t            )\n" +
                  "\t            (and\n" +
                  "\t               (not (= (f s1 k) v))\n" +
                  "\t               (= s1 s2)\n" +
                  "\t               (= b (newBool false))\n" +
                  "\t            )\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +

                  "\t(declare-fun remove1 (State Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s1 State) (k Val) (s2 State) (v Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (remove1 s1 k) (newPair s2 v))\n" +
                  "\t         (and\n" +
                  "\t            (= v (f s1 k))\n" +
                  "\t            (or\n" +
                  "\t               (and\n" +
                  "\t                  (= v null)\n" +
                  "\t                  (= s1 s2)\n" +
                  "\t               )\n" +
                  "\t               (and\n" +
                  "\t                  (not (= v null))\n" +
                  "\t                  (= (f s2 k) null)\n" +
//                  "\t            (forall ((k^ Val)) (=> (not (= k^ k)) (= (f s2 k^) (f s1 k^))))\n" +
                  "\t               )\n" +
                  "\t            )\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +

                  "\t(declare-fun size (State) (Pair State Val))\n" +
                  "\t(declare-fun clear (State) (Pair State Val))\n" +
                  "\t\n" +
         /*
         "\t(declare-fun remove2 (State Val) (Pair State Val))\n" +
         "\t(assert\n" +
         "\t   (forall ((s1 State) (k Val) (s2 State) (b Val)\n" +
         "\t            (s3 State) (b1 Val) (s4 State) (b2 Val))\n" +
         "\t      (=>\n" +
         "\t         (and\n" +
         "\t            (= (remove2 s1 k) (newPair s2 b))\n" +
         "\t            (= (get s1 k) (newPair s3 b1))\n" +
         "\t            (= (get s2 k) (newPair s4 b2))\n" +
         "\t         )\n" +
         "\t         (and\n" +
         "\t            (= b b1)\n" +
         "\t            (or\n" +
         "\t               (and\n" +
         "\t                  (= b (newBool true))\n" +
         "\t                  (= b2 (newBool false))\n" +
         "\t               )\n" +
         "\t               (and\n" +
         "\t                  (= b (newBool false))\n" +
         "\t                  (= s1 s2)\n" +
         "\t               )\n" +
         "\t            )\n" +
         "\t         )\n" +
         "\t      )\n" +
         "\t   )\n" +
         "\t)\n"
         */

// ------------------------------------------------------------------------------
// For Set
                  "\t(declare-fun scontains (State Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s1 State) (k Val) (s2 State) (b Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (scontains s1 k) (newPair s2 b))\n" +
                  "\t         (and\n" +
                  "\t            (= s1 s2)\n" +
                  "\t            (= b (newBool (not (= (f s1 k) null))))\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +

                  "\t(declare-fun sremove (State Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s1 State) (k Val) (s2 State) (b Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (sremove s1 k) (newPair s2 b))\n" +
                  "\t         (or\n" +
                  "\t            (and\n" +
                  "\t               (not (= (f s1 k) null))\n" +
                  "\t               (= (f s2 k) null)\n" +
                  "\t               (forall ((k^ Val)) (=> (not (= k^ k)) (= (f s2 k^) (f s1 k^))))\n" +
                  "\t               (= b (newBool true))\n" +
                  "\t            )\n" +
                  "\t            (and\n" +
                  "\t               (= (f s1 k) null)\n" +
                  "\t               (= s1 s2)\n" +
                  "\t               (= b (newBool false))\n" +
                  "\t            )\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n" +

                  "\t(declare-fun sadd (State Val) (Pair State Val))\n" +
                  "\t(assert\n" +
                  "\t   (forall ((s1 State) (k Val) (s2 State) (b Val))\n" +
                  "\t      (=>\n" +
                  "\t         (= (sadd s1 k) (newPair s2 b))\n" +
                  "\t         (or\n" +
                  "\t            (and\n" +
                  "\t               (not (= (f s1 k) null))\n" +
                  "\t               (= s1 s2)\n" +
                  "\t               (= b (newBool false))\n" +
                  "\t            )\n" +
                  "\t            (and\n" +
                  "\t               (= (f s1 k) null)\n" +
                  "\t               (not (= (f s2 k) null))\n" +
                  "\t               (forall ((k^ Val)) (=> (not (= k^ k)) (= (f s2 k^) (f s1 k^))))\n" +
                  "\t               (= b (newBool true))\n" +
                  "\t            )\n" +
                  "\t         )\n" +
                  "\t      )\n" +
                  "\t   )\n" +
                  "\t)\n" +
                  "\t\n"
      );

// ------------------------------------------------------------------------------

      HashMap<String, Set<Integer>> map = new HashMap<String, Set<Integer>>();
      for (MethodSig methodSig : funMethods) {
         int argCount = 0;
         if (!statics.contains(methodSig.object) && !methodSig.argFunctional)
            argCount++;
         argCount += methodSig.argCount;

         Set<Integer> prevCounts = map.get(methodSig.method);
//         System.out.println("----------");
//         System.out.println(methodSig.method);
//         System.out.println(argCount);
//         System.out.println(prevCounts);
//         System.out.println("----------");
         boolean alreadyDefined =
               (prevCounts != null && prevCounts.contains(argCount));

         if (!alreadyDefined) {
            seq.add("\t(declare-fun " + methodSig.method + " (");
            //methodSig.object
            //State Val) (Pair State Val))\n"
            if (!statics.contains(methodSig.object) && !methodSig.argFunctional)
               seq.add("Val");

            if (!statics.contains(methodSig.object) && !methodSig.argFunctional && methodSig.argCount > 0)
               seq.add(" ");

            for (int i = 0; i < methodSig.argCount; i++) {
               seq.add("Val");
               if (i != methodSig.argCount - 1)
                  seq.add(" ");
            }
            seq.add(") (Val))\n");

            if (prevCounts == null) {
               prevCounts = new HashSet<Integer>();
               map.put(methodSig.method, prevCounts);
            }
            prevCounts.add(argCount);
         }

      }

      for (String userLiteral : literals)
         seq.add("\t(declare-const " + userLiteral + " String)\n");

      seq.add(
         "; Prelude }\n" +
         "; ================================================================\n"
      );

      return seq.get();
   }

   private Text genExecInsOuts() {
      TextSeq seq = textFact.newText();
      seq.add(
         "; ================================================================\n" +
         "; Inputs and outputs { \n" +
         "\n"
      );
      for (Param param : params) {
         if (param.isArray)
            seq.add("\t(declare-fun " + param.name + " (Val) Val)\n");
         else
            seq.add("\t(declare-const " + param.name + " Var)\n");
      }

      seq.add("\t(declare-const this" + " Var)\n");

      seq.add(
         "\t(declare-const initState Var)\n" +
         "\t\n" +
         "\t(declare-const retValue Varl)\n" +
         "\t(declare-const retState State)\n" +
         "\t\n"
      );

      seq.add(
         "; Inputs and outputs } \n" +
         "; ================================================================\n" +
         "\n"
      );

      return seq.get();
   }

   private Text genPathAlter(Path path, int p) {


      TextSeq seq = textFact.newText();
      seq.add("; ================================================================\n");
      seq.add("; Path " + p +" Condensation Candidate { \n");

      int numberOfStates = path.getMethodCount();
//      for (Step step : path.steps()) {
//         for (int j = 0; j < AllIgnoredFunctions.size(); j++) {
//            if(AllIgnoredFunctions.get(j).equals(step.toString())) {
//               numberOfStates = numberOfStates - 1;
//            }
//         }
//      }
      seq.add("\t; -------------------------------------------\n");
      seq.add("\t; State Declarations \n");
      Text stateDecls = genStateDecls(numberOfStates, p + "");
      seq.add(stateDecls);

      seq.add("\t; -------------------------------------------\n");
      seq.add("\t; Var Declarations \n");
      Text varDecls = genVarDecls(path, p + "");
      seq.add(varDecls);

      seq.add("\t; -------------------------------------------\n");
      seq.add("\t; Init \n");
      Text init = genInit(p);
      seq.add(init);

      seq.add("\t; -------------------------------------------\n");
      seq.add("\t; Body \n");

      Text body = genBody(path, p + "");
      seq.add(body);

      seq.add("\t; -------------------------------------------\n");
      seq.add("\t; Assumes implies return value\n");

      seq.add(
            "\t(assert\n" +
                  "\t   (=>\n" +
                  "\t      (and\n"
      );

      boolean assumeExists = false;
      MathExp2SMT boolExp2SMT = new MathExp2SMT(p + "");
      for (Step step : path.steps()) {
         if (step instanceof Assume) {
            Exp cond = ((Assume) step).exp;
            seq.add("\t         (boolVal" + boolExp2SMT.translate(cond) + ")\n");
            assumeExists = true;
         }
      }

      if (!assumeExists)
         seq.add("\t         true\n");

//      int last = path.getMethodCount();
//      if (ignoreStep == true) {
//         last = last - functionsIgnored;
//         System.out.println("\n****pathMethodCount = " + last + "***\n");
//      }

      seq.add(
            "\t      )\n\n"
      );

      seq.add(
            "\t      (and\n" +
            "\t         (= (valOfVarl retValue) (valOfVarl p" + p + ".retValue))\n" +
            "\t         (= retState p" + p + ".s" + numberOfStates + ")\n" +
            "\t      )\n" +
            "\t   )\n" +
            "\t)\n"
      );
      seq.add("\t; -------------------------------------------\n");

      seq.add("; Path " + p + " Condensation Candidate } \n");
      seq.add("; ================================================================\n");


      return seq.get();
   }

   private Text genStateDecls(int methodCount, String p) {
      return genStateDecls(methodCount, p, false);
   }
   private Text genStateDecls(int methodCount, String p, boolean separate) {
      TextSeq seq = textFact.newText();

      int count;
      if (separate)
         count = 2 * methodCount;
      else
         count = methodCount + 1;

      if (count == 0)
         count = 1;

      for (int i = 0; i < count; i++) {
         seq.add("\t(declare-const p" + p + ".s" + i + " State)\n");
      }

      return seq.get();
   }

   private Text genVarDecl(String var, String p) {
      return new Snippet(
            "\t(declare-const p" + p + "." + var + " Var)\n"
      );
   }

   private Text genVarDecls(Path path, String p) {
      TextSeq seq = textFact.newText();

      Set<String> paramSet = new HashSet<String>();
      for (Param param : params) {
         if (param.isArray)
            seq.add("\t(declare-fun p" + p + "." + param.name + " (Val) Val)\n");
         else
            seq.add("\t(declare-const p" + p + "." + param.name + " Var)\n");
         paramSet.add(param.name);
      }

      Set<Var> vars = new HashSet<Var>();
      vars.addAll(getReadVars(path));
      vars.addAll(getWrittenVars(path));

//      for (Step step : path.steps()) {
//
//         if (step instanceof MethodCall) {
//            MethodCall methodCall = (MethodCall) step;
//            for (Varl varl : methodCall.args) {
//               if (varl instanceof Var) {
//                  Var var = (Var) varl;
//                  if (!paramSet.contains(var.name))
//                     vars.add(var.name);
//               }
//            }
//            vars.add(methodCall.ret.name);
//
//         } else if (step instanceof Assignment) {
//            Assignment assignment = (Assignment) step;
//            if (!paramSet.contains(assignment.left.name))
//               vars.add(assignment.left.name);
//         }
//      }

      vars.add(new Var("this"));

//      OUTER:
      for (Var var : vars) {
//         for (MethodSig funMethod : funMethods) {
//            if (funMethod.object.equals("Sys") &&
//                funMethod.method.equals(var))
//               continue OUTER;
//         }
         if (!paramSet.contains(var.name))
            seq.add(genVarDecl(var.name, p));
      }

      seq.add("\t(declare-const p" + p + ".retValue Varl)\n\n");

      return seq.get();
   }

   private String printVarl(Varl varl, String p) {
      if (varl instanceof NullVal)
         return "(newVal null)";
      else if (varl instanceof IntVal)
         return "(newVal (newInt " + varl.toString() + "))";
      else if (varl instanceof BoolVal)
         return "(newVal (newBool " + varl.toString() + "))";
      else if (varl instanceof StringVal)
         return "(newVal (newString Literal_" +
               varl.toString().replace(" ", "_").replace("\"","").replace("'","") + "))";
      else // if (varl instanceof Var)
         return "(newVar p" + p + "." + varl + ")";
   }

   private String printValOfVarl(Varl varl, String p) {
      if (varl instanceof NullVal)
         return "null";
      else if (varl instanceof IntVal)
         return "(newInt " + varl.toString() + ")";
      else if (varl instanceof BoolVal)
         return "(newBool " + varl.toString() + ")";
      else if (varl instanceof StringVal)
         return "(newString Literal_" +
               varl.toString().replace(" ", "_").replace("\"","").replace("'","") + ")";
      else // if (varl instanceof Var)
         return "(valOfVar p" + p + "." + varl + ")";
   }

   private Text genInit(int p) {
      TextSeq seq = textFact.newText();

      seq.add("\t;--------------------------------------------------------------\n");
      seq.add("\n");

      for (Param param : params) {
         if (!param.isArray)
            seq.add(
               "\t(assert\n" +
               "\t   (=\n" +
               "\t      p" + p + "." + param.name +"\n" +
               "\t      " + param.name + "\n" +
               "\t   )\n" +
               "\t)\n"
            );
         else
            seq.add(
               "\t(assert\n" +
               "\t   (forall ((i Val))\n" +
               "\t      (=\n" +
               "\t         (p" + p + "." + param.name +" i)\n" +
               "\t         (" + param.name + " i)\n" +
               "\t      )\n" +
               "\t   )\n" +
               "\t)\n"
            );
      }

//      seq.add(
//            "\t(assert\n" +
//            "\t   (=\n" +
//            "\t      p" + p + ".this" +"\n" +
//            "\t      this" + "\n" +
//            "\t   )\n" +
//            "\t)\n"
//      );

      seq.add(
            "\t(assert\n" +
            "\t   (=\n" +
            "\t      p" + p + ".s0\n" +
            "\t      initState\n" +
            "\t   )\n" +
            "\t)\n" +
            "\n"
      );

      return seq.get();
   }

   private Text genBody(Path path, final String p) {
      return genBody(path, p, false);
   }
   private Text genBody(Path path, final String p, boolean separate) {

      Set<Var> vars = getObjectWrittenVars(path);
//      System.out.println("Vars = " + vars);
//      Set<Var> mathVars = getMathVars(path);
//      System.out.println("MathVars = " + mathVars);
//      vars.retainAll(mathVars);

      final TextSeq seq = textFact.newText();

      int i = 0;
      for (Step step : path.steps()) {
         if (step instanceof MethodCall) {
            MethodCall methodCall = (MethodCall) step;
            if (methodCall.name.equals("containsKey")) {
               Text text = genTransMethodCall(methodCall, p, i, separate);
               seq.add(text);
            } else {
               Text text = genMethodCall(p, i, methodCall, separate);
               seq.add(text);
            }
            i += 1;
         } else if (step instanceof Assignment) {
            Text text = genAssignment(p, (Assignment) step, vars);
            seq.add(text);
         }
      }
      seq.add("\t; --------------------------------------\n");
      seq.add("\t; Return value\n");

      Option<Varl> retV = path.retV();
      Text text = genRetV(p, retV);
      seq.add(text);

      return seq.get();
   }

   private Text genTransMethodCall(MethodCall methodCall, String p, int i, boolean separate) {
      // m.containsKey() is translated to (m.get() != null)

      final TextSeq seq = textFact.newText();

      if (methodCall.name.equals("containsKey")) {
         String newVarName = methodCall.ret.name + "^^";
         Var newVar = new Var(newVarName);

         seq.add(genVarDecl(newVarName, p));

         MethodCall getMethodCall = new MethodCall(
               methodCall.receiver,
               "get",
               methodCall.args,
               newVar
         );
         Text text1 = genMethodCall(p, i, getMethodCall, separate);
         seq.add(text1);

         Assignment assignment = new Assignment(
               methodCall.ret,
               new Not(new Equality(newVar, new NullVal()))
         );
         Text text2 = genAssignment(p, assignment, new HashSet<Var>());
         seq.add(text2);
      }

      return seq.get();
   }

   private Text genMethodCall(String p, int i, MethodCall methodCall) {
      return genMethodCall(p, i, methodCall, false);
   }
   private Text genMethodCall(String p, int i, MethodCall methodCall, boolean separate) {

      TextSeq seq = textFact.newText();

      seq.add("\t; --------------------------------------------\n");

      int preState;
      if (separate)
         preState = 2*i; // - functionsIgnored;
      else
         preState = i; // - functionsIgnored;

      int postState;
      if (separate)
         postState = 2*i+1;// - functionsIgnored;
      else
         postState = i + 1;// - functionsIgnored;

      seq.add("\t; " + methodCall.toString() + "\n");

//      if (!methodCall.toString().contains(dummyFunctionString)) {
//      if (methodCall.receiver.name.equals(baseObject)) {
      if (equalBaseObject(methodCall.receiver, baseObject)) {

         String name = methodCall.name;
         if (name.equals("remove") && !baseObjectIsSet)
            name += methodCall.args.length;
         if (baseObjectIsSet)
            name = "s" + name;

   //      if (ignoreStep == true) {
   //         if(separate)
   //            preState = preState - 2*functionsIgnored;
   //         else
   //            preState = preState - functionsIgnored;
   //         System.out.println("\n****preState = " + preState + "***\n");
   //      }

         seq.add(
            "\t(assert\n" +
            "\t   (=\n" +
            "\t      (" + name + "\n" +
            "\t         p" + p +".s" + preState + "\n"
         );

         for (Varl arg : methodCall.args) {
            String varlS = printValOfVarl(arg, p);
            seq.add("\t         " + varlS + "\n");
         }

   //      if(ignoreStep == true) {
   //         if(separate)
   //            postState = postState - 2*functionsIgnored;
   //         else
   //            postState = postState - functionsIgnored;
   //      }

         seq.add(
               "\t      )\n" +
               "\t      (newPair\n" +
               "\t         p" + p + ".s" + postState + "\n" +
               "\t         (valOfVar p" + p + "." + methodCall.ret + ")\n" +
               "\t      )\n" +
               "\t   )\n" +
               "\t)\n" +
               "\n"
         );

      } else {
//         System.out.println("-------------------");

         String methodName = methodCall.name;
         String receiverName = methodCall.receiver.name;

         boolean isStatic = statics.contains(receiverName);
         int argCount = methodCall.args.length;
         boolean isArgFunctional = false;
//         System.out.println(funMethods);
         for (MethodSig funMethod : funMethods) {
            if (funMethod.method.equals(methodName) &&
                funMethod.object.equals(receiverName)) {
               isArgFunctional = funMethod.argFunctional;
//               System.out.println("Found ArgFun");
//               System.out.println(isArgFunctional);
//               System.out.println(methodCall);
               break;
            }
         }

         seq.add(
               "\t(assert\n" +
               "\t   (=\n");

         if (!isStatic && !isArgFunctional)
            argCount++;

         if (argCount > 0) {
            if (!methodName.equals("equals"))
               seq.add(
                  "\t      (" + methodName + "\n"
               );
            else
               seq.add(
                  "\t      (newBool (=" + "\n"
               );


            if (!isStatic && !isArgFunctional)
               seq.add("\t         (valOfVar p" + p + "." + receiverName + ")\n");

            for (Varl arg : methodCall.args) {
               String varlS = printValOfVarl(arg, p);

               seq.add("\t         " + varlS + "\n");
            }
            if (!methodName.equals("equals"))
               seq.add(
                  "\t      )\n"
               );
            else {
               seq.add(
                  "\t      ))\n"
               );
            }

         } else {
            seq.add(
               "\t      " + methodName + "\n"
            );
         }

         seq.add(
               "\t      (valOfVar p" + p + "." + methodCall.ret + ")\n" +
               "\t   )\n" +
               "\t)\n" +
               "\n"
         );
         if (methodName.equals("equals")) {
            seq.add("\t(assert\n");
            seq.add("\t\t(is-newBool (valOfVar p" + p + "." +
                  methodCall.ret.name + "))\n");
            seq.add("\t)\n");
         }

         seq.add(
               "\t(assert\n" +
               "\t   (=\n" +
               "\t      p" + p +".s" + preState + "\n" +
               "\t      p" + p +".s" + postState + "\n" +
               "\t   )\n" +
               "\t)\n"
         );

      }
      seq.add("\t; --------------------------------------------\n");
      return seq.get();
   }

   private Text genAssignment(String p, Assignment assignment, Set<Var> vars) {

      //Set<Var> objectVars = new HashSet<Var>(vars);
      //Set<Var> mathVars = getMathVars(assignment.right);
      //objectVars.retainAll(mathVars);

      TextSeq seq = textFact.newText();
      MathExp2SMT exp2SMT = new MathExp2SMT(p);
//      Assignment assignment = (Assignment) step;

      seq.add("\t; " + assignment.toString() + "\n");
      seq.add(
         "\t(assert\n"
      );

      /*
      if (objectVars.size() != 0) {
         seq.add(
            "\t   (=>\n"
         );

         seq.add(
            "\t      (and\n"
         );
         for (Var var : objectVars) {
            seq.add(
               "\t         (not (= (valOfVar p" + p + "." + var.name + ") null))\n"
            );
         }
         seq.add(
            "\t      )\n"
         );
      }
      */

      seq.add(
         "\t\t(=\n"
      );

      seq.add("\t\t\t" + exp2SMT.translate(assignment.left) + "\n");
      seq.add("\t\t\t" + exp2SMT.translate(assignment.right) + "\n");

      seq.add(
         "\t\t)\n"
      );

      /*
      if (objectVars.size() != 0)
         seq.add(
            "\t   )\n"
         );
      */

      seq.add(
         "\t)\n"
      );

      return seq.get();
   }

   private Text genRetV(final String p, Option<Varl> retV) {
      TextSeq seq = textFact.newText();
      String retS = retV.option(
            "(newVal (newInt 1))",
            new F<Varl, String>() {
               @Override
               public String f(Varl varl) {
                  return printVarl(varl, p);
               }
            }
      );
      seq.add(
            "\t(assert\n" +
                  "\t   (=\n" +
                  "\t      p" + p + ".retValue\n" +
                  "\t      " + retS + "\n" +
                  "\t   )\n" +
                  "\t)\n"
      );
      return seq.get();
   }

   // ------------------------------------------------------------
   private int linMethodHeuristic(Path path) {
      int linMethod = -1;
      int i = 0;
      for (Step step : path.steps()) {
         if (step instanceof MethodCall) {
            MethodCall methodCall = (MethodCall) step;
            final String name = methodCall.name;

            if (equalBaseObject(methodCall.receiver, baseObject) &&
                mutatorMethods.contains(name)) {
               // Giving priority to later mutator methods.
               linMethod = i;
            }
            i += 1;
         }
      }
      if (linMethod != -1)
         return linMethod;

      // If there is no mutator method, take an accessor.
      i = 0;
      for (Step step : path.steps()) {
         if (step instanceof MethodCall) {
            MethodCall methodCall = (MethodCall) step;
            if (equalBaseObject(methodCall.receiver, baseObject)) {
               linMethod = i;
               break;
            }
            i += 1;
         }
      }

      return linMethod;
   }

   private Text genPathUnderTest(Path path, int p) {

      TextSeq seq = textFact.newText();

      int linMethod = linMethodHeuristic(path);
      if (linMethod != -1) {
         int j = -1;
         int i = 0;
         while (true) {
            j += 1;
            Step step = path.steps().index(j);
            if (step instanceof MethodCall) {
               if (i == linMethod) {
                  if (log)
                     System.out.println(
                        "\t\tCondensing at step " + j + ": " + step
                     );
                  break;
               }
               i += 1;
            }
         }
      }



      seq.add("; ================================================================\n");
      seq.add("; Path " + p + " Under Test { \n");

      //needed to count the number of states needed after removing
      //the states from the ignored functions of the other objects
      int numberOfStates = path.getMethodCount();
//      for (Step step : path.steps()) {
//         for(int j = 0; j < AllIgnoredFunctions.size(); j++) {
//            if(AllIgnoredFunctions.get(j).equals(step.toString())) {
//               numberOfStates = numberOfStates - 1;
//               System.out.println("numberOfStates = " + numberOfStates);
//            }
//         }
//      }

      Text stateDecls = genStateDecls(numberOfStates, "", true);
      seq.add(stateDecls);

      Text varDecls = genVarDecls(path, "");
      seq.add(varDecls);

      for (Param param : params) {
         if (!param.isArray)
            seq.add(
               "\t(assert\n" +
               "\t   (=\n" +
               "\t      p." + param.name + "\n" +
               "\t      " + param.name + "\n" +
               "\t   )\n" +
               "\t)\n"
            );
         else
            seq.add(
               "\t(assert\n" +
               "\t   (forall ((i Val))\n" +
               "\t      (=\n" +
               "\t         (p" + p + "." + param.name +" i)\n" +
               "\t         (" + param.name + " i)\n" +
               "\t      )\n" +
               "\t   )\n" +
               "\t)\n"
            );
      }

//      seq.add(
//         "\t(assert\n" +
//         "\t   (=\n" +
//         "\t      p.this\n" +
//         "\t      this\n" +
//         "\t   )\n" +
//         "\t)\n"
//      );

      Text body = genBody(path, "", true);
      seq.add(body);

      seq.add("\t; Assumes\n");

      MathExp2SMT boolExp2SMT = new MathExp2SMT("");
      for (Step step : path.steps()) {
         if (step instanceof Assume) {
            seq.add("\t(assert (boolVal \n");
            Assume assume = (Assume) step;
            Exp cond = assume.exp;
            seq.add("\t   " + boolExp2SMT.translate(cond) + "\n");
            seq.add("\t))\n");
         }
      }

      int last = 2*linMethod;
      /*
      if(ignoreStep == true)
      {
    	  last = last - functionsIgnored;
    	  System.out.println("\n****last = " + last + "***\n");
    	  seq.add(";------the state below was (-) by " + functionsIgnored + "\n");
      }*/

//      System.out.println("linMethod is " + linMethod);
      if (linMethod != -1)
         seq.add(
            "\t(assert\n" +
            "\t   (=\n" +
            "\t      initState\n" +
            "\t      p.s" + last + "\n" +
            "\t   )\n" +
            "\t)\n"
         );

//      BoolExp2SMT boolExp2SMT = new BoolExp2SMT("");
//      seq.add(
//         "(assert\n" +
//         "   (and\n"
//      );
//
//      boolean assumeExists = false;
//      for (Step step : path.steps()) {
//         if (step instanceof Assume) {
//            Assume assume = (Assume) step;
//            Exp cond = assume.exp;
//            seq.add("      " + boolExp2SMT.translate(cond) + "\n");
//            assumeExists = true;
//         }
//      }
//
//      if (!assumeExists)
//         seq.add("      true\n");
//
//      seq.add(
//         "   )\n" +
//         ")\n"
//      );
      seq.add("; Path " + p  + " Under Test } \n");
      seq.add("; ================================================================\n");

      return seq.get();
   }

   public Text genConjecture(Path path) {
      //needed to update the states here to ignore the states of the functions
      //that were ignored
      //fixes "define-fun conjecture () Bool"
      TextSeq seq = textFact.newText();

      int linMethod = linMethodHeuristic(path);

      seq.add(
         "(define-fun conjecture () Bool\n" +
         "   (and\n"
      );

      int pathMethodCount = path.getMethodCount();
//      if(ignoreStep == true) {
//         pathMethodCount = pathMethodCount - functionsIgnored;
//      }

      for (int j = 0; j < pathMethodCount; j++) {
         if (j != linMethod) {
            seq.add("      (= p.s" + (2*j) + " p.s" + (2*j+1) + ")\n");
         }
      }

      //int last = 2 * path.getMethodCount() - 1 ;
//      int last = 2 * pathMethodCount - 1 ;
//      if (last < 0)
//         last = 0;
      int last = 2 * linMethod + 1;

      seq.add(
         "      (= (valOfVarl retValue) (valOfVarl p.retValue))\n");

      if (linMethod != -1)
         seq.add(
            "      (= retState p.s" + last + ")\n"
         );

      /*
      Set<Var> vars = getObjectWrittenVars(path);
      System.out.println("Vars = " + vars);
      Set<Var> mathVars = getMathVars(path);
      System.out.println("MathVars = " + mathVars);
      vars.retainAll(mathVars);
      System.out.println("Vars = " + vars);

      for (Var var : vars) {
         seq.add(
            "      (not (= (valOfVar p." + var.name + ") null))\n"
         );
      }
      */

      seq.add(
         "   )\n" +
         ")\n" +
         "(assert (not conjecture))\n" +
         "(check-sat)\n"
      );

      return seq.get();
   }

   // ------------------------------------------------------------

   private Text genPurityPath(Path path, int p) {

      TextSeq seq = textFact.newText();

      seq.add("; ================================================================\n");
      seq.add("; Purity Path " + p + " { \n");

      int numberOfStates = path.getMethodCount();

      Text stateDecls = genStateDecls(numberOfStates, "", true);
      seq.add(stateDecls);

      Text varDecls = genVarDecls(path, "");
      seq.add(varDecls);

      Text body = genBody(path, "", true);
      seq.add(body);

      seq.add("\t; Assumes\n");

      MathExp2SMT boolExp2SMT = new MathExp2SMT("");
      for (Step step : path.steps()) {
         if (step instanceof Assume) {
            seq.add("\t(assert (boolVal \n");
            Assume assume = (Assume) step;
            Exp cond = assume.exp;
            seq.add("\t   " + boolExp2SMT.translate(cond) + "\n");
            seq.add("\t))\n");
         }
      }

      seq.add("; Purity Path " + p  + " } \n");
      seq.add("; ================================================================\n");

      return seq.get();
   }

   public Text genPurityConjecture(Path path) {
      TextSeq seq = textFact.newText();

      seq.add(
            "(define-fun conjecture () Bool\n" +
            "   (and\n"
      );

      int pathMethodCount = path.getMethodCount();

      for (int j = 0; j < pathMethodCount; j++) {
         seq.add("      (= p.s" + (2*j) + " p.s" + (2*j+1) + ")\n");
      }

      seq.add(
         "   )\n" +
         ")\n" +
         "(assert (not conjecture))\n" +
         "(check-sat)\n"
      );

      return seq.get();
   }


   // ------------------------------------------------------------

   private Boolean isSat(Printable printable, String baseName) {
      return isSat(printable, baseName, 0);
   }
   class TimeoutException extends RuntimeException {}
   private Boolean isSat(Printable printable, String baseName, int waitSec) {
      try {
         //System.out.println("\n\nprocessDir == " + processDir + "\n\n");
         String smt2FilePath = processDir + "src/" + baseName + ".smt2";
         String z3OutFilePath = processDir + "out/" + baseName + ".txt";
         File smt2File = new File(smt2FilePath);
         PrintWriter writer = new PrintWriter(new FileOutputStream(smt2File));
         printable.print(writer);
         writer.close();

         // String z3FilePath = processDir + baseName + "out";

         String[] command = {
               processDir + "RunScript.sh",
               smt2FilePath, z3OutFilePath};
//         String[] command = {"/home/lesani/Prog/Command/lz3", name};
//         String[] command = {"lz3", name};
//         String[] command = {"echo", "$PATH"};
//         String[] command = {"ls"};
         ProcessBuilder builder = new ProcessBuilder(command);
         builder.directory(new File(processDir));
//         for (String s : builder.command()) {
//            System.out.println(s);
//         }
//         Map<String, String> env = builder.environment();
//         env.put("PATH", "/home/lesani/Prog/Command/");
         Process process = builder.start();

//         process.waitFor();
//         FileInputStream inputStream = new FileInputStream(z3OutFilePath);

         InputStream inputStream = process.getInputStream();
         if (waitSec != 0) {
            long start = System.currentTimeMillis();
            int c = inputStream.available();
            while (c == 0) {
               Thread.yield();
               long now = System.currentTimeMillis();
               if (now - start > waitSec * 1000) {
                  inputStream.close();
                  process.destroy();
                  // destroy is not enough.
                  String[] command2 = {processDir + "KillScript.sh"};
                  builder = new ProcessBuilder(command2);
                  builder.directory(new File(processDir));
                  Process killProcess = builder.start();
                  killProcess.waitFor();
                  throw new TimeoutException();
               }
               c = inputStream.available();
            }
         }

         Scanner scanner = new Scanner(inputStream);
         String line = "";
         boolean firstLine = true;
//         boolean errorExists = false;
         while (scanner.hasNext()) {
            line = scanner.nextLine();
            if (firstLine && !line.equals("sat") && !line.equals("unsat"))
               break;
//            System.out.println(line);
            firstLine = false;
         }
         inputStream.close();
         scanner.close();

         if (line.equals("sat"))
            return true;
         else if (line.equals("unsat"))
            return false;
         else {
            process.destroy();
            inputStream = new FileInputStream(z3OutFilePath);
            scanner = new Scanner(inputStream);
            if (!scanner.hasNext())
               System.out.println("No line from z3.");
            System.out.println();
            while (scanner.hasNext())
               System.out.println(scanner.nextLine());
            inputStream.close();
            scanner.close();

            throw new RuntimeException("Error in the generated z3 file.\n" + z3OutFilePath + "\n");
         }
      } catch (Exception e) {
         if (e instanceof TimeoutException)
            throw (TimeoutException)e;

         System.out.println("Error with z3: " + e.getMessage());
         e.printStackTrace(System.out);

         System.exit(1);
         return null;
      }
   }

   // ------------------------------------------------------------


   class MathExp2SMT implements ExpVisitor<String> {
      String p;
      MathExp2SMT(String p) {
         this.p = p;
      }

      public String translate(Exp exp) {
         return visitDispatch(exp);
      }

      private String visitDispatch(Exp exp) {
         return exp.accept(this);
      }

      ValVisitor<String> valVisitor = new ValVisitor<String>() {
         public String visit(IntVal intVal) {
            return "(newInt " + intVal.toString() + ")";
         }

         public String visit(BoolVal boolVal) {
            return "(newBool " + boolVal.toString() + ")";
         }

         public String visit(StringVal stringVal) {
            return "(newString " + stringVal.toString() + ")";
         }

         public String visit(NullVal boolVal) {
            return "null";
         }
      };
      public String visit(Val val) {
         return val.accept(valVisitor);
      }

      public String visit(Var var) {
//         return "(intVal (valOfVar p" + p + "." + var.name + "))";
         return "(valOfVar p" + p + "." + var.name + ")";
      }

      // Todo: Have visitor here
      public String visit(BinaryExp binaryExp) {
         if (binaryExp instanceof Plus || binaryExp instanceof Minus) {
            String s1 = visitDispatch(binaryExp.operand1);
            String s2 = visitDispatch(binaryExp.operand2);
//            return "(" + binaryExp.operator() + " " +
//                         s1 + " " +
//                         s2 + ")";
            return "(newInt (" + binaryExp.operator() + " " +
                   "(intVal " + s1 + ") " +
                   "(intVal " + s2 + ")))";
         } else if (binaryExp instanceof Equality) {
            String s1 = visitDispatch(binaryExp.operand1);
            String s2 = visitDispatch(binaryExp.operand2);
//            return "(" + binaryExp.operator() + " " +
//                         s1 + " " +
//                         s2 + ")";
            return "(newBool (= " + s1 + " " + s2 + "))";
         } else if (binaryExp instanceof Inequality) {
            String s1 = visitDispatch(binaryExp.operand1);
            String s2 = visitDispatch(binaryExp.operand2);
//            return "(" + binaryExp.operator() + " " +
//                         s1 + " " +
//                         s2 + ")";
            return "(newBool (not (= " + s1 + " " + s2 + ")))";
         } else {
            throw new RuntimeException("Unknown operation in math conditions.");
         }
      }

      public String visit(UMinus minus) {
         String s = visitDispatch(minus.exp);
         return "(newInt (-" +
                "(intVal " + s + ")))";
      }

      public String visit(And and) {
         String s1 = visitDispatch(and.exp1);
         String s2 = visitDispatch(and.exp2);
         return "(newBool (and " +
               "(boolVal " + s1 + ") " +
               "(boolVal " + s2 + ")))";
      }

      public String visit(Or or) {
         String s1 = visitDispatch(or.exp1);
         String s2 = visitDispatch(or.exp2);
         return "(newBool (or " +
               "(boolVal " + s1 + ") " +
               "(boolVal " + s2 + ")))";
      }

      public String visit(Not not) {
         String s = visitDispatch(not.exp);
         return "(newBool (not (boolVal" + s + ")))";
      }

      public String visit(CallExp callExp) {
         String name = callExp.name;
         if (name.equals("equals")) {
            Varl operand1 = callExp.receiver;
            Varl operand2 = callExp.args[0];
            return visitDispatch(new Equality(operand1, operand2));
         } else
            throw new RuntimeException(
                  "CallExp " + callExp + " in math.");
      }
   }

   // ------------------------------------------------------------

}



