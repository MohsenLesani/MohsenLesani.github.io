package cocheck.types;

import polyglot.ext.jl5.types.JL5TypeSystem_c;
import polyglot.types.*;

public class COCheckTypeSystem_c extends JL5TypeSystem_c implements COCheckTypeSystem {
    // TODO: implement new methods in COCheckTypeSystem.
    // TODO: override methods as needed from TypeSystem_c.
}
