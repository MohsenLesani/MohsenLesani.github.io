package cocheck.types;

import polyglot.types.*;

public interface COCheckTypeSystem extends TypeSystem {
    // TODO: declare any new methods needed
}
