package cocheck;

import polyglot.ext.jl5.JL5Scheduler;
//import polyglot.ext.jl5.parse.Grm;
import polyglot.ext.jl5.parse.Lexer_c;
import polyglot.frontend.goals.Goal;
import polyglot.lex.Lexer;
//import cocheck.parse.Lexer_c;
import cocheck.parse.Grm;
import cocheck.ast.*;
import cocheck.types.*;

import polyglot.ast.*;
import polyglot.types.*;
import polyglot.util.*;
import polyglot.frontend.*;

import java.io.*;

/**
 * Extension information for COCheck extension.
 */
public class ExtensionInfo extends polyglot.ext.jl5.ExtensionInfo {
    static {
        // force Topics to load
        Topics t = new Topics();
    }

    public String defaultFileExtension() {
        return "java";
    }

    public String compilerName() {
        return "COCheckc";
    }

    public Parser parser(Reader reader, FileSource source, ErrorQueue eq) {
        Lexer lexer = new Lexer_c(reader, source, eq);
        Grm grm = new Grm(lexer, ts, nf, eq);
        return new CupParser(grm, source, eq);
    }

    protected NodeFactory createNodeFactory() {
        return new COCheckNodeFactory_c();
    }

    protected TypeSystem createTypeSystem() {
        return new COCheckTypeSystem_c();
    }

//   @Override
   public Scheduler scheduler() {
//      System.out.println("Creating scheduler");
      if (scheduler == null)
          scheduler = new COScheduler(this);
      return scheduler;
   }

   public Goal getCompileGoal(Job job) {
       return ((COScheduler) scheduler).MyVisit(job);
   }


//   @Override
//   protected Scheduler createScheduler() {
//      return new COScheduler(this);
//   }
}

