package cocheck;

import polyglot.main.Report;

/**
 * Extension information for COCheck extension.
 */
public class Topics {
    public static final String COCheck = "COCheck";

    static {
        Report.topics.add(COCheck);
    }
}
