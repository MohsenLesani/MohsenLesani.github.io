package cocheck;

import polyglot.ast.NodeFactory;
import polyglot.ext.jl5.JL5Scheduler;
import polyglot.frontend.CyclicDependencyException;
import polyglot.frontend.Job;
import polyglot.frontend.goals.Goal;
import polyglot.frontend.goals.VisitorGoal;
import polyglot.types.TypeSystem;
import polyglot.util.InternalCompilerError;

public class COScheduler extends JL5Scheduler {

   public COScheduler(ExtensionInfo extensionInfo) {
      super(extensionInfo);
   }

   public Goal MyVisit(Job job) {
      TypeSystem ts = extInfo.typeSystem();
      NodeFactory nf = extInfo.nodeFactory();
//      Goal g = new VisitorGoal(job, new MethodVisitor(job, ts, nf));
      Goal g = new VisitorGoal(job, new AtomicityVisitor());
      try {
         g.addPrerequisiteGoal(Parsed(job), this);
//         g.addPrerequisiteGoal(TypeChecked(job), this);
//         g.addPrerequisiteGoal(AnnotationCheck(job), this);
//         g.addPrerequisiteGoal(TypeClosure(job), this);
//         g.addPrerequisiteGoal(AutoBoxing(job), this);
//         g.addPrerequisiteGoal(RemoveExtendedFors(job), this);
      }
      catch (CyclicDependencyException e) {
         throw new InternalCompilerError(e);
      }
      return this.internGoal(g);
   }

//   public Goal CastsInserted(Job job) {
//       TypeSystem ts = extInfo.typeSystem();
//       NodeFactory nf = extInfo.nodeFactory();
//       Goal g = new VisitorGoal(job, new TVCaster(job, ts, nf));
//       try {
//           g.addPrerequisiteGoal(TypeChecked(job), this);
//           g.addPrerequisiteGoal(AnnotationCheck(job), this);
//           g.addPrerequisiteGoal(TypeClosure(job), this);
//           g.addPrerequisiteGoal(AutoBoxing(job), this);
//           g.addPrerequisiteGoal(RemoveExtendedFors(job), this);
//           g.addPrerequisiteGoal(MyVisit(job), this);
//       }
//       catch (CyclicDependencyException e) {
//           throw new InternalCompilerError(e);
//       }
//       return this.internGoal(g);
//   }

}

