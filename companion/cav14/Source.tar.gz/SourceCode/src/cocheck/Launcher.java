package cocheck;

import java.io.*;
import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Launcher {

   public static void main(String[] args) {
      // For warmup
      System.out.println("Warmup Run");
      main2(args);

      System.out.println("Measure Run");
      main2(args);
   }
   public static void main2(String[] args) {

      final String testDir = Settings.testDir;

      final String sourceDir = testDir + "src/";
      final String outDir = testDir + "out/";

      final String benchmarks[] = {

// ------------------------------------------
// Linearizable benchmarks
            "example13.java",
            "example29.java",
            "example30.java",
            "example31.java",
            "example36.java",
            "example37.java",
            "example39.java",
            "example44.java",
            "example48.java",
            "example56.java",
            "example63.java",
            "example69.java",
            "example70.java",
            "example72.java",
            "example73.java",
            "example74.java",
            "example75.java",
            "example76.java",
            "example77.java",
            "example78.java",
            "example80.java",
            "example81.java",
            "example85.java",
            "example92.java",
            "example93.java",
            "example111.java",

// Non-Linearizable benchmarks
            "example1.java",
            "example2.java",
            "example3.java",
            "example4.java",
            "example5.java",
            "example6.java",
            "example7.java",
            "example8.java",
            "example9.java",
            "example10.java",
            "example11.java",
            "example12.java",
            "example14.java",
            "example15.java",
            "example16.java",
            "example17.java",
            "example18.java",
            "example19.java",
            "example20.java",
            "example21.java",
            "example22.java",
            "example23.java",
            "example24.java",
            "example25.java",
            "example26.java",
            "example27.java",
            "example28.java",
            "example32.java",
            "example33.java",
            "example34.java",
            "example35.java",
            "example38.java",
            "example40.java",
            "example41.java",
            "example42.java",
            "example43.java",
            "example45.java",
            "example46.java",
            "example47.java",
            "example49.java",
            "example50.java",
            "example51.java",
            "example52.java",
            "example53.java",
            "example54.java",
            "example55.java",
            "example57.java",
            "example58.java",
            "example59.java",
            "example60.java",
            "example61.java",
            "example62.java",
            "example64.java",
            "example65.java",
            "example66.java",
            "example67.java",
            "example68.java",
            "example71.java",
            "example79.java",
            "example82.java",
            "example83.java",
            "example84.java",
            "example86.java",
            "example87.java",
            "example88.java",
            "example89.java",
            "example90.java",
            "example91.java",
            "example94.java",
            "example95.java",
            "example96.java",
            "example97.java",
            "example98.java",
            "example99.java",
            "example100.java",
            "example101.java",
            "example102.java",
            "example103.java",
            "example104.java",
            "example105.java",
            "example106.java",
            "example107.java",
            "example108.java",
            "example109.java",
            "example110.java",
            "example112.java",

// ------------------------------------------
// Linearizable benchmarks (Added)
//            "XInc1.java",
//            "XInc2.java",
//            "XInc3.java",
//            "XInc4.java",
//            "XInc5.java",
//            "XRemove1.java",
//            "XRemove2.java",
//            "XRemove3.java",
//            "XToggle.java",
//            "XMemoize1.java",
//            "XMemoize2.java",
//            "XMemoize3.java",
//            "example5b.java",
//            "example7b.java",
//            "example54b.java",
//            "example57b.java",
//            "example58b.java",
//            "example64b.java",
//            "example68b.java",
//            "example71b.java",
//            "example84b.java",
//            "example89b.java",
//            "example91b.java",
//            "example96b.java",

//------------------------------------------
// Non-Linearizable benchmarks (Added)
//         "XIncX1.java",
//         "XMemoizeX1.java",
//         "XMemoizeX1b.java",
//         "XMemoizeX2.java",
//         "XMemoizeX3.java",
//         "XRemoveX1.java",
//         "example103b.java",



// ------------------------------------------
      };


//      ArrayList<String> benchmarks = new ArrayList<String>();
//      for(int i = 1; i <= 10; i++)
//         benchmarks.add("example" + i + ".java");

      boolean log = Settings.log;

      class BenchmarkInfo {
         public String name;
         public long time;
         public int purityPathCount;
         public int pathCount;
         public boolean verifiedAtomic;
         public boolean annotatedAtomic;

         @Override
         public String toString() {
            return "BenchmarkInfo{" +
                  "name='" + name + '\'' +
                  ", time=" + time +
                  ", purityPathCount=" + purityPathCount +
                  ", pathCount=" + pathCount +
                  ", verifiedAtomic=" + verifiedAtomic +
                  ", annotatedAtomic=" + annotatedAtomic +
                  '}';
         }
      }
      LinkedList<BenchmarkInfo> info = new LinkedList<BenchmarkInfo>();

      try {

         for (String benchmark : benchmarks) {
            if (log)
               System.out.println("========================================================================");
            //---------------------
//            int lineNumber = 1;
//            BufferedReader br = new BufferedReader(new FileReader(sourceDir + benchmark));
//            String line = null;
//            while ((line = br.readLine()) != null) {
//               if (line.contains("putIfAbsent"))
//                  System.out.println("--------------------------------------------------------");
//               System.out.println(lineNumber + ". " + line);
//               if (line.contains("putIfAbsent"))
//                  System.out.println("--------------------------------------------------------");
//               lineNumber++;
//            }
            //---------------------
            final String[] pArgs = new String[3];
            pArgs[0] = sourceDir + benchmark;
            pArgs[1] = "-d";
            pArgs[2] = outDir;
            if (log) {
               System.out.println("==================================");
               System.out.println(benchmark);
               System.out.println("==================================");
               Scanner reader = new Scanner(new FileInputStream(pArgs[0]));
               //Scanner reader = new Scanner(System.in);
               while (reader.hasNextLine()) {
                  String s = reader.nextLine();
                  System.out.println(s);
               }
               reader.close();
               System.out.println("==================================");
            }
            long t1 = System.currentTimeMillis();
            Main.main(pArgs);
            long t2 = System.currentTimeMillis();
            long time = t2 - t1;

            BenchmarkInfo benchmarkInfo = new BenchmarkInfo();
            benchmarkInfo.name = benchmark;
            benchmarkInfo.time = time;
            benchmarkInfo.purityPathCount = AtomicityVisitor.purityPathCount;
            benchmarkInfo.pathCount = AtomicityVisitor.pathCount;
            benchmarkInfo.verifiedAtomic = AtomicityVisitor.verifiedAtomic;
            benchmarkInfo.annotatedAtomic = AtomicityVisitor.annotatedAtomic;
            info.add(benchmarkInfo);
//            System.out.println(benchmarkInfo);

            if (log) {
               System.out.println("==================================");
               System.out.println("========================================================================");
            }
         }


         int atomicCount = 0;
         int nonAtomicCount = 0;
         List<String> falsePositives = new LinkedList<String>();
         List<String> falseNegatives = new LinkedList<String>();

         long totalTime = 0;
         long maxTime = Long.MIN_VALUE;
         long minTime = Long.MAX_VALUE;
         long tCount = 0;

         for (BenchmarkInfo benchmarkInfo : info) {

            if (benchmarkInfo.annotatedAtomic) {
               atomicCount++;
               if (!benchmarkInfo.verifiedAtomic)
                  falseNegatives.add(benchmarkInfo.name);
            } else {
               nonAtomicCount++;
               if (benchmarkInfo.verifiedAtomic)
                  falsePositives.add(benchmarkInfo.name);
            }

            if (benchmarkInfo.verifiedAtomic) {

               tCount++;
               long time = benchmarkInfo.time;
               totalTime += time;
               if (time > maxTime)
                  maxTime = time;
               if (time < minTime)
                  minTime = time;
            }
         }

         DecimalFormat df = new DecimalFormat("#.00");
         int count = atomicCount + nonAtomicCount;
         System.out.println("-------------------------");
         System.out.println("Atomic");
         int truePositiveCount = atomicCount - falseNegatives.size();
         int falseNegativeCount = falseNegatives.size();
         double positiveSuccessRate = (truePositiveCount * 100.0) / atomicCount;
         System.out.println("\tCount: " + atomicCount);
         System.out.println("\tTrue Positive: " + truePositiveCount);
         System.out.print("\tFalse Negative: " + falseNegativeCount);
         System.out.print(" in {");
         for (int i = 0; i < falseNegatives.size(); i++) {
            String falseNegative = falseNegatives.get(i);
            System.out.print(falseNegative);
            if (i != falseNegatives.size() - 1)
               System.out.print(" ");
         }
         System.out.println("}");
         System.out.println("\tSuccess Rate: " + df.format(positiveSuccessRate));
         System.out.println("-------------------------");
         System.out.println("Non-Atomic");
         System.out.println("\tCount: " + nonAtomicCount);
         int trueNegativeCount = nonAtomicCount - falsePositives.size();
         int falsePositiveCount = falsePositives.size();
         double nagativeSuccessRate = (trueNegativeCount * 100.0) / nonAtomicCount;
         System.out.println("\tTrue Negative: " + trueNegativeCount);
         System.out.print("\tFalse Positive: " + falsePositiveCount);
         System.out.print(" in {");
         for (int i = 0; i < falsePositives.size(); i++) {
            String falsePositive = falsePositives.get(i);
            System.out.print(falsePositive);
            if (i != falsePositives.size() - 1)
               System.out.print(" ");
         }
         System.out.println("}");
         System.out.println("\tSuccess Rate: " + df.format(nagativeSuccessRate));
         System.out.println("-------------------------");
         System.out.println("All");
         System.out.println("\tCount: " + count);
         int trueClassification = truePositiveCount + trueNegativeCount;
         int falseClassification = count - trueClassification;
         double successRate = (trueClassification * 100.0) / count;
         System.out.println("\tTrue Classification: " + trueClassification);
         System.out.println("\tFalse Classification: " + falseClassification);
         System.out.println("\tSuccess Rate: " + df.format(successRate));
         System.out.println("-------------------------");

         System.out.println("========================================================================");
         System.out.println("Verification Time (for atomic benchmarks)");
         System.out.println("\tTotal time: " + totalTime);
         System.out.println("\tCount = " + tCount);
         System.out.println("\tAverage = " + (totalTime / tCount));
         System.out.println("\tMax time: " + maxTime);
         System.out.println("\tMin time: " + minTime);
         System.out.println("========================================================================");


         System.out.println("Name\tNonExceptionalPaths\tExceptionalPaths\tTime\tAtomic");
         for (BenchmarkInfo b : info) {
            System.out.print(b.name + "\t" + b.purityPathCount + "\t" + b.pathCount + "\t" + b.time + "\t");
//            if (b.annotatedAtomic)
//               System.out.print("+");
//            else
//               System.out.print("-");
//            System.out.print("\t");

            if (b.verifiedAtomic)
               System.out.print("+");
            else
               System.out.print("-");

            System.out.print("\n");
         }

         System.out.println("========================================================================");

      } catch (Exception e) {
         e.printStackTrace();
      } finally {
//            try {
//               if (br != null) {
//                  br.close();
//               }
//            } catch (IOException e) {
//               e.printStackTrace();
//            }
      }
   }

}



