/*
Example 88

Applications: Tammi

Class: DefaultKeyCacheClient

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("clientCaches")
@Result("-")
private CachedMap<K, V> getClientCache(String key, boolean create) {

  KeyValue<String, CachedMap<K, V>> kv = clientCaches.get(key);
  if ((kv == null) && (key != null) && create) {
    ObjectName name = getObjectName();
    if ((name != null) && !name.isPattern()) {
      SharedCache<?, ?> shared = getSharedCache();
      if (shared != null) {
        String domain;
        Hashtable<String, String> keys = name.getKeyPropertyList();
        keys.put(cacheKeyName, ObjectName.quote(key));
        try {
          domain = ObjectName.getInstance(name.getDomain(), keys)
            .getCanonicalName();
        } catch(MalformedObjectNameException x) {
          throw new IllegalArgumentException(
            "Invalid cache key '" + key + '\'');
        }
        CachedMap<K, V> cache = shared.getDomainCache(domain, true);
        kv = new GenericKeyValue<String, CachedMap<K, V>>(domain, cache);
        KeyValue<String, CachedMap<K, V>> tv = clientCaches.putIfAbsent(key, kv);
        if (tv != null) {
          kv = tv;
        }
      }
    }
  }
  return kv != null ? kv.getValue() : null;

}

