/*
Example 50

Applications: Flexive

Class: MessageBean

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("cachedBundles")
@Functional(object="bundleReference", method="getCacheKey")
@Functional(object="bundleReference", method="getBundle")
@Result("-")
private ResourceBundle getResources(BundleReference bundleReference, Locale locale) {

  final String key = bundleReference.getCacheKey(locale);

  if (cachedBundles.get(key) == null) {
    cachedBundles.putIfAbsent(key, bundleReference.getBundle(locale));
  }

  return cachedBundles.get(key);

}
