/*
Example 28

Applications: Apache CXF

Class: ClassResourceInfo

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("subResources")
@Static("ResourceUtils")
@Functional(object="ResourceUtils", method="createClassResourceInfo")
@Functional(object="this", method="enableStatic")
@Result("-")
public ClassResourceInfo getSubResource(Class<?> typedClass, Class<?> instanceClass) {

  instanceClass = this.enableStatic ? typedClass : instanceClass;
  SubresourceKey key = new SubresourceKey(typedClass, instanceClass);
  ClassResourceInfo cri = subResources.get(key);
  if (cri == null && !this.enableStatic) {
    cri = ResourceUtils.createClassResourceInfo(
        typedClass, instanceClass, false, this.enableStatic);
    if (cri != null) {
      subResources.putIfAbsent(key, cri);
    }
  }
  return cri;

}

