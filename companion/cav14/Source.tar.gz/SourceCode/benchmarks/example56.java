/*
Example 56

Applications: Granite

Class: HibernateProxyInstanciator

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("proxyFactories")
//@Static("tokens")
@Result("+")
public void AMethod(C[] tokens) {
  ProxyFactory factory = proxyFactories.get(tokens[0]);

  if (factory == null) {

    factory = new ProxyFactory(tokens[0]);

    ProxyFactory previousFactory = proxyFactories.putIfAbsent(tokens[0], factory);

    if (previousFactory != null)

      factory = previousFactory;
  }
}

