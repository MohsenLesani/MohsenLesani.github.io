/*
Example 51

Applications: Flexive

Class: FxValueRendererFactory

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Two keys

Automatic Extraction: Yes
*/


@BaseObject("renderers")
@Functional(object="this", method="DEFAULT")
@Result("-")
public static FxValueRenderer getInstance(FxLanguage language) {

  if (language == null) {
    // default renderer always exists
    return renderers.get(this.DEFAULT);
  }
  if (!renderers.containsKey(language)) {
    renderers.putIfAbsent(language, new FxValueRendererImpl(language));
  }
  return renderers.get(language);

}

