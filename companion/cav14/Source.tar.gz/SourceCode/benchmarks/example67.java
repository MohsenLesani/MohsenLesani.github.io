/*
Example 67

Applications: Hwajjin

Class: ConcurrentCache

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("cache")
@Result("-")
public V cacheIfAbsent(final K key,final P param) throws InterruptedException {
  while (true) {
    Future<V> f = cache.get(key);
    if (f == null) {
      FutureTask<V> ft = new FutureTask<V>(new Callable<V>() {
        public V call() throws InterruptedException {
          return factory.doWith(param);
        }
      });
      f = cache.putIfAbsent(key, ft);
      if (f == null) {
        f = ft;
        ft.run();
      }
    }
    try {
      return f.get();
    } catch (CancellationException e) {
      cache.remove(key, f);
    } catch (ExecutionException e) {
      throw new RuntimeException(e.getCause());
    }
  }

}

