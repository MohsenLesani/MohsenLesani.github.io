
/*
Example 91

Applications: Tammi

Class: StaticPersisterFactory

Result: Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Many inputs

Automatic Extraction: Yes
*/

@BaseObject("instances")
@Result("+")
public static MBeanReference<? extends PersisterFactory> putRegisteredConnection(
  String className, String alias,
  MBeanReference<? extends PersisterFactory> ref) {

  ConcurrentMap<String, MBeanReference<? extends PersisterFactory>> map = instances
    .get(className);

  if (map == null) {
    map = new ConcurrentReadMap<String, MBeanReference<? extends PersisterFactory>>();
    ConcurrentMap<String, MBeanReference<? extends PersisterFactory>> old = instances
      .putIfAbsent(className, map);

    if (old != null) {
      map = old;
    }
  }
  return map;

}

