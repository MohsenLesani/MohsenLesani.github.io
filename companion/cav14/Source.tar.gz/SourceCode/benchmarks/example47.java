/*
Example 47

Applications: ExoPlatform

Class: TransactionableResourceManager

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("this")
@Result("-")
synchronized public void add(XASessionImpl userSession) {

  final List<SoftReference<XASessionImpl>> joinedList =
      txManagers.get(userSession.getUserID());
  if (joinedList != null) {
    // remove unused session from user list and put this list at the end
    // synchronized (joinedList) { // sync for comodifications from concurrent
    // threads of same user
    for (
        Iterator<SoftReference<XASessionImpl>> siter = joinedList.iterator();
        siter.hasNext();) {
      try {
        XASessionImpl xaSession = siter.next().get();
        if (xaSession == null || !xaSession.isLive())
          siter.remove();
      } catch (ConcurrentModificationException e) {
        e.printStackTrace();
        System.err.println("same user >>> " + e); // TODO
      }
    }
    joinedList.add(new SoftReference<XASessionImpl>(userSession));
    // }
    // make sure the list is not removed by another Session of same user, see
    // remove()
    this.putIfAbsent(userSession.getUserID(), joinedList);
  } else {
    // sync for same userId operations
    final List<SoftReference<XASessionImpl>> newJoinedList =
      new ArrayList<SoftReference<XASessionImpl>>();
    final List<SoftReference<XASessionImpl>> previous =
      this.putIfAbsent(userSession.getUserID(), newJoinedList);
    if (previous != null)
      previous.add(new SoftReference<XASessionImpl>(userSession));
    else
      newJoinedList.add(new SoftReference<XASessionImpl>(userSession));
  }

}

