/*
Example 1

Applications: Adaptive planning

Class: CC

Result: Non-linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: No
*/

// It is not atomic if there is a remove in other threads between the successful putIfAbsent and the following get.
// This is XMemoiseX2


@BaseObject("versionCacheMap")
@Functional(object="this", method="getEntry")
@Result("-")
private static VC get(Version version, Connection conn) throws APException {
   // Get a read lock on the company entry
   Entry companyEntry = this.getEntry();
   companyEntry.acquireReadLock();
   try {
       ConcurrentHashMap<Integer, VC> versionCacheMap =
          companyEntry.getStructureData(version.getStructure(conn), conn).versionCacheMap;

       // Get the version in question.  If it does not exist in the cache, create it.

       Integer versionId = version.getId();
       VC versionCache = versionCacheMap.get(versionId);
       if (versionCache == null) {
           versionCacheMap.putIfAbsent(versionId, create(version, companyEntry, conn));
           versionCache = versionCacheMap.get(versionId);
       }
       return versionCache;
   }
   catch (APException e) {
       companyEntry.releaseReadLock();
       throw e;
   }
   catch (Exception e) {
       companyEntry.releaseReadLock();
       log.error("Caught exception in CC.get, rethrowing as RuntimeException", e);
       throw new RuntimeException("Caught exception in CC.get", e);
   }
}

