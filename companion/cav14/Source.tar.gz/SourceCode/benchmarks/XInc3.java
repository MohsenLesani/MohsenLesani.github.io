



@BaseObject("m")
@Result("+")
public Integer inc3(K key) {
   Integer i = m.putIfAbsent(key, 1);
   if (i == null)
      return 1;
   else {
      while (true) {
         i = m.get(key);
         Integer ni = (i == null) ? 1 : i + 1;
         if (m.replace(key, i, ni))
            return ni;
      }
   }
}




