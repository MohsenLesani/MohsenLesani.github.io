/*
Example 26

Applications: Apache Tomcat

Class: ReplicatedContext

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("tomcatAttributes")
@Result("-")
public Object getAttribute(String name) {

  if (tomcatAttributes.containsKey(name) )
    return tomcatAttributes.get(name);
  else
    return super.getAttribute(name);

}

