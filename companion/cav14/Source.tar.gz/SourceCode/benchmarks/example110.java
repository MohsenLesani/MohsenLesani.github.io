/*
Example 110

Applications: xbird

Class: ConcurrentKeyedStackObjectPool

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: No
*/

@BaseObject("_poolMap")
@Result("-")
public void returnObject(K key, V value) {

  if(!_factory.validateObject(value)) {
    return;
  }
  PooledObject<V> newPoolObj = asPooledObject(value);
  Queue<PooledObject<V>> queue = _poolMap.get(key);
  if(queue == null) {
    Queue<PooledObject<V>> newQueue = new ConcurrentLinkedQueue<PooledObject<V>>();
    Queue<PooledObject<V>> existingQueue = _poolMap.putIfAbsent (key, newQueue);
    if(existingQueue != null) {
      existingQueue.offer(newPoolObj);
    } else {
      newQueue.offer(newPoolObj);
    }
  } else {
    queue.offer(newPoolObj);
  }

}

