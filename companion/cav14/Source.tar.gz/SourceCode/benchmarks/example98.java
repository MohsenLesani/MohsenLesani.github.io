/*
Example 98

Applications: RestEasy

Class: SimpleSecurityDomain

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("roles")
@Result("-")
public void addRole(String user, String role) {

  Set<String> users = roles.get(role);
  if (users == null) {
    users = new CopyOnWriteArraySet<String>();
    roles.putIfAbsent(role, users);
    users = roles.get(role);
  }
  users.add(user);

}

