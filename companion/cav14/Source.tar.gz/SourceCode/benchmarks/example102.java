/*
Example 102

Applications: RestEasy

Class: JsonJAXBContextFinder

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("mappedCollectionCache")
@Result("-")
public JAXBContext dummyFunction() {

	JAXBContext ctx = mappedCollectionCache.get(key);

	if (ctx != null) return ctx;

	ctx = new JettisonMappedContext(mapped, classes);

	mappedCollectionCache.put(key, ctx);

	return ctx;
}

