/*
Example 24

Applications: Apache Tomcat

Class: StandardSession

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("attributes")
@Result("-")
public void setAttribute(String name, Object value, boolean notify) {

  // Name cannot be null
  if (name == null)
    throw new IllegalArgumentException
       (sm.getString("standardSession.setAttribute.namenull"));
  // Null value is the same as removeAttribute()

  if (value == null) {
    removeAttribute(name); // does attributes.remove(name) internally
    return;
  }

  // Validate our current state
  if (!isValidInternal())
    throw new IllegalStateException
       (sm.getString("standardSession.setAttribute.ise"));

  if ((manager != null) && manager.getDistributable() &&
    !(value instanceof Serializable))
    throw new IllegalArgumentException
       (sm.getString("standardSession.setAttribute.iae"));

  // Construct an event with the new value
  HttpSessionBindingEvent event = null;
  // Call the valueBound() method if necessary
  if (notify && value instanceof HttpSessionBindingListener) {
    // Don't call any notification if replacing with the same value
    Object oldValue = attributes.get(name);
    if (value != oldValue) {
      event = new HttpSessionBindingEvent(getSession(), name, value);
      try {
        ((HttpSessionBindingListener) value).valueBound(event);
      } catch (Throwable t){
        manager.getContainer().getLogger().error
          (sm.getString("standardSession.bindingEvent"), t);
      }
    }
  }

  // Replace or add this attribute
  Object unbound = attributes.put(name, value);
  // Call the valueUnbound() method if necessary
  if (notify && (unbound != null) && (unbound != value) &&
    (unbound instanceof HttpSessionBindingListener)) {
      try {
        ((HttpSessionBindingListener) unbound).valueUnbound
          (new HttpSessionBindingEvent(getSession(), name));
      } catch (Throwable t) {
        manager.getContainer().getLogger().error
          (sm.getString("standardSession.bindingEvent"), t);
      }
  }

  if ( !notify ) return;
  // Notify interested application event listeners
  Context context = (Context) manager.getContainer();
  Object listeners[] = context.getApplicationEventListeners();
  if (listeners == null)
    return;

  for (int i = 0; i < listeners.length; i++) {
    if (!(listeners[i] instanceof HttpSessionAttributeListener))
      continue;
    HttpSessionAttributeListener listener =
      (HttpSessionAttributeListener) listeners[i];
    try {
      if (unbound != null) {
        fireContainerEvent(context,
          "beforeSessionAttributeReplaced",
          listener);
        if (event == null) {
          event = new HttpSessionBindingEvent
            (getSession(), name, unbound);
        }
        listener.attributeReplaced(event);
        fireContainerEvent(context,
          "afterSessionAttributeReplaced",
          listener);
      } else {
        fireContainerEvent(context,
          "beforeSessionAttributeAdded",
          listener);
        if (event == null) {
          event = new HttpSessionBindingEvent
            (getSession(), name, value);
        }
        listener.attributeAdded(event);
        fireContainerEvent(context,
          "afterSessionAttributeAdded",
          listener);
      }
    } catch (Throwable t) {
      try {
        if (unbound != null) {
          fireContainerEvent(context,
            "afterSessionAttributeReplaced",
            listener);
        } else {
          fireContainerEvent(context,
            "afterSessionAttributeAdded",
            listener);
        }
      } catch (Exception e) {
        ;
      }
      manager.getContainer().getLogger().error
        (sm.getString("standardSession.attributeEvent"), t);
    }
  }

}

