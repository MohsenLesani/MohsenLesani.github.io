/*
Example 58

Applications: Granite

Class: ProxyFactory

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("identifierTypes")
@Result("-")
private Type getIdentifierType(Class<?> persistentClass) {

  Type type = identifierTypes.get(persistentClass);
  if (type != null)
    return type;

  for (Class<?> clazz = persistentClass; clazz != Object.class && clazz != null; clazz = clazz.getSuperclass()) {
    for (Field field : clazz.getDeclaredFields()) {
      if (field.isAnnotationPresent(Id.class) || field.isAnnotationPresent(EmbeddedId.class)) {
        type = field.getGenericType();
        break;
      }
    }
  }

  if (type == null) {
    PropertyDescriptor[] propertyDescriptors = null;
    try {
      BeanInfo info = Introspector.getBeanInfo(persistentClass);
      propertyDescriptors = info.getPropertyDescriptors();
    } catch (Exception e) {
      throw new IllegalArgumentException("Could not find id in: " + persistentClass, e);
    }
    for (PropertyDescriptor propertyDescriptor : propertyDescriptors) {
      Method method = propertyDescriptor.getReadMethod();
      if (method != null && (
        method.isAnnotationPresent(Id.class) ||
        method.isAnnotationPresent(EmbeddedId.class))) {
          type = method.getGenericReturnType();
          break;
      }
      method = propertyDescriptor.getWriteMethod();
      if (method != null && (
        method.isAnnotationPresent(Id.class) ||
        method.isAnnotationPresent(EmbeddedId.class))) {
          type = method.getGenericParameterTypes()[0];
          break;
      }
    }
  }

  if (type != null) {
    Type previousType = identifierTypes.putIfAbsent(persistentClass, type);
    if (previousType != null)
      type = previousType; // should be the same...
    return type;
  }
  throw new IllegalArgumentException("Could not find id in: " + persistentClass);

}

