/*
Example 64

Applications: Hazelcast

Class: Log4jFactory

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("mapLoggers")
@Static("Logger")
@Result("-")
public ILogger getLogger(String name) {

  ILogger logger = mapLoggers.get(name);
  if (logger == null) {
    Logger l = Logger.getLogger(name);
    ILogger newLogger = new Log4jLogger(l);
    logger = mapLoggers.putIfAbsent(name, newLogger);
    if (logger == null) {
      logger = newLogger;
    }
  }
  return logger;

}

