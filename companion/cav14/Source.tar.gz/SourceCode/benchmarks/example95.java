/*
Example 95

Applications: RestEasy

Class: XmlJAXBContextFinder

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Many inputs

Automatic Extraction: Yes
*/


@BaseObject("collectionCache")
@Result("-")
public JAXBContext findCacheContext(MediaType mediaType, Annotation[] paraAnnotations, Class... classes) throws JAXBException {

  CacheKey key = new CacheKey(classes);
  JAXBContext ctx = collectionCache.get(key);
  if (ctx != null) return ctx;
  ctx = this.createContext(paraAnnotations, classes);
  collectionCache.put(key, ctx);
  return ctx;

}

