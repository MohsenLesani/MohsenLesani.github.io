/*
Example 107

Applications: Vo-urp

Class: JPAFactory

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("managedInstances")
@Functional(object="logB", method="isInfoEnabled")
@Functional(object="logB", method="info")
@Result("-")
public static final JPAFactory getInstance(final String pu) {

  JPAFactory jf = managedInstances.get(pu);
  if (jf == null) {
    if (logB.isInfoEnabled()) {
      logB.info("JPAFactory.getInstance : creating new instance for : " + pu);
    }
    jf = this.prepareInstance(new JPAFactory(pu));
    if (jf != null) {
      managedInstances.putIfAbsent(pu, jf);
      // to be sure to return the singleton :
      jf = managedInstances.get(pu);
    }
  }
  return jf;

}

