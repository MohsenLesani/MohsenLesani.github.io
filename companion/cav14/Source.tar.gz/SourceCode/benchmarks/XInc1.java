

@BaseObject("m")
@Result("+")
public Integer inc1(K key) {
   while (true) {
      Integer i = m.get(key);
      if (i == null) {
         Integer r = m.putIfAbsent(key, 1); // @L
         if (r == null)
            return 1;
      } else {
         Integer ni = i + 1;
         Boolean b = m.replace(key, i, ni); // @L
         if (b)
            return ni;
      }
   }
}

