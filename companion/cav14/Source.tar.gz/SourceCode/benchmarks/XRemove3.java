

// Concurrent Version 3 (Even More Optimized)
@BaseObject("m")
@Result("+")
Attribute removeAttribute(String name) {
   Attribute v = m.remove(name);
   return v;
}
