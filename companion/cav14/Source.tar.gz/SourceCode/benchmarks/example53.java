/*
Example 53

Applications: Flexive

Class: ScriptingEngineBean

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: No
*/


@BaseObject("groovyScriptCache")
@Result("-")
public void fun() {

	Script script = LocalScriptingCache.groovyScriptCache.get(scriptId);
	if (script == null) {
	  try {
	    GroovyShell shell = new GroovyShell();
	    script = shell.parse(CacheAdmin.getEnvironment().getScript(scriptId).getCode());
	  } catch (CompilationFailedException e) {
	    throw new FxInvalidParameterException(
           si.getName(),
           "ex.general.scripting.compileFailed",
           si.getName(),
           e.getMessage());
	  } catch (Throwable t) {
	    throw new FxInvalidParameterException(
           si.getName(),
           "ex.general.scripting.exception",
           si.getName(),
           t.getMessage());
	  }

	  LocalScriptingCache.groovyScriptCache.putIfAbsent(scriptId, script);

	}

}