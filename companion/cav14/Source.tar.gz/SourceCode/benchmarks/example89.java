/*
Example 89

Applications: Tammi

Class: AbstractPersisterFactory

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("timestamps")
@Result("-")
public void modified(String key, long msecs) {
   LongTime stamp = timestamps.get(key);
   if (stamp == null) {
      stamp = new LongTime(msecs);
      stamp = timestamps.putIfAbsent(key, stamp);
      if (stamp != null) {
         stamp.setTimestamp(msecs);
      }
   } else {
      // What if stamp is not thread-safe and multiple threads reach here?
      stamp.setTimestamp(msecs);
   }
}

