/*Example 37

Applications: Cometdim

Class: ChatService

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("_members")
@Result("+")
public void dummyFunction(T channelName)
{
	ArrayList<User> membersArr = _members.get(channelName);
	if (membersArr == null) {

	  ArrayList<User> newMembersArr = new ArrayList<User>();
	  membersArr = _members.putIfAbsent(channelName, newMembersArr);
	  if (membersArr == null)
	    membersArr = newMembersArr;
	}
}
