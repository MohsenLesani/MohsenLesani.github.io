/*
Example 11

Applications: Apache Derby

Class: BufferCache

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("tbl")
@Result("-")
final BufferFrame createNewEntry(final Object key) throws StandardException {
  final BufferFrame newEntry = new BufferFrame(key, null);
  final BufferFrame removed = clockbuf.add(newEntry);

  if (removed != null) {
    assert (removed.isEvicted());
    if(tbl.remove(removed.getKey(), removed)) {
      final Cacheable removedEntry = removed.getValue();
      if(removedEntry != null & removedEntry.isDirty()) {
        removedEntry.clean(false);
      }
    }
  }

  final BufferFrame prevEntry = tbl.putIfAbsent(key, newEntry);
  if (prevEntry != null) {
     newEntry.evictUnshared();
     return null;
  }

  return newEntry;
}

