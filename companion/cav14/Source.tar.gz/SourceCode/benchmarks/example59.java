/*
Example 59

Applications: Gridkit

Class: ReflectionPofSerializer

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Exit not based on collection result

Automatic Extraction: Yes
*/

// Regardless of method calls on objects other than formats,
// this benchmark uses put() instead of putIfAbsent()

@BaseObject("formats")
@Result("-")
protected Object internalDeserialize(PofReader in) throws IOException {

  Class<?> type = in.getPofContext().getClass(in.getUserTypeId());
  ObjectFormat format = formats.get(type);
  if (format == null) {
    try {
      format = new ObjectFormat(type);
    } catch (Exception e) {
      throw new IOException(
          "Failed to create reflection format for " + type.getName(),
          e);
    }
    formats.put(type, format);
  }
  Object result = resolve(format.deserialize(in));
  return result;

}

