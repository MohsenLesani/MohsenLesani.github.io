/*
Example 89b

Applications: Tammi

Class: AbstractPersisterFactory

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("timestamps")
@Functional(object="this", method="setTime")
@Result("+")
public void modified(String key, long msecs) {
   LongTime stamp = timestamps.get(key);
   if (stamp == null) {
      stamp = new LongTime(msecs);
      stamp = timestamps.putIfAbsent(key, stamp);
      if (stamp != null) {
         this.setTime(stamp, msecs);
      }
   } else {
      this.setTime(stamp, msecs);
   }
}


