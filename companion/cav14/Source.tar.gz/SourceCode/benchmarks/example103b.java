/*
Example 103b

Applications: retrotranslator

Class: WeakIdentityTable

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Two keys

Automatic Extraction: Yes        
*/

@BaseObject("map")
@Functional(object="this", method="initialValue")
@Result("-")
public V obtain(K key) {

  V currentValue = map.get(new StrongKey<K>(key));
  if (currentValue != null) {
    return currentValue;
  }
//  cleanup();
//  V newValue = initialValue();
  V newValue = this.initialValue();
  V previousValue = map.putIfAbsent(new WeakKey<K>(key, queue), newValue);
  return previousValue != null ? previousValue : newValue;

}

