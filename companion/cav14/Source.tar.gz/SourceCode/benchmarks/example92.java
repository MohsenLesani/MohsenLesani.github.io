/*
Example 92

Applications: ProjectTrack

Class: MethodCallRecorder

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/


@BaseObject("map")
@Result("+")
public void AMethod(C declaringType)
{
	ConcurrentMap<String, CallRecord> mapForType = map.get(declaringType);

	if (mapForType == null) {

	  mapForType = new ConcurrentHashMap<String, CallRecord>();

	  ConcurrentMap<String, CallRecord> existingEntry = map.putIfAbsent(
	    declaringType, mapForType);

	  if (existingEntry != null)

	    mapForType = existingEntry;

	}
}

