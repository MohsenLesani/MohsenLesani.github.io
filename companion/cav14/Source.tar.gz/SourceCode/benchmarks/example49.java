/*
Example 49

Applications: Flexive

Class: MessageBean

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: No
*/

@BaseObject("cachedMessages")
@Result("-")
public String fun(C messageKey) {

	if (cachedMessages.containsKey(messageKey)) {
	  return cachedMessages.get(messageKey);
	}
	for (BundleReference bundleReference : resourceBundles) {
	  try {
	    final ResourceBundle bundle = getResources(bundleReference, locale);
	    final String message = bundle.getString(key);
	    cachedMessages.putIfAbsent(messageKey, message);
	    return message;
	  } catch (MissingResourceException e) {
	    // continue with next bundle
	  }
	}
}

