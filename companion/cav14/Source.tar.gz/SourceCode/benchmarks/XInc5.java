


@BaseObject("m")
@Result("+")
public Integer incX2(K key) {
   while (true) {
      Integer i = m.putIfAbsent(key, 1);
      if (i == null)
         return 1;
      else {
         Integer ni = i + 1;
         Boolean b = m.replace(key, i, ni);
         while (!b) {
            i = m.get(key);
            ni = (i == null) ? 1 : i + 1;
            b = m.replace(key, i, ni);
         }
         return ni;
      }
   }
}

// This is a correct version with an impure loop.
