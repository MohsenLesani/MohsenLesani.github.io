/*
Example 29

Applications: autoandroid

Class: AndroidTools

Result: Linearizable

Rule Based Data Independence class: FCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("androidTools")
@Result("+")
public static AndroidTools forOsFamily(String osFamily) {

  AndroidTools instance = androidTools.get(osFamily);

  if (instance == null) {
    AndroidTools newInstance = null;
    if (osFamily.equals("windows")) {
      newInstance = new WindowsAndroidTools();
    } else if (osFamily.equals("unix")) {
      newInstance = new UnixAndroidTools();
    } else {
      throw new UnsupportedOperationException("Don't know how to start android tools on " + osFamily);
    }
    instance = androidTools.putIfAbsent(osFamily, newInstance);
    if (instance == null)
       instance = newInstance;
  }
  return instance;

}

