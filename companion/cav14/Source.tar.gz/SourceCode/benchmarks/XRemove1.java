
// Concurrent Version 1
@BaseObject("m")
@Result("+")
Attribute removeAttribute(String name) {
   while (true) {
      boolean found = m.containsKey(name);
      Attribute val = null;
      if (found) {
         val = m.remove(name);
         if (val == null)  
         // Checking the found condition
            continue;
      }
      return val;
   }
}
