/*
Example 46

Applications: EntityFS

Class: OwnerAwareReadLock

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("m_ownerMap")
@Static("Thread")
@Functional(object="Thread", method="currentThread")
@Result("-")
private void incrementLockCountForThread() {

  Thread curThread = Thread.currentThread();
  m_ownerMap.putIfAbsent(curThread, new AtomicInteger(0));
  // Findbugs whines about this, but we set the value in the row above.
  m_ownerMap.get(curThread).incrementAndGet();

}

