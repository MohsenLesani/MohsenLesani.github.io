/*
Example 34

Applications: CBB

Class: AbstractGraph

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("mainList")
@Result("-")
public Node<E> addNode(E e) {

  if (mainList.containsKey(e)) {
    return mainList.get(e).getHeadNode();
  }
  Node<E> node = new Node<E>(e);
  node.setCompare(globalSequenceOfNode.getAndIncrement());
  int gs = globalSequenceOfNode.get();
  if (gs < 0) {
    globalSequenceOfNode.compareAndSet(gs, 0);
  }

  AdjacentList<E> al = new AdjacentList<E>(node);
  AdjacentList<E> prev;
  prev = mainList.putIfAbsent(e, al);
  if (prev == null) {
    return al.getHeadNode();
  } else {
    return prev.getHeadNode();
  }

}

