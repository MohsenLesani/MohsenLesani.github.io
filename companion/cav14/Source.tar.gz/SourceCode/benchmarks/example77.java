/*Example 77

Applications: Jetty

Class: OortChatService

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("_members")
@Result("+")
public void AMethod(C channelName) {
	Map<String, String> membersMap = _members.get(channelName);

	if (membersMap == null) {
	  Map<String, String> newMembersMap = new ConcurrentHashMap<String, String>();
	  membersMap = _members.putIfAbsent(channelName, newMembersMap);
	  if (membersMap == null) membersMap = newMembersMap;
	}
}

