/*
Example 66

Applications: Hudson

Class: Hudson

Result: Non-Linearizable

Rule Based Data Independence class: FCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("labels")
@Result("-")
public Label getLabel(String name) {

  if (name==null) return null;
  while (true) {
    Label l = labels.get(name);
    if (l != null)
      return l;
    // non-existent
    labels.putIfAbsent(name, new Label(name));
  }

}

