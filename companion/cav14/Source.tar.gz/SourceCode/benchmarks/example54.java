/*
Example 54

Applications: GlassFish

Class: DefaultSharedCache

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("runningServices")
@Result("-")
public <T> void registerRunningService(Class<T> serviceClass, T provider) {

  CopyOnWriteArrayList rs = runningServices.get(serviceClass);
  if (rs==null) {
    rs = new CopyOnWriteArrayList<T>();
    CopyOnWriteArrayList existing = runningServices.putIfAbsent(serviceClass, rs);
    if (existing!=null)
      rs = existing;
  }

  // This add is a separate atomic operation.
  rs.add(provider);
}


