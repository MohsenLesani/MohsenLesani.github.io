/*
Example 96b

Applications: RestEasy

Class: Destinations

Result: Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("queues")
@ArgFunctional(object="this", method="makeQueue")
@Result("+")
public QueueResource getQueueResource(String name) throws Exception {

  QueueResource queue = queues.get(name);
  if (queue != null) {
    return queue;
  }
  queue = this.makeQueue(name);
  /*
  InitialContext ctx = new InitialContext();
  Destination destination = null;
  try {
    destination = (Destination) ctx.lookup(queueJndiPrefix + name);
  } catch(NamingException e) {
    throw new WebApplicationException(e, HttpResponseCodes.SC_NOT_FOUND);
  }
  queue = new QueueResource(name, factory.createConnection(), destination, processor, dlq);
  */
  QueueResource tmp = queues.putIfAbsent(name, queue);
  if (tmp == null) {
    //System.out.println("created Queue Resource:" + name);
    return queue;
  } else {
    //queue.close();
    return tmp;
  }

}


