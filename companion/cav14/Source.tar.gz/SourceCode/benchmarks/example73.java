/*
Example 73

Applications: Jetty

Class: AbstractBayeux

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/


@BaseObject("_channelIdCache")
@Result("+")
public ChannelId getChannelId(String id){

  ChannelId cid = _channelIdCache.get(id);
  if (cid == null) {
    cid=new ChannelId(id);
    ChannelId other=_channelIdCache.putIfAbsent(id,cid);
    if (other!=null)
      return other;
  }
  return cid;

}

