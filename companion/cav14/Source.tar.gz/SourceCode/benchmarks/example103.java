/*
Example 103

Applications: retrotranslator

Class: WeakIdentityTable

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Two keys

Automatic Extraction: Yes        
*/

@BaseObject("map")
@Result("-")
public V obtain(K key) {

  V currentValue = map.get(new StrongKey<K>(key));
  if (currentValue != null) {
    return currentValue;
  }
  cleanup();
  V newValue = initialValue();
  V previousValue = map.putIfAbsent(new WeakKey<K>(key, queue), newValue);
  return previousValue != null ? previousValue : newValue;

}

