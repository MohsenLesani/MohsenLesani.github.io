/*
Example 27

Applications: Apache Wicket

Class: Localizer

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("nameToId")
@Functional(object="clazz", method="getName")
@Result("-")
public long id(Class<?> clazz) {

  final String name = clazz.getName();
  Long id = nameToId.get(name);
  if (id == null) {
    id = nameCounter.incrementAndGet();
    Long previousId = nameToId.putIfAbsent(name, id);
    if (previousId != null) {
      id = previousId;
    }
  }
  return id;

}

