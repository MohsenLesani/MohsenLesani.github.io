/*
Example 97

Applications: RestEasy

Class: Destinations

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("topics")
@Result("-")
public TopicResource getTopicResource(String name) throws Exception {

  TopicResource topic = topics.get(name);
  if (topic != null) {
    return topic;
  }

  InitialContext ctx = new InitialContext();
  Destination destination = null;
  try {
    destination = (Destination) ctx.lookup(topicJndiPrefix + name);
  } catch (NamingException e) {
    throw new WebApplicationException(e, HttpResponseCodes.SC_NOT_FOUND);
  }
  topic = new TopicResource(name, factory, factory.createConnection(), destination, processor, dlq);
  TopicResource tmp = topics.putIfAbsent(name, topic);
  if (tmp == null) {
    //System.out.println("created Topic Resource:" + name);
    return topic;
  } else {
    topic.close();
    return tmp;
  }

}

