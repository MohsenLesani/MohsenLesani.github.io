/*
Example 44

Applications: ehcache-spring-annotation

Class: CacheAttributeSourceImpl

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("this.selfPopulatingCaches")
@ArgFunctional(object="this", method="selfPopulatingCaches")
@ArgFunctional(object="this", method="createSelfPopulatingCache")
@Result("+")
public SelfPopulatingCacheTracker AMethod(String cacheName) {

	SelfPopulatingCacheTracker selfPopulatingCacheTracker = this.selfPopulatingCaches.get(cacheName); // LP if cacheName already in
	if (selfPopulatingCacheTracker == null) {
	   selfPopulatingCacheTracker = this.createSelfPopulatingCache(cacheName);
	   //do putIfAbsent to handle concurrent creation. If a value is returned it was already put and that
	   //value should be used. If no value was returned the newly created selfPopulatingCache should be used
      final SelfPopulatingCacheTracker existing =
         this.selfPopulatingCaches.putIfAbsent(cacheName, selfPopulatingCacheTracker);  // LP CAS succeeds

 	   if (existing != null) {
	      selfPopulatingCacheTracker = existing;
	   }
	}

	return selfPopulatingCacheTracker;
}

