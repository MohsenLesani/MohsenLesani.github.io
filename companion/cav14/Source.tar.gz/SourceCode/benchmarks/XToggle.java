



@SetObject
@BaseObject("s")
@Result("+")
public void toggle(V v) {
   while (true) {
      if (s.contains(v)) {
         b = s.remove(v);
         if (b)
            return;
      } else {
         boolean b = s.add(v);
         if (b)
            return;
      }
   }
}


