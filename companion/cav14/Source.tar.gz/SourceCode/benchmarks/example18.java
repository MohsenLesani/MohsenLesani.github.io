/*
Example 18

Applications: Apache Tomcat

Class: ConcurrentCache

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("eden")
@Result("-")
public V get(K k) {

  V v = eden.get(k);
  if (v == null) {
    v = longterm.get(k);
    if (v != null) {
      eden.put(k, v);
    }
  }
  return v;

}

