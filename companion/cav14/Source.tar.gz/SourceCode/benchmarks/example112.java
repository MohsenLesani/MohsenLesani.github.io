/*
Example 112

Applications: Pgrade

Class: ObjectOutputStream

Result: non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("Caches.subclassAudits")
@Result("-")
private void verifySubclass() {

  Class cl = getClass();
  if (cl == ObjectOutputStream.class) {
    return;
  }
  SecurityManager sm = System.getSecurityManager();
  if (sm == null) {
    return;
  }
  processQueue(Caches.subclassAuditsQueue, Caches.subclassAudits);
  WeakClassKey key = new WeakClassKey(cl, Caches.subclassAuditsQueue);

  Boolean result = Caches.subclassAudits.get(key);
  if (result == null) {
    result = Boolean.valueOf(auditSubclass(cl));
    Caches.subclassAudits.putIfAbsent(key, result);
  }
  if (result.booleanValue()) {
    return;
  }
  sm.checkPermission(SUBCLASS_IMPLEMENTATION_PERMISSION);

}

