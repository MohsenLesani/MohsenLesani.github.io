
// Incorrect Version 1b

@BaseObject("m")
@Result("-")
@Static("Math")
@Functional(object="Math", method="computeValue")
V memoizeX1(K k) {
   if (!m.containsKey(k)) {
      v = Math.computeValue(k);
      m.putIfAbsent(k, v);
   }
   v = m.get(k);
   return v;
}

// Similar to XMemoize1.java


