/*Example 42

Applications: dyuproject

Class: StandardConvertorCache

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("_convertors")
@Static("StandardJSON")
@Functional(object="StandardJSON", method="loadClass")
@Functional(object="this", method="newConvertor")
@Functional(object="this", method="UNRESOLVED_CONVERTOR")
@Result("-")
protected Convertor getConvertor(String className) {

  Convertor convertor = (Convertor)_convertors.get(className);
  if(convertor==null) {
    Class<?> clazz = StandardJSON.loadClass(className);
    convertor = clazz==null ? this.UNRESOLVED_CONVERTOR : this.newConvertor(clazz);
    _convertors.putIfAbsent(className, convertor);
  }

  return convertor;

}

