/*
Example 57

Applications: Granite

Class: ExternalizerFactory

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

// This is XMemoize2.java

@BaseObject("externalizersCache")
@Result("-")
private Externalizer newInstance(String externalizerType) {

  Externalizer externalizer = externalizersCache.get(externalizerType);
  if (externalizer == null) {
    try {
      externalizer = ClassUtil.newInstance(externalizerType, Externalizer.class);
    } catch (Exception e) {
      throw new GraniteConfigException(
          "Could not instantiate externalizer: " + externalizerType, e);
    }
    Externalizer previous = externalizersCache.putIfAbsent(externalizerType, externalizer);
    if (previous != null)
      externalizer = previous;
  }
  return externalizer;

}

