/*
Example 6

Applications: Annsor

Class: Annsor

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


// If get() finds nothing and then putIfAbsent() finds an element, there is an add in between.
// we cannot move any of them to the other side
// We cannot condense at get() because then the if condition is satisfied and putIfAbsent() is executed and finds nothing and mutates the map but in the original execution maps is not mutated. We cannot show the equality of resutl states.
// We cannot condense at putIfAbsent() because then get() returns not null and returns it but in the original execution a new object was returned. We cannot show the equaltity of returned values.

@BaseObject("lookup")
@Functional(object="annotation", method="getClass")
@Functional(object="this", method="getClass")
@Result("-")
protected Class getKey(Annotation annotation) {

   if (annotation == null) {
       throw new NullPointerException("A null reference for the Annotation class was passed in.");
   }

   Class clazz = lookup.get(annotation.getClass());
   if (clazz == null) {
       clazz = this.getClass(annotation);
       lookup.putIfAbsent(annotation.getClass(), clazz);
   }

   return clazz;
}

