/*
Example 111

Applications: Yasca

Class: Profiler

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/


@BaseObject("profile")
@Result("+")
public void AMethod(C c) {

	Profile counter = profile.get(c);
	if (counter == null) {
	  counter = new Profile();
	  Profile counter2 = profile.putIfAbsent(c, counter);
	  if (counter2 != null) {
	    counter = counter2;
	  }
	}
}

