/*
Example 7

Applications: Apache Cassandra

Class: SuperColumn

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

// This is similar to XInc5.java

@BaseObject("columns_")
@Functional(object="column", method="name")
@Result("-")
public void addColumn(IColumn column) {

  assert column instanceof Column : "A super column can only contain simple columns";

  byte[] name = column.name();

  IColumn oldColumn = columns_.putIfAbsent(name, column); // LP if CAS succeeds

  if (oldColumn != null) {
     IColumn reconciledColumn = reconciler.reconcile((Column)column, (Column)oldColumn);
     while (!columns_.replace(name, oldColumn, reconciledColumn)) { // LP if CAS succeeds
        oldColumn = columns_.get(name);
        reconciledColumn = reconciler.reconcile((Column)column, (Column)oldColumn);
     }
  }

}

