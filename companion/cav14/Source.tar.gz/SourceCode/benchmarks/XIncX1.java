

@BaseObject("m")
@Result("-")
public Integer inc1(K key) {
   Integer i = m.get(key);
   if (i == null) {
      Integer r = m.put(key, 1);
   } else {
      Integer ni = i + 1;
      m.replace(key, i, ni);
   }
}

