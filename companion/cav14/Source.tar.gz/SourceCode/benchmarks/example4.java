/*
Example 4

Applications: Adobe BlazeDS

Class: GossipRouter

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Many inputs

Automatic Extraction: Yes
*/

// Getting or putting the mapped value for groupname is done atomically but
// accesses and updates to the mapped value are not atomic.

@BaseObject("routingTable")
@Functional(object="log", method="isErrorEnabled")
@Functional(object="log", method="error")
//@Functional(object="this", method="newMap")
@Result("-")
private void addEntry(String groupname, Address logical_addr, AddressEntry entry, boolean update_only) {

   if (groupname == null || logical_addr == null) {
      if (log.isErrorEnabled())
         log.error("groupname or logical_addr was null, entry was not added");
      return;
   }

   ConcurrentMap<Address,AddressEntry> mbrs=routingTable.get(groupname);

   if (mbrs == null) {
       mbrs=new ConcurrentHashMap<Address,AddressEntry>();
       mbrs.put(logical_addr, entry);
       //mbrs = this.newMap(logical_addr, entry)
       routingTable.putIfAbsent(groupname, mbrs);
   } else {
       AddressEntry tmp = mbrs.get(logical_addr);
       if (tmp != null) { // already present
           if (update_only) {
               tmp.update();
               return;
           }
           tmp.destroy();
       }
       mbrs.put(logical_addr, entry);
   }
}

