
// Concurrent Version 3

@BaseObject("m")
@ArgFunctional(object="this", method="computeValue")
@Result("+")
V memoize3(K k) {
   V v = m.get(k);
   while (true) {
      if (v != null)
         return v;
      else {
         v = computeValue(k);
         V vp = m.putIfAbsent(k, v);
         if (vp == null)
            return v;
         v = vp;
      }
   }
}

// This is a correct version with an inpure loop.

