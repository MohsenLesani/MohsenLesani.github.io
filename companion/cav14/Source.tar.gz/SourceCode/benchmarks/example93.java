/*Example 93

Applications: ProjectTrack

Class: MethodCallRecorder

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("mapForType")
@Result("+")
public CallRecord AMethod(C name) {
	CallRecord count = mapForType.get(name);
	if (count == null) {
	  count = new CallRecord();
	  CallRecord oldEntry = mapForType.putIfAbsent(name, count);
	  if (oldEntry != null)
	    count = oldEntry;
	}

	return count;
}

