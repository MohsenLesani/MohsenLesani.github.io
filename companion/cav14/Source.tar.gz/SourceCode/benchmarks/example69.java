/*Example 69

Applications: ifw2

Class: ReflectiveClone

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("cvInstances")
@Result("+")
public static final ClassMetadata getInstance(Class<?> theClass)
throws RuntimeException {

  ClassMetadata res = (ClassMetadata)cvInstances.get(theClass);

  if (res == null) {

    res = new ClassMetadata(theClass);

    ClassMetadata old = cvInstances.putIfAbsent(theClass, res);

    if (old != null)

      res = old;

  }

  return res;

}

