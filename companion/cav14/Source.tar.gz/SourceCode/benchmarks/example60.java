/*
Example 60

Applications: Gridkit

Class: ReflectionPofSerializer

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Exit not based on collection result

Automatic Extraction: No
*/


@BaseObject("formats")
@Result("-")
protected void internalSerialize(PofWriter out, Object origValue) throws IOException {
  Object value = replace(origValue);
  Class<?> type = value.getClass();
  ObjectFormat format = formats.get(type);
  if (format == null) {
    try {
      format = new ObjectFormat(type);
    } catch (Exception e) {
      throw new IOException(
          "Failed to create reflection format for " + type.getName(), e);
    }
    formats.put(type, format);
  }
  format.serialize(out, value);

}

