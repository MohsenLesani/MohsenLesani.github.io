/*
Example 86

Applications: PGrade

Class: StandardLocation

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("locations")
@Functional(object="location", method="getName")
@Result("-")
public static Location locationFor(final String name) {

  if (locations.isEmpty()) {
    // can't use valueOf which throws IllegalArgumentException
    for (Location location : values())
      locations.putIfAbsent(location.getName(), location);
  }

  locations.putIfAbsent(name.toString(/* null-check */), new Location() {
    public String getName() { return name; }
    public boolean isOutputLocation() { return name.endsWith("_OUTPUT"); }
  });

  return locations.get(name);

}

