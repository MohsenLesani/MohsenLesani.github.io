/*Example 48

Applications: FindBugs

Class: Profiler

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

//@interface BaseObject {
//	String className;
//}


@BaseObject("profile")
@Result("+")
public void method48(C c)
{
	//c = x;
	//Ahan I see, it cannot show that
	//(= p.c p3.c)
	//which stems from the fact that this example fails to declare the 
	//input parameters of the method. c should be declared as the parameter.

	AtomicLong counter = profile.get(c);

	if (counter == null) {

	  counter = new AtomicLong();

	  AtomicLong counter2 = profile.putIfAbsent(c, counter);

	  if (counter2 != null)

	    counter = counter2;

	}
}

