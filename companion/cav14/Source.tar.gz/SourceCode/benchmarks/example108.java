/*
Example 108

Applications: Webmill

Class: ContextNavigator

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("portalInstanceMap")
@Static("PortalInstanceImpl")
@Functional(object="PortalInstanceImpl", method="getInstance")
@Result("-")
private PortalInstanceImpl createNewPortalInsance(Long siteId) {

  PortalInstanceImpl portalInstance = portalInstanceMap.get(siteId);
  if (portalInstance != null) {
    return portalInstance;
  }
  portalInstance = PortalInstanceImpl.getInstance(portalServletConfig);
  portalInstanceMap.putIfAbsent(siteId, portalInstance);

  return portalInstance;

}

