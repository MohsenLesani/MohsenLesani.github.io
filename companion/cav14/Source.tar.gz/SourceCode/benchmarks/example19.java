/*Example 19

Applications: Apache Tomcat

Class: ConcurrentCache

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("eden")
@Result("-")
public void put(K k, V v) {

  if (eden.size() >= size) {
    this.longterm.putAll(eden);
    eden.clear();
  }
  eden.put(k, v);

}

