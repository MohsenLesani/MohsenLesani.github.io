/*
Example 109

Applications: xbird

Class: Memoizer

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Conditional remove

Automatic Extraction: Yes
*/

// putIfAbsent() and remove() do not have atomicity with each other.

@BaseObject("cache")
@Result("-")
public V compute(final A arg) throws InterruptedException {

  while(true) {
    Future<V> f = cache.get(arg);
    if(f == null) {
      final Callable<V> eval = new Callable<V>() {
        public V call() throws Exception {
          return c.compute(arg);
        }
      };
      final FutureTask<V> ft = new FutureTask<V>(eval);
      f = cache.putIfAbsent(arg, ft);
      if (f == null) {
        f = ft;
        ft.run();
      }
    }
    try {
      return f.get();
    } catch (CancellationException ce) {
      cache.remove(arg, f);
    } catch (ExecutionException ee) {
      throw launderThrowable(ee.getCause());
    }
  }

}

