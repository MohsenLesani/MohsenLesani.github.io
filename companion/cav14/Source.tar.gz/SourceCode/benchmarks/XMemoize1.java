
// Concurrent Version 1

@BaseObject("m")
@ArgFunctional(object="this", method="computeValue")
@Result("+")
V memoize1(K k) {
   V v = m.get(k);
   if (v == null) {
      v = computeValue(k);
      V v2 = m.putIfAbsent(k, v);
      if (v2 != null)
         v = v2;
   }
   return v;
}


// Similar benchmarks
//    Example 57


