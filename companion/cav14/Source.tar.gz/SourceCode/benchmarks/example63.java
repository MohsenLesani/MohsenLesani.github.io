/*Example 63

Applications: GWTEventService

Class: DefaultUserManager

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("myUserMap")
@Result("+")
public UserInfo addUser(String aUserId) {

  UserInfo theUserInfo = null;
  if (aUserId != null) {
    UserInfo theNewUserInfo = new UserInfo(aUserId);
    theUserInfo = myUserMap.putIfAbsent(aUserId, theNewUserInfo);
    if(theUserInfo == null) {
      theUserInfo = theNewUserInfo;
    }
  }
  return theUserInfo;

}

