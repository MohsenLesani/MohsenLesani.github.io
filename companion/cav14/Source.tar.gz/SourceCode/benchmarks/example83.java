/*
Example 83

Applications: OpenEJB

Class: Memoizer

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("cache")
@Result("-")
public V compute(final K key) throws InterruptedException {

  while (true) {
    Future<V> future = cache.get(key);
    if (future == null) {
      Callable<V> eval = new Callable<V>() {
        public V call() throws Exception {
          return c.compute(key);
        }
      };
      FutureTask<V> futureTask = new FutureTask<V>(eval);
      future = cache.putIfAbsent(key, futureTask);
      if (future == null) {
        future = futureTask;
        futureTask.run();
      }
    }
    try {
      return future.get();
    } catch (ExecutionException e) {
      e.printStackTrace();
    }
  }

}

