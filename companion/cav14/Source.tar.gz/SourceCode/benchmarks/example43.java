/*
Example 43

Applications: ehcache-spring-annotation

Class: CacheAttributeSourceImpl

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("attributesCache")
@Result("-")
private MethodAttribute getMethodAttribute(final Method method, final Class<?> targetClass) {

  final Object cacheKey = this.getCacheKey(method, targetClass);
  //Check if the method has already been inspected and should be ignored
  if (ingoredMethods.containsKey(cacheKey)) {
    return null;
  }
  //Check the cache if the method has already had its advise attributes created
  final MethodAttribute attributes = attributesCache.get(cacheKey);  // LP if cacheKey already in
  if (attributes != null) {
    return attributes;
  }
  // We need to work it out.
  final MethodAttribute att = this.computeMethodAttribute(method, targetClass);
  // Put it in the cache.
  if (att == null) {
    ingoredMethods.put(cacheKey, cacheKey);
  } else {
    this.logger.debug(
        "Adding {} advised method '{}' under key '{}' with attribute: {}",
        new Object[] { att.getAdviceType(), method.getName(), cacheKey, att }
    );
    final MethodAttribute existing = attributesCache.putIfAbsent(cacheKey, att);  // LP if CAS both succeed and fail
    if (existing != null) {
      return existing;
    }
  }
  return att;

}

