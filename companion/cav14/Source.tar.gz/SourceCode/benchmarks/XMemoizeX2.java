
// Incorrect Version 2

@BaseObject("m")
@Result("-")
@Static("Math")
@Functional(object="Math", method="computeValue")
V memoizeX2(K k) {
   V v = m.get(k);
   if (v == null) {
      v = Math.computeValue(k);
      m.putIfAbsent(k, v);
      v = m.get(k);
   }
   return v;
}

// If putIfAbsent() succeeds, there can be a remove between
// the putIfAbsent() and the following get().

