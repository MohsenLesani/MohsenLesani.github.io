/*
Example 87

Applications: Tammi

Class: StaticVariableRegistry

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Branch on collection return value different than null

Automatic Extraction: Yes
*/

@BaseObject("instances")
@Result("-")
public static MBeanReference<? extends VariableRegistry> putRegisteredType(
  String type, MBeanReference<? extends VariableRegistry> ref) {

  MBeanReference<? extends VariableRegistry> old =
      instances.putIfAbsent(type, ref);

  if ((old != null) && !old.isRegistered() && instances.remove(type, old)) {
    return instances.putIfAbsent(type, ref);
  } else {
    return old;
  }

}

