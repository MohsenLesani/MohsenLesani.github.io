/*
Example 13

Applications: Apache ServiceMix

Class: SimpleLockManager

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("locks")
@Result("+")
public Lock getLock(String id) {

  Lock lock = locks.get(id);
  if (lock == null) {
    lock = new ReentrantLock();
    Lock oldLock = locks.putIfAbsent(id, lock);
    if (oldLock != null) {
      lock = oldLock;
    }
  }
  return lock;

}

