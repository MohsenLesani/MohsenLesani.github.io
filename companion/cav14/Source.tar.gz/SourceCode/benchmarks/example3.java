/*Example 3

Applications: Adobe BlazeDS

Class: FIFOMessageQueue

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

// This is similar to example 2

@BaseObject("dests")
@Result("-")
Entry<V> put (K dest) {

   Entry<V> entry=dests.get(dest);

   if (entry == null) {
      entry=new Entry<V>();
      if (dests.putIfAbsent(dest, entry) != null) {
         entry=dests.get(dest);
      }
   }
   return entry;

}


