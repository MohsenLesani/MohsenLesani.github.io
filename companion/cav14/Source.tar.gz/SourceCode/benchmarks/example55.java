/*
Example 55

Applications: GlassFish

Class: BeanManager

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("handlerMap")
@Functional(object="this", method="makeHandler")
@Result("-")
private static ScopeHandler getScopeHandler(String customScope, FacesContext context) {

  ScopeHandler handler = handlerMap.get(customScope);
  if (handler == null) {

    //ExpressionFactory factory = context.getApplication().getExpressionFactory();
    //ValueExpression ve = factory.createValueExpression(
    //      context.getELContext(),
    //      customScope,
    //      Map.class);
    //handler = new CustomScopeHandler(ve);
    handler = this.makeHandler(context, customScope);

    handlerMap.putIfAbsent(customScope, handler);
  }
  return handler;

}

