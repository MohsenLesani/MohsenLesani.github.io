/*
Example 20

Applications: Apache Tomcat

Class: ApplicationContext

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("attr")
@Result("-")
Attribute removeAttribute(String name){

  Attribute val = null;
  found = attr.containsKey(name);
  if (found) {
    val = attr.get(name);
    attr.remove(name);
  }
  return val;

}

