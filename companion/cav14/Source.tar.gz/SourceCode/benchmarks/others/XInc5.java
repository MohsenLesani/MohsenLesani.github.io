



private int inc(Key key) {

  m.putIfAbsent(key, new AtomicInteger(0));
  return m.get(key).incrementAndGet();

}



// This has two atomic operations.
// But isn't it what the user wants?

