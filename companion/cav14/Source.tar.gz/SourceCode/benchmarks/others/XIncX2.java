


@BaseObject("m")
@Result("-")
public Integer incX2(K key) {
   while (true) {
      Integer i = m.putIfAbsent(key, 1);
      if (i == null)
         return 1;
      else {
         Integer ni = i + 1;
         Boolean b = m.replace(key, i, ni); // @L
         while (!b) {
            i = m.get(key);
            ni = i + 1;
            b = m.replace(key, i, ni);
         }
         return ni;
      }
   }
}

// get() may return null.


// A separate tool can check non-nullity.

// Similar benchmarks:
//    Example 8