
// Incorrect Version 1

@BaseObject("m")
@Result("-")
public Integer incX1(K key) {
   Integer i = m.putIfAbsent(key, 1);
   if (i != null) {
      Integer ni = i + 1;
      while (!m.replace(key, i, ni)) {
         i = m.get(key);
         ni = i + 1;
      }
      return ni;
   }
   return 1;
}

/*
The incorrect Version 1 may experience a null pointer exception.
The method call \texttt{putIfAbsent} can return a non-\texttt{null} value denoting that the map contains \texttt{key}.
After this thread passes \texttt{putIfAbsent}, another thread may \texttt{remove} the item from the map.
Thus, \texttt{get} at line 7 may return \texttt{null} and the access of \texttt{i} at line 8 may throw a null pointer exception.
*/



// A separate tool can check non-nullity.

