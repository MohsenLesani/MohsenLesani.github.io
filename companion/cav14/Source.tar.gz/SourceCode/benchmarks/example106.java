/*
Example 106

Applications: Torque-spring

Class: PersistenceManagerFactory

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("repository")
@Functional(object="torqueObjectClass", method="getName")
@Result("-")
public static <T extends BaseObject>
TorquePersistenceManager<T> create (final Class<T> torqueObjectClass) {

  TorquePersistenceManager result =
      PersistenceManagerFactory.repository.get(torqueObjectClass.getName());
  if (result == null) {
    result = new TorquePersistenceManager<T>(torqueObjectClass);
    PersistenceManagerFactory.repository.putIfAbsent (torqueObjectClass.getName(), result);
  }

  return result;

}

