/*
Example 21

Applications: Apache Tomcat

Class: ApplicationContext

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("attributes")
@Result("-")
boolean removeAttribute(String name, Attribute value) {

  boolean replaced = false;
  oldValue = attributes.get(name);

  if (oldValue != null)
    replaced = true;

  attributes.put(name, value);
  return replaced;

}


