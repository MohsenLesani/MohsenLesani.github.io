/*
Example 94

Applications: RestEasy

Class: XmlJAXBContextFinder

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("cache")
@Result("-")
public JAXBContext findCachedContext(Class type, MediaType mediaType,
      Annotation[] parameterAnnotations) throws JAXBException {

  JAXBContext result;
  JAXBContext jaxb = cache.get((Class<?>) type);
  if (jaxb != null) {
    return jaxb;
  }
  jaxb = findProvidedJAXBContext((Class<?>) type, mediaType);
  if (jaxb != null) {
    cache.putIfAbsent((Class<?>) type, jaxb);
    return jaxb;
  }
  jaxb = createContext(parameterAnnotations, type);
  if (jaxb != null)
    cache.putIfAbsent((Class<?>) type, jaxb);
  result = jaxb;
  return result;

}


