

// Concurrent Version 2 (Optimized)
@BaseObject("m")
@Result("+")
Attribute removeAttribute(String name) {
   Attribute val = m.get(name);
   if (val != null)
      val = m.remove(name);
   return val;
}

