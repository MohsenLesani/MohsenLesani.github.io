/*
Example 68b

Applications: ifw2

Class: PropertyNavigator

Result: Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("ivPaths")
@Functional(object="compositeProperty", method="indexOf")
@Static("ivClassInfo")
@Functional(object="ivClassInfo", method="getDirectProperty")
@ArgFunctional(object="this", method="_getPropertyPath")
@Result("+")
public <T> Property<C, T> getProperty(String compositeProperty) {

  if (compositeProperty.indexOf('.') < 0)
    return ivClassInfo.getDirectProperty(compositeProperty);

  CompositeProperty<C, T> path = (CompositeProperty<C, T>)ivPaths.get(compositeProperty);
  if (path == null) {
    path = _getPropertyPath(compositeProperty);
    if (path != null) {
      CompositeProperty<C, T> old =
         (CompositeProperty<C, T>)ivPaths.putIfAbsent(compositeProperty, path);
      if (old != null)
        path = old;
    }
  }

  return path;

}

