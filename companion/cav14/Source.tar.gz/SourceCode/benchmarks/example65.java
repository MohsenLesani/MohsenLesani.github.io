/*
Example 65

Applications: Hazelcast

Class: ClientEndpoint

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("listeneds")
@Result("-")
private ConcurrentMap<Object, EntryEvent> getEventProcessedLog(String name) {

  ConcurrentMap<Object, EntryEvent> eventProcessedLog = listeneds.get(name);
  if (eventProcessedLog == null) {
    eventProcessedLog = new ConcurrentHashMap<Object, EntryEvent>();
    listeneds.putIfAbsent(name, eventProcessedLog);
  }
  return eventProcessedLog;

}

