/*
Example 15

Applications: Apache Tomcat

Class: FastHttpDateFormat

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Size operation

Automatic Extraction: Yes
*/

@BaseObject("formatCache")
@Functional(object="this", method="CACHE_SIZE")
@Result("-")
private static void updateFormatCache(Long key, String value) {

  if (value == null) {
    return;
  }
  if (formatCache.size() > this.CACHE_SIZE) {
    formatCache.clear();
  }
  formatCache.put(key, value);

}



/*
public static final String formatDate(long value, DateFormat threadLocalformat) {
  Long longValue = new Long(value);
  String cachedDate = formatCache.get(longValue);
  if (cachedDate != null)
    return cachedDate;

  String newDate = null;
  Date dateValue = new Date(value);
  if (threadLocalformat != null) {
    newDate = threadLocalformat.format(dateValue);
    updateFormatCache(longValue, newDate);
  } else {
    synchronized (formatCache) {
      synchronized (format) {
        newDate = format.format(dateValue);
      }
      updateFormatCache(longValue, newDate);
    }
  }
  return newDate;
}
*/
