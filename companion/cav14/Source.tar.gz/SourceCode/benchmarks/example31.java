/*Example 31

Applications: Beanlib

Class: EnumUtils

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("enumToStringDirectory")
@Functional(object="enumType", method="getEnumConstants")
@Functional(object="Collections", method="unmodifiableMap")
@Static("Funs")
@Functional(object="Funs", method="makeMap")
@Static("LazyToString")
@Static("Collections")
@Result("+")
private static <T extends Enum<T>>
Map<String,T> enumStringConstantDirectory(Class<T> enumType) {

  Map<String,T> constantMap = LazyToString.enumToStringDirectory.get(enumType);
  if (constantMap == null) {
    constantMap = Funs.makeMap(enumType.getEnumConstants());
//    T[] constants = enumType.getEnumConstants();
//    constantMap = new HashMap<String,T>(2 * constants.length);
//    for (T constant : constants)
//      constantMap.put(constant.toString(), constant);

    Map<String,T> prev =
      LazyToString.enumToStringDirectory
      .putIfAbsent(enumType, Collections.unmodifiableMap(constantMap));
    if (prev != null)
      constantMap = prev;
  }
  return constantMap;

}

