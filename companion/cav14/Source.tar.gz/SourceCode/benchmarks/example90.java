/*
Example 90

Applications: Tammi

Class: DefaultFlowFilter

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Size operation

Automatic Extraction: Yes
*/

@BaseObject("stepStateIndex")
@Result("-")
public int getStateIndex(String state, boolean add) {

  Integer index = stepStateIndex.get(state);
  if ((index == null) && add) {
    if (state == null) {
      throw new NullPointerException("String state");
    }
    index = new Integer(stepStateIndex.size());
    Integer check = stepStateIndex.putIfAbsent(state, index);
    if (check != null) {
      index = check;
    }
  }
  return index != null ? index : -1;

}

