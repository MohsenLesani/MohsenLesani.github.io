/*
Example 52

Applications: Flexive

Class: FxValueRendererFactory

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("renderers")
@Result("-")
void addRenderer(
      FxLanguage language,
      Class<T> valueType,
      FxValueFormatter<DT, T> formatter) {

  renderers.putIfAbsent(language, new FxValueRendererImpl(language));
  renderers.get(language).put(valueType, formatter);

}

