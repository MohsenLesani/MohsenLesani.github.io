/*
Example 2

Applications: Adobe BlazeDS

Class: FIFOMessageQueue

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

// The problem is that after the failed putIfAbsent, a thread may remove the item
// and then our get method call may get null and our the composing method returns null.
// Our method should never return null. It should either return a value that is
// already there or a new value that it is adding.

@BaseObject("queues")
@Result("-")
ConcurrentMap<K,Entry<V>> put(SomeType sender) {

   ConcurrentMap<K,Entry<V>> dests = queues.get(sender);

   if (dests == null) {
       dests = new ConcurrentHashMap<K,Entry<V>>();
       if (queues.putIfAbsent(sender, dests) != null) {
           dests = queues.get(sender);
       }
   }
   return dests;

}



