

@BaseObject("m")
@Result("+")
public Integer inc4(K key) {
   Integer i = m.putIfAbsent(key, 1);
   if (i != null) {
      Integer ni = i + 1;
      while (!m.replace(key, i, ni)) {
         i = m.get(key);
         ni = (i == null) ? 1 : i + 1;
      }
      return ni;
   }
   return 1;
}


// This is a correct version with an impure loop.

// Similar benchmarks
//    Example 7b
