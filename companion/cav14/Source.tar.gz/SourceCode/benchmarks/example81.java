/*
Example 81

Applications: Keyczar

Class: StreamCache

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/


@BaseObject("cacheMap")
@Result("+")
StreamQueue<T> getQueue(KeyczarKey key) {

  StreamQueue<T> queue = cacheMap.get(key);

  if (queue != null) {

    return queue;

  }

  StreamQueue<T> freshQueue = new StreamQueue<T>();

  queue = cacheMap.putIfAbsent(key, freshQueue);

  if (queue != null) {

    return queue;

  }

  return freshQueue;

}

