/*
Example 84

Applications: OpenEJB

Class: EJBInvocationHandler

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("liveHandleRegistry")
@Result("-")
protected static void registerHandler(Object key, EJBInvocationHandler handler) {

  Set<WeakReference<EJBInvocationHandler>> set = liveHandleRegistry.get(key);

  if (set == null) {

    set = new HashSet<WeakReference<EJBInvocationHandler>>();

    Set<WeakReference<EJBInvocationHandler>> current =
      liveHandleRegistry.putIfAbsent(key, set);

    if (current != null) set = current;

  }

  synchronized (set) {
    // This add operation is separate atomic operation.
    set.add(new WeakReference<EJBInvocationHandler>(handler));

  }

}
