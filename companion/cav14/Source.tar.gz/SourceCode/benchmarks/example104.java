/*
Example 104

Applications: Streamy

Class: HttpClient

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes        
*/


@BaseObject("_destinations")
@Result("-")
public HttpDestination getDestination(Address remote, boolean ssl) throws UnknownHostException, IOException {

  if (remote == null)
    throw new UnknownHostException("Remote socket address cannot be null.");
  HttpDestination destination = _destinations.get(remote);
  if (destination == null) {
    destination = new HttpDestination(this, remote, ssl, _maxConnectionsPerAddress);
    if (_proxy != null && (_noProxy == null || !_noProxy.contains(remote.getHost()))) {
      destination.setProxy(_proxy);
      if (_proxyAuthentication != null)
        destination.setProxyAuthentication(_proxyAuthentication);
    }
    HttpDestination other =_destinations.putIfAbsent(remote, destination);
    if (other != null)
      destination=other;
  }
  return destination;

}

