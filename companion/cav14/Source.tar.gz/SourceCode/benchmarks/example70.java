/*Example 70

Applications: ifw2

Class: ClassInfo

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("cvInstances")
@Result("+")
@SuppressWarnings("unchecked")
public static <C> ClassInfo<C> getInstance(Class<C> aClass) {

  ClassInfo<?> classInfo = cvInstances.get(aClass);

  if (classInfo == null) {

    classInfo = new ClassInfo<C>(aClass);

    ClassInfo<?> old = cvInstances.putIfAbsent(aClass, classInfo);

    if (old != null)

      classInfo = old;

  }

  return (ClassInfo<C>)classInfo;

}

