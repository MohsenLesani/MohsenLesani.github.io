/*
Example 75

Applications: Jetty

Class: OortChatService

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("_members")
@Result("+")
public void AMethod(C channelName) {
	Set<String> members = _members.get(channelName);
	if (members == null)	{
	  Set<String> newMembers = new HashSet<String>();
	  members = _members.putIfAbsent(channelName, newMembers);
	  if (members == null) members = newMembers;
	}
}

