/*
Example 9

Applications: Apache Derby

Class: BufferCache

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("tbl")
@Result("-")
private final BufferFrame addEntry(final Object key, final Cacheable value)
throws StandardException {

  for (;;) {
    final BufferFrame newEntry = new BufferFrame(key, value);
    final BufferFrame removed = clockbuf.add(newEntry);
    if (removed != null) {
      assert (removed.isEvicted());
      if (tbl.remove(removed.getKey(), removed)) {
        purgeEntry(removed);
      }
    }

    final BufferFrame prevEntry = tbl.putIfAbsent(key, newEntry);
    if (prevEntry != null) {
      if (prevEntry.pin()) {
        newEntry.evictUnshared(); // need to clean if we failed
        prevEntry.incrementRefCount();
        return prevEntry;
      }
      if (tbl.replace(key, prevEntry, newEntry)) {
        newEntry.setValue(prevEntry.getValue()); // actually not evicted
        return newEntry;
      }
      newEntry.evictUnshared();
      continue;
    }
    return newEntry;
  }

}


