/*
Example 17

Applications: Apache Tomcat

Class: ManagerBase

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Size operation

Automatic Extraction: Yes
*/

@BaseObject("sessions")
@Functional(object="session", method="getIdInternal")
@Result("-")
public void add(Session session) {

  sessions.put(session.getIdInternal(), session);
  int size = sessions.size();

  if (size > this.maxActive) {
    this.maxActive = size;
  }

}

