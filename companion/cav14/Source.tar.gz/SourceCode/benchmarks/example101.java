/*
Example 101

Applications: RestEasy

Class: JsonJAXBContextFinder

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("badgerCollectionCache")
@Result("-")
public JAXBContext dummyFunction(K key) {

	JAXBContext ctx = badgerCollectionCache.get(key);

	if (ctx != null) return ctx;

	ctx = new BadgerContext(classes);

	badgerCollectionCache.put(key, ctx);

	return ctx;
}

