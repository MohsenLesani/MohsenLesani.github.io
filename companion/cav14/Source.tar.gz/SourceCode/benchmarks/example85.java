/*Example 85

Applications:OpenJDK

Class: ThrowingTasks

Result: Linearizable

Rule Based Data Independence class: VCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("this")
@Result("+")
void inc(Class<?> key) {

  while (true) {
    Integer i = this.get(key);
    if (i == null) {
      if (this.putIfAbsent(key, 1) == null) // LP if succeeds
        return;
    } else {
      if (this.replace(key, i, i + 1)) // LP if succeeds
        return;
    }
  }
}

