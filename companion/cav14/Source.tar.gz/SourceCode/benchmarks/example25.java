/*
Example 25

Applications: Apache Tomcat

Class: FileMessageFactory

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("msgBuffer")
@Functional(object="log", method="debug")
@Functional(object="log", method="isDebugEnabled")
@Functional(object="msg", method="getData")
@Functional(object="msg", method="getDataLength")
@Functional(object="msg", method="getMessageNumber")
@Result("-")
public boolean writeMessage(FileMessage msg)
throws IllegalArgumentException, IOException {

  if (!openForWrite)
    throw new IllegalArgumentException(
       "Can't write message, this factory is reading.");
  if (log.isDebugEnabled())
    log.debug("Message " + msg + " data " + msg.getData()
      + " data length " + msg.getDataLength() + " out " + out);

  if (msg.getMessageNumber() <= lastMessageProcessed.get()) {
    // Duplicate of message already processed
    log.warn("Receive Message again -- Sender ActTimeout too short [ path: "
      + msg.getContextPath()
      + " war: "
      + msg.getFileName()
      + " data: "
      + msg.getData()
      + " data length: " + msg.getDataLength() + " ]");
    return false;
  }

  FileMessage previous =
    msgBuffer.put(new Long(msg.getMessageNumber()), msg);

  if (previous !=null) {
    // Duplicate of message not yet processed
    log.warn("Receive Message again -- Sender ActTimeout too short [ path: "
      + msg.getContextPath()
      + " war: "
      + msg.getFileName()
      + " data: "
      + msg.getData()
      + " data length: " + msg.getDataLength() + " ]");
    return false;

  }

  FileMessage next = null;
  synchronized (this) {
    if (!isWriting) {
      next = msgBuffer.get(new Long(lastMessageProcessed.get() + 1));
      if (next != null) {
        isWriting = true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  while (next != null) {
    out.write(next.getData(), 0, next.getDataLength());
    lastMessageProcessed.incrementAndGet();
    out.flush();
    if (next.getMessageNumber() == next.getTotalNrOfMsgs()) {
      out.close();
      cleanup();
      return true;
    }

    synchronized(this) {
      next =
        msgBuffer.get(new Long(lastMessageProcessed.get() + 1));
      if (next == null) {
        isWriting = false;
      }
    }
  }
  return false;

}


