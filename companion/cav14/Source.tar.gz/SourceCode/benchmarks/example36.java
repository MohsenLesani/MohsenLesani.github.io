/*Example 36

Applications: Clojure

Class: Namespace

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("namespaces")
@Result("+")
public static Namespace findOrCreate(Symbol name){

  Namespace ns = namespaces.get(name);
  if (ns != null)
    return ns;

  Namespace newns = new Namespace(name);
  ns = namespaces.putIfAbsent(name, newns);

  return ns == null ? newns : ns;

}

