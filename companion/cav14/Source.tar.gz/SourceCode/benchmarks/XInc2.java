
@BaseObject("m")
@Result("+")
public Integer inc2(K key) {
   while (true) {
      Integer i = m.putIfAbsent(key, 1);
      if (i == null)
         return 1;
      else {
         Integer ni = i + 1;
         Boolean b = m.replace(key, i, ni); // @L
         if (b)
            return ni;
      }
   }
}


