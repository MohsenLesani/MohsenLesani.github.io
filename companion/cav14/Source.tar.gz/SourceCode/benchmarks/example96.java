/*
Example 96

Applications: RestEasy

Class: Destinations

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("queues")
@Result("-")
public QueueResource getQueueResource(String name) throws Exception {

  QueueResource queue = queues.get(name);
  if (queue != null) {
    return queue;
  }
  InitialContext ctx = new InitialContext();
  Destination destination = null;
  try {
    destination = (Destination) ctx.lookup(queueJndiPrefix + name);
  } catch(NamingException e) {
    throw new WebApplicationException(e, HttpResponseCodes.SC_NOT_FOUND);
  }
  queue = new QueueResource(name, factory.createConnection(), destination, processor, dlq);
  QueueResource tmp = queues.putIfAbsent(name, queue);
  if (tmp == null) {
    //System.out.println("created Queue Resource:" + name);
    return queue;
  } else {
    queue.close();
    return tmp;
  }

}

