/*
Example 32

Applications: Carbonado

Class: WorkFilePool

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Exit not based on collection result

Automatic Extraction: Yes
*/

@BaseObject("cPools")
@Functional(object="this", method="computeCanonical")
@Functional(object="this", method="cTempDir")
@Result("-")
static WorkFilePool getInstance(String tempDir) {
  // This method uses ConcurrentMap features to eliminate the need to
  // ever synchronize access, since this method may be called frequently.
  if (tempDir == null) {
    tempDir = this.cTempDir;
  }
  WorkFilePool pool = cPools.get(tempDir);
  if (pool != null) {
    return pool;
  }

  String canonical = this.computeCanonical(tempDir);
  //String canonical;
  //try {
  //  canonical = new File(tempDir).getCanonicalPath();
  //} catch (IOException e) {
  //  canonical = new File(tempDir).getAbsolutePath();
  //}

  if (!canonical.equals(tempDir)) {
    pool = getInstance(canonical);
    cPools.putIfAbsent(tempDir, pool);
    return pool;
  }
  pool = new WorkFilePool(new File(tempDir));
  WorkFilePool existing = cPools.putIfAbsent(tempDir, pool);
  if (existing == null) {
    // New pool is the winner, so finish off initialization. Pool can
    // be used concurrently by another thread without shutdown hook.
    pool.addShutdownHook(tempDir);
  } else {
    pool = existing;
  }
  return pool;

}



