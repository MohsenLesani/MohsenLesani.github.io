/*Example 39

Applications: DWR

Class: AbstractMapContextScope

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("map")
@Result("+")
public ConcurrentMap registryFor(C context) {

  ConcurrentMap instanceMap = map.get(context);
  if (instanceMap == null) {
    ConcurrentMap emptyMap = new ConcurrentHashMap();
    instanceMap = map.putIfAbsent(context, emptyMap);
    if (instanceMap == null) {
      instanceMap = emptyMap;
    }
  }
  return instanceMap;

}

