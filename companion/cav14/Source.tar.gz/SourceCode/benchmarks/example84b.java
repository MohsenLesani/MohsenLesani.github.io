/*
Example 84b

Applications: OpenEJB

Class: EJBInvocationHandler

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("liveHandleRegistry")
@Result("+")
protected static void registerHandler(Object key, EJBInvocationHandler handler) {

  Set<WeakReference<EJBInvocationHandler>> set = liveHandleRegistry.get(key);

  if (set == null) {

    set = new HashSet<WeakReference<EJBInvocationHandler>>();

    Set<WeakReference<EJBInvocationHandler>> current = liveHandleRegistry.putIfAbsent(key, set);

    if (current != null) set = current;

  }
}


