/*
Example 8

Applications: Apache Cassandra

Class: ColumnFamily

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Branch on collection return value different than null

Automatic Extraction: Yes
*/

// This is similar to XIncX2.java

@BaseObject("columns_")
@Functional(object="column", method="name")
@Result("-")
public void addColumn(IColumn column) {
  byte[] name = column.name();
  IColumn oldColumn = columns_.putIfAbsent(name, column);
  if (oldColumn != null) {
    if (oldColumn instanceof SuperColumn) {
      ((SuperColumn) oldColumn).putColumn(column);
    } else {
      while (((Column) oldColumn).comparePriority((Column)column) <= 0) {
        if (columns_.replace(name, oldColumn, column))
          break;
        oldColumn = columns_.get(name); // oldColumn might be null
      }
    }
  }
}

