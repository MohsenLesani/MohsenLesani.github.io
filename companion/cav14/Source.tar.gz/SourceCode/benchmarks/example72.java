/*
Example 72

Applications: JBoss

Class: AOPLogger

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/


@BaseObject("loggers")
@Result("+")
public static AOPLogger getLogger(final Class<?> clazz) {

  AOPLogger logger = loggers.get(clazz);
  if (logger == null) {
    logger = new AOPLogger(clazz);
    AOPLogger oldLogger = loggers.putIfAbsent(clazz, logger);
    if (oldLogger != null) {
      logger = oldLogger;
    }
  }
  return logger;

}

