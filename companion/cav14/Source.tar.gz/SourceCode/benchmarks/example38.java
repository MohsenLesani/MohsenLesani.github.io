/*
Example 38

Applications: Daisy

Class: VariablesManagerImpl

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("cache")
@Result("-")
private Variables getVariables(VariantKey inputKey, final PublisherVersionMode versionMode, Set<VariantKey> loadedVariantKeys) {

  // normalize the variant key
  String docId = repository.normalizeDocumentId(inputKey.getDocumentId());
  final VariantKey key = new VariantKey(docId, inputKey.getBranchId(), inputKey.getLanguageId());
  // avoid loading same document twice
  if (loadedVariantKeys.contains(key))
    return null;
  else
    loadedVariantKeys.add(key);
  VariablesCacheKey cacheKey = new VariablesCacheKey(key, versionMode);
  Future<Variables> future = cache.get(cacheKey);
  if (future == null) {
    Callable<Variables> eval = new Callable<Variables>() {
      public Variables call() throws Exception {
        return loadVariables(key, versionMode);
      }
    };
    FutureTask<Variables> futureTask = new FutureTask<Variables>(eval);
    future = cache.putIfAbsent(cacheKey, futureTask);
    if (future == null) {
      future = futureTask;
      futureTask.run();
    }
  }
  try {
    return future.get();
  } catch (InterruptedException e) {
    throw new RuntimeException(e);
  } catch (ExecutionException e) {
    throw new RuntimeException(e);
  }

}

