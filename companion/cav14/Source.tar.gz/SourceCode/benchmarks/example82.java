/*
Example 82

Applications: memcache-client

Class: SocklOpool

Result: Non-linearizable

Rule Based Data Independence class: FCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("pools")
@Result("-")
public static SockIOPool getInstance(String poolName) {
  SockIOPool pool;
  if (!pools.containsKey("poolName")) {
    pool = new SockIOPool();
    pools.putIfAbsent(poolName, pool);
  }
  return pools.get(poolName);
}

