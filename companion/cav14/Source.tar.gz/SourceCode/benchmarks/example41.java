/*
Example 41

Applications: dyuproject

Class: StandardConvertorCache

Result: Non-Linearizable

Rule Based Data Independence class: FCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("_convertors")
@Functional(object="clazz", method="getName")
@Functional(object="this", method="newConvertor")
@Result("-")
public Convertor getConvertor(Class<?> clazz, boolean create, boolean addClass) {

  Convertor convertor = (Convertor)_convertors.get(clazz.getName());
  if (convertor==null && create) {
    convertor = this.newConvertor(clazz, addClass);
    _convertors.putIfAbsent(clazz.getName(), convertor);
  }
  return convertor;

}

