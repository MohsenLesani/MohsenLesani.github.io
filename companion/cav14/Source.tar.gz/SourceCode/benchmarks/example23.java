/*
Example 23

Applications: Apache Tomcat

Class: Http11NioProtocol

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("connections")
@Functional(object="log", method="debug")
@Functional(object="log", method="isDebugEnabled")
@Result("-")
public SocketState event(NioChannel socket, SocketStatus status) {

  Http11NioProcessor result = connections.get(socket);
  SocketState state = SocketState.CLOSED;
  if (result != null) {
    if (log.isDebugEnabled()) log.debug("Http11NioProcessor.error="+result.error);
    try {
      state = result.event(status);
    } catch (java.net.SocketException e) {
      Http11NioProtocol.log.debug(sm.getString("http11protocol.proto.socketexception.debug"), e);
    } catch (java.io.IOException e) {
      Http11NioProtocol.log.debug(sm.getString("http11protocol.proto.ioexception.debug"), e);
    } catch (Throwable e) {
      Http11NioProtocol.log.error
        (sm.getString("http11protocol.proto.error"), e);
    } finally {
      if (state != SocketState.LONG) {
        connections.remove(socket);
        recycledProcessors.offer(result);
        if (state == SocketState.OPEN) {
          socket.getPoller().add(socket);
        }
      } else {
        if (log.isDebugEnabled()) log.debug("Keeping processor["+result);
        //add correct poller events here based on Comet stuff
        NioEndpoint.KeyAttachment att = (NioEndpoint.KeyAttachment)socket.getAttachment(false);
        socket.getPoller().add(socket,att.getCometOps());
      }
    }
  }

  return state;

}

