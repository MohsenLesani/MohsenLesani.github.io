/*
Example 45

Applications: Ektorp

Class: ReflectionUtils

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Two keys

Automatic Extraction: Yes
*/

@BaseObject("accessors")
@Functional(object="document", method="getClass")
@Result("-")
private static DocumentAccessor getAccessor(Object document) {

  Class<?> clazz = document.getClass();
  DocumentAccessor accessor = accessors.get(clazz);
  if (accessor == null) {
    if (document instanceof Map<?,?>) {
      accessor = accessors.get(Map.class);
      accessors.put(clazz, accessor);
    } else {
      accessors.putIfAbsent(clazz, new ReflectionAccessor(clazz));  // non linearizable
      accessor = accessors.get(clazz);
    }
  }
  return accessor;

}

