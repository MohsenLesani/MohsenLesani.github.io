/*
Example 61

Applications: GWTEventService

Class: AutoIncrementFactory

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("myAutoIncrementMap")
@Result("-")
private AtomicInteger getAtomic(String aKey) {

  myAutoIncrementMap.putIfAbsent(aKey, new AtomicInteger());
  return myAutoIncrementMap.get(aKey);

}

