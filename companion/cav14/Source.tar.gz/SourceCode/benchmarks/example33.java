/*
Example 33

Applications: Carbonado

Class: AbstractWeakPool

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Exit not based on collection result

Automatic Extraction: Yes
*/

@BaseObject("mValues")
@Functional(object="valueRef", method="get")
@Functional(object="valueRef", method="clear")
@Result("-")
public V get(K key) throws E {

  clean();
  ValueRef<K, V> valueRef = mValues.get(key);
  V value;
  if (valueRef == null || (value = valueRef.get()) == null) {
    try {
      value = create(key);
    } catch (Exception e) {
      // Workaround compiler bug.
      ThrowUnchecked.fire(e);
      return null;
    }
    valueRef = new ValueRef<K, V>(value, mValueRefQueue, key);
    while (true) {
      ValueRef<K, V> existingRef = mValues.putIfAbsent(key, valueRef);
      if (existingRef == null) {
        // Newly created value is now the official value.
        break;
      }
      V existing = existingRef.get();
      if (existing != null) {
        // Someone else just created value before us. Use that
        // instead and chuck the new value object.
        value = existing;
        valueRef.clear();
        break;
      }
      // Reference just got cleared. Try again. Explicitly remove it
      // to prevent an infinite loop. Note that the two argument
      // remove method is called to ensure that what is being removed
      // is not a new value.
      mValues.remove(((ValueRef<K, V>) existingRef).mKey, existingRef);
    }
  }
  return value;

}

// what does clean() do?
// Even without that this method may remove() and then add a key-value that are two separate atomic oparations.


