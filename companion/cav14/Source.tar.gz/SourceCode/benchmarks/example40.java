/*
Example 40

Applications: DWR

Class: AbstractContextScope

Result: Non-Linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Conditional remove

Automatic Extraction: Yes
*/

@BaseObject("this")
@Functional(object="log", method="isDebugEnabled")
@Functional(object="log", method="debug")
@Functional(object="String", method="format")
@Result("-")
public T get(C1 key, C2 context, C3 scopeName, C4 name) {
  if (log.isDebugEnabled()) {
    log.debug(String.format(
      "scope %s: getting key %s with creator %s",
      scopeName, key, creator
      ));
  }

  C context = getContext(key);
  R registry = registryFor(context);
  InstanceProvider<T> future =
    AbstractContextScope.this.get(registry, key, name);
  if (future == null) {
    InstanceProvider<T> futureTask = new FutureTaskProvider<T>(creator);
    future = putIfAbsent(registry, key, name, futureTask);
    if (future == null) {
      future = futureTask;
      futureTask.run();
      if (Thread.currentThread().isInterrupted()) {
        remove(registry, key, name, futureTask);
      }
    }
  }
  return future.get();

}

