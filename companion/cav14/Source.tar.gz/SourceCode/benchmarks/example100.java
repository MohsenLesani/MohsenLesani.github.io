/*Example 100

Applications: RestEasy

Class: JsonJAXBContextFinder

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("cache")
@Result("-")
protected JAXBContext find(Class<?> type, MediaType mediaType, ConcurrentHashMap<Class<?>, JAXBContext> cache, Mapped mapped, BadgerFish badger) throws JAXBException {

  JAXBContext jaxb;
  jaxb = cache.get(type);
  if (jaxb != null) {
    return jaxb;
  }
  jaxb = findProvidedJAXBContext(type, mediaType);
  if (jaxb == null) {
    if (badger != null) {
      jaxb = new BadgerContext(type);
    } else if (mapped != null) {
      jaxb = new JettisonMappedContext(mapped, type);
    } else {
      jaxb = new JettisonMappedContext(type);
    }
  }
  cache.putIfAbsent(type, jaxb);
  return jaxb;

}

