/*Example 78

Applications: Jexin

Class: ActiveTemplateMap

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/
@BaseObject("activeTemplates")
@Result("+")
public void AMethod(C key) {
   ConcurrentMap<Integer, StackTraceTemplate> templateMap = activeTemplates.get(key);
	if (templateMap == null) {
	   ConcurrentMap<Integer, StackTraceTemplate> newTemplateMap =
         new ConcurrentHashMap<Integer, StackTraceTemplate>();
	   templateMap = activeTemplates.putIfAbsent(key, newTemplateMap);
	   if (templateMap == null) {
	      templateMap = newTemplateMap;
	  }
	}
}

