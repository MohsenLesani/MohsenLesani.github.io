/*Example 79

Applications: JRipples

Class: HessianSkeletonProviderImpl

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

// Muliple receivers:
//    this.skeletonCache
//    this.mapping

@BaseObject("this.skeletonCache")
@Functional(object="path", method="endsWith")
@Functional(object="path", method="length")
@Functional(object="path", method="substring")
@Functional(object="path", method="lastIndexOf")
@Result("-")
protected HessianSkeleton getMappingFromPath(String path) {

  if (path.endsWith("/"))
    path = path.substring(0, path.length() - 1);
  String requestedService = path.substring(path.lastIndexOf("/") + 1);

  HessianSkeleton retVal = this.skeletonCache.get(requestedService);
  if (retVal == null) {
    WebserviceMappingBean wsBean = this.mapping.get(requestedService);
    if (wsBean == null)
      throw new NoSuchServiceException();
    if (!checkInterface(wsBean))
      throw new RuntimeException(
         "The configured webservice interface is " +
         "not assignable from the corresponding service");
    retVal = new HessianSkeleton(
       wsBean.getServiceImpl(),
       wsBean.getServiceInterface());

    /*
    * rather create this service twice as synchronize the whole block
    */

    this.skeletonCache.putIfAbsent(requestedService, retVal);
  }
  return retVal;

}

