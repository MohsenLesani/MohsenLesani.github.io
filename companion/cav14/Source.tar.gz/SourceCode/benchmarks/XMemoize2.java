
// Concurrent Version 2

@BaseObject("m")
@Static("Math")
@Functional(object="Math", method="computeValue")
@Result("+")
V memoize2(K k) {
   while (true) {
      V v = m.get(k);
      if (v == null) {
         v = Math.computeValue(k);
         V r = m.putIfAbsent(k, v);
         if (r != null)
            continue;
      }
      return v;
   }
}
