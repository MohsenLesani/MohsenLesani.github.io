/*
Example 80

Applications: JSefa

Class: InitialConfiguration

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("MAP")
@Functional(object="defaultValueProvider", method="get")
@Result("+")
public static <T> T get(String parameter, OnDemandObjectProvider defaultValueProvider) {

  T previousValue = (T) MAP.get(parameter);

  if (previousValue != null) {

    return previousValue;

  } else {

    T defaultValue = (T) defaultValueProvider.get();

    previousValue = (T) MAP.putIfAbsent(parameter, defaultValue);

    if (previousValue != null) {

      return previousValue;

    } else {

      return (T) defaultValue;

    }

  }

}

