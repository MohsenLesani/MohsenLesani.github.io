/*
Example 10

Applications: Apache Derby

Class: ConcurrentCache

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/


@BaseObject("cache")
@Result("-")
private CacheEntry getEntry(Object key) {

  CacheEntry entry = cache.get(key);
  while (true) {
    if (entry != null) {
      entry.lock();
      entry.waitUntilIdentityIsSet();
      if (entry.isValid()) {
        return entry;
      } else {
        entry.unlock();
        entry = cache.get(key);
      }
    } else {
      CacheEntry freshEntry = new CacheEntry();
      freshEntry.lock();
      CacheEntry oldEntry = cache.putIfAbsent(key, freshEntry);
      if (oldEntry != null) {
        entry = oldEntry;
      } else {
        return freshEntry;
      }
    }
  }

}

