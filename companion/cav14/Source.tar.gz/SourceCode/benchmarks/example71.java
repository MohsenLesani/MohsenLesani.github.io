/*
Example 71

Applications: Jack4J

Class: JackClient

Result: Non-linearizable

Rule Based Data Independence class: FCM

Violated Rule: None

Automatic Extraction: Yes
*/


@BaseObject("ports")
@Result("-")
private JackPort portForHandle(long portHandle) {

  if (portHandle == 0) {
    return null;
  }
  WeakReference<JackPort> portReference = ports.get(portHandle);
  JackPort port = (portReference == null) ? null : portReference.get();
  if (port == null) {
    JackPort newPort = new JackPort(portHandle);
    WeakReference<JackPort> newPortReference = new WeakReference<JackPort>(newPort);
    do {
      WeakReference<JackPort> oldPortReference =
         ports.putIfAbsent(portHandle, newPortReference);
      if (oldPortReference == null) {
        port = newPort;
      } else {
        port = oldPortReference.get();
      }
    } while (port == null);
  }
  return port;

}


