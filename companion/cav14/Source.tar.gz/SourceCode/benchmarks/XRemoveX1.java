




@BaseObject("m")
@Result("-")
Attribute removeAttribute(String name){

  Attribute val = null;
  found = m.containsKey(name);
  if (found) {
    val = m.get(name);
    m.remove(name);
  }
  return val;

}


// Similar benchamrks:
//    Example 20

