/*
Example 22

Applications: Apache Tomcat

Class: Http11AprProtocol

Result: Non-Linearizable

Rule Based Data Independence class: Data Dependent

Violated Rule: Globals

Automatic Extraction: Yes
*/

@BaseObject("connections")
@Result("-")
public SocketState event(long socket, SocketStatus status) {

  Http11AprProcessor result = connections.get(socket);
  SocketState state = SocketState.CLOSED;
  if (result != null) {
    try {
      state = result.event(status);
    } catch (java.net.SocketException e) {
      Http11AprProtocol.log.debug(sm.getString("http11protocol.proto.socketexception.debug"), e);
    } catch (java.io.IOException e) {
      Http11AprProtocol.log.debug(sm.getString("http11protocol.proto.ioexception.debug"), e);
    } catch (Throwable e) {
      Http11AprProtocol.log.error(sm.getString("http11protocol.proto.error"), e);
    } finally {
      if (state != SocketState.LONG) {
        connections.remove(socket);
        recycledProcessors.offer(result);
        if (state == SocketState.OPEN) {
          proto.endpoint.getPoller().add(socket);
        }
      } else {
        proto.endpoint.getCometPoller().add(socket);
      }
    }
  }
  return state;

}

