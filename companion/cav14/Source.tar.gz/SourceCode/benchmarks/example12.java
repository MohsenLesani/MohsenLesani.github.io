/*
Example 12

Applications: Apache MyFaces Trinidad

Class: SessionChangeManager

Result: Non-linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("componentChangesMapForSession")
@Result("-")
public DummyClass dummyFunction(C viewId) {

  if (!componentChangesMapForSession.containsKey(viewId)) {
    componentChangesMapForSession.putIfAbsent(viewId, new ChangesForView(true));
  }

  return componentChangesMapForSession.get(viewId); // non linearizable
}


