/*
Example 105

Applications: Tersus

Class: DefaultMessageSizeEstimator

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Exit not based on collection result

Automatic Extraction: Yes
*/

@BaseObject("class2size")
@Result("-")
private int estimateSize(Class<?> clazz, Set<Class<?>> visitedClasses) {
  Integer objectSize = class2size.get(clazz);
  if (objectSize != null) {
    return objectSize;
  }
  if (visitedClasses != null) {
    if (visitedClasses.contains(clazz)) {
      return 0;
    }
  } else {
    visitedClasses = new HashSet<Class<?>>();
  }
  visitedClasses.add(clazz);
  int answer = 8; // Basic overhead.
  for (Class<?> c = clazz; c != null; c = c.getSuperclass()) {
    Field[] fields = c.getDeclaredFields();
    for (Field f: fields) {
      if ((f.getModifiers() & Modifier.STATIC) != 0) {
        // Ignore static fields.
        continue;
      }
      answer += estimateSize(f.getType(), visitedClasses);
    }
  }
  visitedClasses.remove(clazz);
  // Some alignment.
  answer = align(answer);
  // Put the final answer.
  class2size.putIfAbsent(clazz, answer);

  return answer;

}

