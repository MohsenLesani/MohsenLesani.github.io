
// Incorrect Version 3

@BaseObject("m")
@Result("-")
@Static("Math")
@Functional(object="Math", method="computeValue")
V memoizeX3(K k) {
   V v = m.get(k);
   if (v == null) {
      v = Math.computeValue(k);
      m.putIfAbsent(k, v);
   }
   return v;
}

// If get() finds nothing and then putIfAbsent() finds an element,
// there should be an add() or successful putIfAbsent() in between.
// Sequential execution on one side of this method either results in a
// different state or a different return value.

// Similar benchmarks
//    Example 28
//    Example 41
//    Example 55