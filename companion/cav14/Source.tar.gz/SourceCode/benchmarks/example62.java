/*
Example 62

Applications: GWTEventService

Class: DomainUserMapping

Result: Non-Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: No
*/

@BaseObject("myDomainUserInfoMap")
@Result("-")
public void addUser(Domain aDomain, UserInfo aUserInfo) {

  myDomainUserInfoMap.putIfAbsent(aDomain, new ConcurrentSkipListSet<UserInfo>());
  Set<UserInfo> theUsers = myDomainUserInfoMap.get(aDomain);
  theUsers.add(aUserInfo);

}

