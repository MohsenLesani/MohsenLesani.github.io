/*
Example 99

Applications: RestEasy

Class: JAXBCache

Result: Non-linearizable

Rule Based Data Independence class: Data dependent

Violated Rule: Exit not based on collection result

Automatic Extraction: Yes
*/


@BaseObject("contextCache")
@Result("-")
public JAXBContext getJAXBContext(Class<?>... classes) {

  JAXBContext context = contextCache.get(classes);
  if (context == null) {
    try {
      context = JAXBContext.newInstance(classes);
    } catch (JAXBException e) {
      throw new ExceptionAdapter(e);
    }
    contextCache.putIfAbsent(classes, context);
  }
  logger.debug("Locating JAXBContext for package: {}", classes);
  return context;

}

