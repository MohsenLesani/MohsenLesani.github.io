/*
Example 30

Applications: Beanlib

Class: EnumUtils

Result: Linearizable

Rule Based Data Independence class: SCM

Violated Rule: None

Automatic Extraction: Yes
*/

@BaseObject("enumExternalDirectory")
@Functional(object="enumType", method="getEnumConstants")
@Functional(object="Collections", method="unmodifiableMap")
@Static("Funs")
@Functional(object="Funs", method="makeMap")
@Static("LazyExternal")
@Static("Collections")
@Result("+")
private static <T extends Enum<T> & External<E>, E>
Map<E, T> enumConstantDirectory(Class<T> enumType) {

  Map<E,T> constantMap = LazyExternal.enumExternalDirectory.get(enumType);

  if (constantMap == null) {

    constantMap = Funs.makeMap(enumType.getEnumConstants());
    //T[] constants = enumType.getEnumConstants();
    //constantMap = new HashMap<E,T>(2 * constants.length);
    //for (T constant : constants)
    //  constantMap.put(constant.externalize(), constant);

    Map<E,T> prev = LazyExternal.enumExternalDirectory
      .putIfAbsent(enumType, Collections.unmodifiableMap(constantMap));
    if (prev != null)
      constantMap = prev;

  }
  return constantMap;
}


