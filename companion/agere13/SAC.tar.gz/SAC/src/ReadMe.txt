
To Have a new implementation of a map and test it:

Define a map class that extends the trait akka.sharing.map.core.Map[K, V].
The methods that should be defined are:
  def get(k: K)(implicit self: Option[ActorRef] = None): Option[V]
  def put(k: K, v: V)(implicit self: Option[ActorRef] = None)
  def remove(k: K)(implicit self: Option[ActorRef] = None)
  def atomicFlush()
  def newReadRef(): ReadMap[K, V]

put(), get() and remove() are the normal methods of the map abstraction.

atomicFlush() method is called for you at the end of each message-processing of the writer actor.
To preserve atomicity, this method is where all the updates should be emitted together.

newReadRef() method should return a subclass of trait akka.sharing.map.core.ReadMap[K, V].
ReadMap[K, V] is the type of map that reader actors hold.
The method that should be implemented are
  def get(k: K): Option[V]
  def update(): Int
The class that extends ReadMap[K, V] is usually a nested class of the class that extends
Map[K, V] (to access data from the nesting class).

get() is the normal method of map abstraction.
update() is called for you at the beginning of each message-processing of the reader actor.
To preserve isolation, this method is the only place that the updates should become visible
to the reader. To enable the replay, the version that reader is updated to should be returned
from this method.

package akka.sharing.map.optimized contains my sample optimized implementation.

To play and reply a test:
Extend your actor classes from import akka.sharing.checker.core.Actor instead of the standard akka actor.
update the following to your paths for the log location:
    akka.sharing.checker.core.Actor.defaultFolder
    akka.sharing.checker.core.Actor.defaultFileName
A test example is at lesani.actor.cases.sharing.server1.MainLauncher.
Import your implementation for the play and the reference implementation
(that akka.sharing.map.reference.MapImp) for the replay








