package akka.checker.core

import akka.actor.ActorRegistered;
import akka.actor.ActorUnregistered;
import akka.actor.Actor._

class RegistryListener(code: => Unit) extends akka.actor.Actor {
  var actives = 0

  def receive = {
    case event: ActorRegistered =>
//      println (event.actor.uuid + " registered")
//      println("Actor registered: %s - %s".format(
//        event.actor.actorClassName, event.actor.uuid))
      actives += 1

    case event: ActorUnregistered =>
//      println (event.actor.uuid + " unregistered")
//      println("Actor unregistered: %s - %s".format(
//        event.actor.actorClassName, event.actor.uuid))
      actives -= 1
      if (actives == 0) {
        registry.shutdownAll()
        code
      }
  }

}

