package akka.checker.core

import collection.mutable.ListBuffer

@serializable
class ActorId {
  var list: ListBuffer[Int] = _

  def this(i: Int) {
    this()
    list = new ListBuffer[Int]() :+ i
  }

  def this(parentId: ActorId, i: Int) {
    this()
    list = parentId.list :+ i
  }

  override def toString = {
    var s = "["
    list.foreach(i =>
        s += (i + " ")
    )
    s.subSequence(0, s.length() - 1) + "]"
  }


  override def equals(obj: Any) =
    obj.isInstanceOf[ActorId] && obj.asInstanceOf[ActorId].list == this.list

  override def hashCode() = list.hashCode()

}

