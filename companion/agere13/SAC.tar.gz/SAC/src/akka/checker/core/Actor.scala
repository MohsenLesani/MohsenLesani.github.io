package akka.checker.core

import scala.collection.JavaConversions._
import java.io.{ObjectInputStream, FileInputStream, FileOutputStream, ObjectOutputStream}
import collection.mutable.{ConcurrentMap, ListBuffer, HashMap}
import java.util.concurrent.ConcurrentHashMap
import akka.actor.ActorRef


trait Actor extends akka.actor.Actor {

  import Actor._
  import Mode._

  var actorId: ActorId = _
  var lastChildNo = 0

  var messageNo = 0
//  println(this + " with no. " + actorNo + " created.")

  private var messageSequence = new ListBuffer[Pair[ActorId, Int]]()
  private val playPreBeh: PartialFunction[Any, Any] = {
    case PaddedMessage(messageId, message) =>
//      println("Actor " + actorId + ": Processing message " + messageId + ": " + message)
      messageSequence += messageId
      message
  }

  var currentMessageId: Pair[ActorId, Int] = _
  val messageMap = new HashMap[Pair[ActorId, Int], Any]()
  private val replayBeh: PartialFunction[Any, Unit] = {
    case PaddedMessage(messageId, message) =>
      //println("Actor " + actorId + ": Processing message " + messageId + ": " + message)
      messageMap += (messageId -> message)
      while (messageMap.containsKey(currentMessageId)) {
        val message = messageMap.get(currentMessageId).get
        messageMap.remove(currentMessageId)
        receive.apply(message)
        nextMessage()
      }
    //case m@_ =>
      //println("Actor " + actorNo + ": Processing message " + m)
      // add the massage to the hashmap
      // if the next required message is in the hashmap,
      // get it from the hashmap and apply it to the receive
  }


  override def become(behavior: Actor#Receive, discardOld: Boolean = true) {
    val currentBehavior =
      if (mode == Play)
        playPreBeh andThen behavior
      else if (mode == Replay)
        replayBeh
      else // if (mode == Deploy)
        behavior
    super.become(currentBehavior, discardOld)
  }

  protected def nextMessage() {
    var iter = messageSequence.iterator
    if (iter.hasNext) {
      currentMessageId = iter.next()
      messageSequence -= currentMessageId
    }
  }

  override def preStart() {
    if (mode == Replay) {
      messageSequence = messageSequences(actorId)
      nextMessage()
    }
    become(receive)
  }

  override def postStop() {
    if (mode == Play)
      messageSequences += (actorId -> messageSequence)
  }

}

object Mode extends Enumeration {
   type Mode = Value
   val Play, Replay, Detached = Value
}

object Actor {
  import Mode._

  val defaultFolder = "/media/MOHSENHD/1.Works/3.Research/0.Topics/0.Concurrency/1.Project/SAC/persisted/"
  val defaultFileName = "Communication.data"
  var messageSequences: ConcurrentMap[ActorId, ListBuffer[Pair[ActorId, Int]]] =
    new ConcurrentHashMap[ActorId, ListBuffer[Pair[ActorId, Int]]]

  var rootLastChildNo = 0

  // ----------------------------------------------------

  def actorOf(factory: ⇒ Actor)(implicit self: Option[ActorRef] = None): ActorRef = {
    if (mode != Detached) {
      val actorRef = new MyLocalActorRef(factory)
      actorRef.actor.asInstanceOf[Actor].actorId =
        self match {
          case Some(parent) =>
            val parentId = parent.actor.asInstanceOf[Actor].actorId
            parent.actor.asInstanceOf[Actor].lastChildNo += 1
            val lastChildNo = parent.actor.asInstanceOf[Actor].lastChildNo
            new ActorId(parentId, lastChildNo)
          case None =>
            rootLastChildNo += 1
            new ActorId(rootLastChildNo)
        }
      actorRef
    } else
      akka.actor.Actor.actorOf(factory)
  }

/*
  def actorOf[T <: Actor: Manifest]: ActorRef = {

  }
*/

  // ----------------------------------------------------
  var mode: Mode = _
  def play(code: => Unit) {
    mode = Play
    println("Play mode")
    start(code)
  }
  def replay(code: => Unit) {
    mode = Replay
    println("Replay mode")
    start(code)
  }
  def detached(code: => Unit) {
    mode = Detached
    println("Detached mode")
    start(code)
  }

  def start(code: => Unit) {
    preStart()
    val listener = akka.actor.Actor.actorOf(new RegistryListener({preFinish()})).start()
    akka.actor.Actor.registry.addListener(listener)
    code
  }

  def preStart() {
    if (mode == Replay) {
      val filename = defaultFolder + defaultFileName
      val fis = new FileInputStream(filename)
      val in = new ObjectInputStream(fis)
      messageSequences = (in.readObject()).asInstanceOf[ConcurrentMap[ActorId, ListBuffer[Pair[ActorId, Int]]]]
      in.close()
    }
  }

  def preFinish() {
    if (mode == Play) {
      val filename = defaultFolder + defaultFileName
      val fos = new FileOutputStream(filename)
      val out = new ObjectOutputStream(fos)
      out.writeObject(messageSequences)
      out.close()
    }
  }

}


