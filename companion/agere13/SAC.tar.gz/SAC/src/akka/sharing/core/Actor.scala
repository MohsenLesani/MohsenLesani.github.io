package akka.sharing.core

import akka.actor.ActorRef
import akka.sharing.map.core.{GenReadMap, GenMap}
import collection.mutable.{ListBuffer, HashMap}
import akka.sharing.map.reference.{GenReadMapImp, Update, MapImp}

trait Actor extends akka.actor.Actor {

  var writeMap: GenMap = null
  var readMap: GenReadMap = null

  protected def masterBeh(behavior: Actor#Receive): PartialFunction[Any, Unit] = {
    case m@Update(ver, update) =>
      updateBeh(m)
    case m@_ =>
      normalBeh(behavior)(m)
//      println("Here at preBeh")
  }

  var earlyUpdates = new HashMap[Int, Any]()
  var nextVer = 1 // Next version number that we are waiting for
  protected val updateBeh: PartialFunction[Any, Any] = {
    case m@Update(ver, update) =>
      //println("Received update no " + ver)
      earlyUpdates += (ver -> update)
      while (earlyUpdates.contains(nextVer)) {
        val theUpdate = earlyUpdates.remove(nextVer).get
        readMap.asInstanceOf[GenReadMapImp].versions += theUpdate
        nextVer += 1
      }
//      println("Here at preBeh")
  }

  protected def normalBeh(behavior: Actor#Receive): PartialFunction[Any, Unit] =
    preBeh andThen behavior andThen postBeh

  var thisVersion: Int = _
  private val preBeh: PartialFunction[Any, Any] = {
    case m@_ =>
//      println("Here at preBeh")
      if (readMap != null)
        thisVersion = readMap.update()
      if (writeMap != null)
        writeMap.changed = false
      m
  }

  private val postBeh: PartialFunction[Unit, Unit] = {
    case _ =>
//      println("Here at postBeh")
      if (writeMap != null)
        if (writeMap.changed)
          writeMap.atomicFlush()
  }

  def mainBecome(function: PartialFunction[Any, Unit], b: Boolean) {
    super.become(function)
  }

  override def become(behavior: Actor#Receive, discardOld: Boolean = true) {
    val currentBehavior = masterBeh(behavior)
    mainBecome(currentBehavior, discardOld)
  }

  override def preStart() {
    become(receive)
  }

}


object Actor {
  def actorOf(factory: ⇒ Actor)(implicit self: Option[ActorRef] = None): ActorRef = {
    akka.actor.Actor.actorOf(factory)
  }
}

