package akka.sharing.map.reference

import collection.mutable.{HashMap, ListBuffer}
import akka.sharing.map.core.ReadMap

trait GenReadMapImp {
  var versions = new ListBuffer[Any]()
}
class ReadMapImp[K, V](var currentVer: HashMap[K, V]) extends ReadMap[K, V] with GenReadMapImp {

  var waitingMessages: ListBuffer[Pair[HashMap[K,V], Int]] = _
  private[akka] def newUpdate(update: Any, ver: Int) {
    if (!reader.isRunning) {
      if (waitingMessages == null)
        waitingMessages = new ListBuffer[Pair[HashMap[K,V], Int]]()
      waitingMessages += new Pair(update.asInstanceOf[HashMap[K,V]], ver)
    } else {
      if (waitingMessages != null) {
        val iter = waitingMessages.iterator
        while (iter.hasNext) {
          val (update, ver) = iter.next()
          reader ! new Update(ver, update)
        }
        waitingMessages = null
      }
      reader ! new Update(ver, update)
    }
  }

  def get(k: K): Option[V] = currentVer.get(k)

  var ver = 0
  private[akka] def update(): Int = {
    val oldVersions = versions
    ver += oldVersions.size
//    println(ver)
    versions = new ListBuffer[Any]()
    val iter = oldVersions.iterator
    var currentVer: HashMap[K, V] = null
    while (iter.hasNext)
      currentVer = iter.next().asInstanceOf[HashMap[K, V]]

    if (currentVer != null)
      this.currentVer = currentVer

    ver
  }
}
