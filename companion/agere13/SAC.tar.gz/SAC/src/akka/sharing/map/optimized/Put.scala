package akka.sharing.map.optimized


case class Put[K, V](k:K, v:V) extends Update[K, V]
