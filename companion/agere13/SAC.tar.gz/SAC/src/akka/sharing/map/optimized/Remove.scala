package akka.sharing.map.optimized


case class Remove[K, V](k: K) extends Update[K, V]