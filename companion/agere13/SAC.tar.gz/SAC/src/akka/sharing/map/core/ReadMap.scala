package akka.sharing.map.core

import akka.sharing.core.Actor
import akka.actor.ActorRef


trait GenReadMap {
  var reader: ActorRef = _

  private[akka] def update(): Int

  def setReader(reader: ActorRef) {
    reader.actor.asInstanceOf[Actor].readMap = this
    this.reader = reader
  }
}


trait ReadMap[K, V] extends GenReadMap {

  def get(k: K): Option[V]

}

