package akka.sharing.map.optimized

import collection.mutable.ListBuffer

class UpdateNode[K, V](var ver: Int, var next: UpdateNode[K, V]) {

  var updates = new ListBuffer[Update[K,V]]()

  def addUpdate(update: Update[K,V]) {
    updates += update
  }

  def get(k: K): Option[V] = {
    for (update <- updates) {
      val res = update match {
        case Put(kp, v) if (k == kp) =>
          Some(Some(v))
        case Remove(kp) if (k == kp) =>
          Some(None)
        case _ =>
          None
      }
      if (res.isDefined)
        return res.get
    }
    None
  }

}

