package akka.sharing.map.optimized

import akka.sharing.map.core.ReadMap
import java.util.concurrent.atomic.AtomicReference
import akka.actor.ActorRef
import java.util.concurrent.ConcurrentHashMap
import collection.mutable.ConcurrentMap
import collection.JavaConversions._


class MapImp[K, V] extends akka.sharing.map.core.Map[K, V] {

  var map: ConcurrentMap[K, V] = new ConcurrentHashMap[K, V]

  val initNode: UpdateNode[K, V] = new UpdateNode[K, V](0, null)
  var head: AtomicReference[UpdateNode[K, V]] = new AtomicReference[UpdateNode[K, V]](initNode)
  var thisUpdateNode = new UpdateNode[K, V](1, initNode)

  def searchAndGet(updateNode: UpdateNode[K, V], k: K): Option[V] = {
    var current = updateNode
    while (current != null) {
      val res = current.get(k)
      if (res.isDefined)
        return res
      current = current.next
    }
    map.get(k)
  }

  override def get(k: K)(implicit self: Option[ActorRef] = None): Option[V] = {
    map.get(k)
    searchAndGet(thisUpdateNode, k)
  }

  override def put(k: K, v: V)(implicit self: Option[ActorRef] = None) {
    super.put(k, v)
    thisUpdateNode.addUpdate(new Put(k, v))
  }

  override def remove(k: K)(implicit self: Option[ActorRef] = None) {
    super.remove(k)
    thisUpdateNode.addUpdate(new Remove[K, V](k))
  }

  private[akka] def atomicFlush() {
    val prev = thisUpdateNode
    val prevVer = thisUpdateNode.ver
    val newVer: Int = prevVer + 1
    thisUpdateNode = new UpdateNode[K, V](newVer, prev)
    head.set(prev)
  }

  // -----------------------------------------------------------

  class ReadMapImp extends ReadMap[K, V] {
    var updateNode: UpdateNode[K, V] = _

    def get(k: K): Option[V] = {
      searchAndGet(updateNode, k)
    }

    private[akka] def update(): Int = {
      updateNode = head.get()
      updateNode.ver
    }

  }

  def newReadRef() = {
    new ReadMapImp()
  }

}


