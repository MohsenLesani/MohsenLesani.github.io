package akka.sharing.map.reference

import akka.sharing.map.core.ReadMap
import akka.actor.ActorRef
import collection.mutable.{ListBuffer, HashMap}
import java.util.concurrent.ConcurrentLinkedQueue
import akka.sharing.core.Actor

case class Update(ver: Int, update: Any)

class MapImp[K, V] extends akka.sharing.map.core.Map[K, V] {

  var map = new HashMap[K, V]()

  override def get(k: K)(implicit self: Option[ActorRef] = None): Option[V] = {
    map.get(k)
  }

  override def put(k: K, v: V)(implicit self: Option[ActorRef] = None) {
    super.put(k, v)
    map.put(k, v)
  }

  override def remove(k: K)(implicit self: Option[ActorRef] = None) {
    super.remove(k)
    map.remove(k)
  }

  val readRefs = new ConcurrentLinkedQueue[ReadMapImp[K, V]]()
  // ReadRefs can be potentially added by newReadRef() and iterated by atomicFlush() concurrently.

  var ver = 0
  private[akka] def atomicFlush() {
    val update = this.map
    this.map = map.clone()
    val iter = readRefs.iterator()
    ver += 1
    while (iter.hasNext) {
      val readRef = iter.next()
      readRef.newUpdate(update, ver)
    }
  }

  // -----------------------------------------------------------

  def newReadRef(): ReadMap[K, V] = {
    val snapshot = map.clone()
    val readMap = new ReadMapImp[K, V](snapshot)
    readRefs.add(readMap)
    readMap
  }

}





