package akka.sharing.map.core

import akka.actor.ActorRef
import akka.sharing.core.Actor
import java.util.concurrent.ConcurrentLinkedQueue

trait GenMap {
  var changed = false

  private[akka] def atomicFlush()
}


trait Map[K, V] extends GenMap {

  def get(k: K)(implicit self: Option[ActorRef] = None): Option[V]

  def put(k: K, v: V)(implicit self: Option[ActorRef] = None) {
    if (self.isDefined) {
      self.get.actor.asInstanceOf[Actor].writeMap = this
      changed = true
    }
  }

  def remove(k: K)(implicit self: Option[ActorRef] = None) {
    if (self.isDefined) {
      self.get.actor.asInstanceOf[Actor].writeMap = this
      changed = true
    }
  }

  private[akka] def newReadRef(): ReadMap[K, V]

}









//   If we get the snapshot first and then add to readers
//     may lose some updates
//   If we do the other way around
//     we may receive updates older than the snapshot
//     If it is an older update, it is ok.
//       The writer should update itself before updating others
//       because the write may miss us if he is in the middle of
//       updating. So we do not see the update.
//       But as the writer has updated himself first, we get
//       the update in the snapshot.
//     When it is a whole snapshot, it is a problem.
//       To have hot new reader we should send a subscribe
//       request to the writer actor and do the subscription
//       in there to have a consistent snapshot and new updates.
//   For now, we assume that the writer actor is not started yet!

