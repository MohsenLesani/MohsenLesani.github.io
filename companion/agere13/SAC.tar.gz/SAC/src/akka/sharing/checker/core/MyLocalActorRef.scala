package akka.sharing.checker.core

import akka.actor.{ActorRef, LocalActorRef}
import akka.checker.core.ActorId
import akka.sharing.map.reference.Update

case class PaddedMessage(messageId: Pair[ActorId, Int], msg: Any)

class MyLocalActorRef(factory: => Actor) extends LocalActorRef(() => factory, None) {

  def getMessageId(sender: Option[ActorRef]): (ActorId, Int) = {
    val actorNo =
      if (sender.isDefined)
        sender.get.actor.asInstanceOf[Actor].actorId
      else
        new ActorId(0)

    val messageNo =
      if (sender.isDefined) {
        sender.get.actor.asInstanceOf[Actor].messageNo += 1
        sender.get.actor.asInstanceOf[Actor].messageNo
      }
      else
        -1

    val messageId = (actorNo, messageNo)
    messageId
  }

  override def !(message: Any)(implicit sender: Option[ActorRef]) {
    message match {
      case Update(ver, update) =>
        super.!(message)
      case _ =>
        val messageId = getMessageId(sender)
        //println("Actor " + actorNo + ": ! (mId:" + messageId + "): " + message)

        super.!(PaddedMessage(messageId, message))
    }
  }

  override def !!(message: Any, timeout: Long)(implicit sender: Option[ActorRef]) = {
    message match {
      case Update(ver, update) =>
        super.!!(message)
      case _ =>
        val messageId = getMessageId(sender)
        //println("Actor " + actorNo + ": !! (mId:" + messageId + "): " + message)

        super.!!(PaddedMessage(messageId, message), timeout)
    }
  }

}

