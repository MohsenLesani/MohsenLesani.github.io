package akka.sharing.checker.core


import scala.collection.JavaConversions._
import java.io.{ObjectInputStream, FileInputStream, FileOutputStream, ObjectOutputStream}
import collection.mutable.{ConcurrentMap, ListBuffer, HashMap}
import java.util.concurrent.ConcurrentHashMap
import akka.actor.ActorRef
import akka.checker.core.{ActorId, RegistryListener}
import akka.sharing.map.reference.Update


trait Actor extends akka.sharing.core.Actor {

  import Actor._
  import Mode._

  var actorId: ActorId = _
  var lastChildNo = 0

  var messageNo = 0

//---------------------------------------------
  var paddedMessage = false
  private var messageSequence = new ListBuffer[Pair[ActorId, Int]]()
  private var verSequence = new ListBuffer[Int]()
  private val playPreBeh: PartialFunction[Any, Any] = {
    case PaddedMessage(messageId, message) =>
//      println("Actor " + actorId + ": Processing message " + messageId + ": " + message)
      messageSequence += messageId
//      println(message)
      paddedMessage = true
      message
    case m@_ =>
      paddedMessage = false
      m
  }

  private val playPostBeh: PartialFunction[Unit, Unit] = {
    case _ =>
      if (paddedMessage)
        verSequence += thisVersion
//      println(self + " thisVersion = " + thisVersion)
  }

//---------------------------------------------

  var currentMessageId: Pair[ActorId, Int] = _
  var currentVer: Int = _
  val waitingMessages = new HashMap[Pair[ActorId, Int], Any]()
  var waitingUpdates = new ListBuffer[Update]()
  var passedVers = 0

  private def replayBeh(behavior: Actor#Receive): PartialFunction[Any, Unit] = {
    case m@Update(ver, update) =>
      if (ver <= currentVer) {
        passedVers += 1
        updateBeh(m)
        if (passedVers == currentVer)
          check(behavior)
      } else
        waitingUpdates += m
    case PaddedMessage(messageId, message) =>
      //println("Actor " + actorId + ": Processing message " + messageId + ": " + message)
      waitingMessages += (messageId -> message)
//      println(message)
      if (currentMessageId == messageId)
        check(behavior)
  }

  def check(behavior: Actor#Receive) {
    while (!finished && waitingMessages.containsKey(currentMessageId) && passedVers == currentVer) {
//      println(self + "passedVers = " + passedVers)
      val message = waitingMessages.get(currentMessageId).get
      waitingMessages.remove(currentMessageId)
      normalBeh(behavior)(message)
      nextMessage()
      if (!finished) {
        val newUpdateMap = new ListBuffer[Update]()
        for (m <- waitingUpdates) {
          m match {
            case Update(ver, update) =>
              if (ver <= currentVer) {
                passedVers += 1
                updateBeh(m)
              } else
                newUpdateMap += m
          }
        }
        waitingUpdates = newUpdateMap
      }
    }
  }

  var finished = false
  protected def nextMessage() {
    var iter = messageSequence.iterator
    if (iter.hasNext) {
      currentMessageId = iter.next()
      messageSequence -= currentMessageId
    } else {
      finished = true
      return
    }
    var iter2 = verSequence.iterator
    if (iter2.hasNext) {
      currentVer = iter2.next()
      verSequence -= currentVer
    }
//    println(self + "currentVer = " + currentVer)
  }

//---------------------------------------------
  override def become(behavior: Actor#Receive, discardOld: Boolean = true) {
    val currentBehavior =
      if (mode == Play)
        playPreBeh andThen masterBeh(behavior) andThen playPostBeh
      else if (mode == Replay)
        replayBeh(behavior)
      else // if (mode == Deploy)
        masterBeh(behavior)

    mainBecome(currentBehavior, discardOld)
  }

  override def preStart() {
    if (mode == Replay) {
      messageSequence = messageSequences(actorId)
      verSequence = verSequences(actorId)
      nextMessage()
    }
    become(receive)
  }

  override def postStop() {
    if (mode == Play) {
      messageSequences += (actorId -> messageSequence)
      verSequences += (actorId -> verSequence)
    }
  }

}

object Mode extends Enumeration {
   type Mode = Value
   val Play, Replay, Detached = Value
}

object Actor {
  import Mode._

  val defaultFolder = "/media/MOHSENHD/1.Works/3.Research/0.Topics/0.Concurrency/1.Project/SAC/persisted/"
  val defaultFileName = "Communication2.data"
  var messageSequences: ConcurrentMap[ActorId, ListBuffer[Pair[ActorId, Int]]] =
    new ConcurrentHashMap[ActorId, ListBuffer[Pair[ActorId, Int]]]
  var verSequences: ConcurrentMap[ActorId, ListBuffer[Int]] =
    new ConcurrentHashMap[ActorId, ListBuffer[Int]]
  var rootLastChildNo = 0

  // ----------------------------------------------------

  def actorOf(factory: ⇒ Actor)(implicit self: Option[ActorRef] = None): ActorRef = {
    if (mode != Detached) {
      val actorRef = new MyLocalActorRef(factory)
      actorRef.actor.asInstanceOf[Actor].actorId =
        self match {
          case Some(parent) =>
            val parentId = parent.actor.asInstanceOf[Actor].actorId
            parent.actor.asInstanceOf[Actor].lastChildNo += 1
            val lastChildNo = parent.actor.asInstanceOf[Actor].lastChildNo
            new ActorId(parentId, lastChildNo)
          case None =>
            rootLastChildNo += 1
            new ActorId(rootLastChildNo)
        }
      actorRef
    } else
      akka.actor.Actor.actorOf(factory)
  }

/*
  def actorOf[T <: Actor: Manifest]: ActorRef = {

  }
*/

  // ----------------------------------------------------
  var mode: Mode = _
  def play(code: => Unit) {
    mode = Play
    println("Play mode")
    start(code)
  }
  def replay(code: => Unit) {
    mode = Replay
    println("Replay mode")
    start(code)
  }
  def detached(code: => Unit) {
    mode = Detached
    println("Detached mode")
    start(code)
  }

  def start(code: => Unit) {
    preStart()
    val listener = akka.actor.Actor.actorOf(new RegistryListener({preFinish()})).start()
    akka.actor.Actor.registry.addListener(listener)
    code
  }

  def preStart() {
    if (mode == Replay) {
      val filename = defaultFolder + defaultFileName
      val fis = new FileInputStream(filename)
      val in = new ObjectInputStream(fis)
      messageSequences = (in.readObject()).asInstanceOf[ConcurrentMap[ActorId, ListBuffer[Pair[ActorId, Int]]]]
      verSequences = (in.readObject()).asInstanceOf[ConcurrentMap[ActorId, ListBuffer[Int]]]
      in.close()
    }
  }

  def preFinish() {
    if (mode == Play) {
      val filename = defaultFolder + defaultFileName
      val fos = new FileOutputStream(filename)
      val out = new ObjectOutputStream(fos)
      out.writeObject(messageSequences)
      out.writeObject(verSequences)
      out.close()
    }
  }
  // ----------------------------------------------------

}





