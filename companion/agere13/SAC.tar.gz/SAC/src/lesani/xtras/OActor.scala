package lesani.xtras

import java.util.concurrent.locks.ReentrantLock

import scala.collection.mutable.Map
import java.util.LinkedList

//object Actor {
//  private var thisTransactor: ThreadLocal[Actor] = _
//  def self = thisTransactor.get
//}

class OActor {

//  import Actor._

	//--------------------------------------------------------------------
	private val mailbox = new LinkedList[Any]
	//  private val mailbox = new ThreadSafeLinkedQueue[T]

  val lock = new ReentrantLock()
  var body: PartialFunction[Any, Unit] = _

  //--------------------------------------------------------------------

//	def this(body: PartialFunction[Any, Unit]) {
//    thisTransactor = new ThreadLocal[Actor].asInstanceOf[ThreadLocal[Actor[Any]]]
//    thisTransactor.set(Actor.this.asInstanceOf[Actor[Any]])
//    this.body = body
//  }

	def start() {

//		launchThread {
//      while (true) {
//        val message = receive
//        body(message)
//      }
//		}
  }

	//--------------------------------------------------------------------

  def !(msg: Any): Unit = {
    lock.lock()
    mailbox.add(msg)
    lock.unlock()
	}

	//--------------------------------------------------------------------

	def receive(): Any = {
//    lock.lock
//    var cell: Cell[T] = null
//    if (currentTrans != null)
//      currentTrans.setTransactor(this)
//
//		var iter = mailbox.iterator()
//    var done = !iter.hasNext()
//		while (!done) {
//			cell = iter.next()
//
//			if (currentTrans == null)  //out of trans
//				done = cell.isStable()
//			else
//				done = !cell.isAnnihilated()
//      done  = !iter.hasNext() || done
//		}
//
//    val empty = !iter.hasNext()

    // Check to suspend if the previous loop could not find the required message.
  }
}












