package lesani.actor.core

import akka.actor.{ActorInitializationException, ScalaActorRef, ActorRef}
import akka.util.ReflectiveAccess.TypedActorModule
import akka.event.EventHandler
import akka.dispatch.{Future, FutureTimeoutException, MessageDispatcher}

/*
class ActorRefDec(mainRef: ActorRef) extends ActorRef { self: ScalaActorRef =>

  override def toString() = mainRef.toString()

  override def equals(that: Any) = mainRef.equals(that)

  override def hashCode() = mainRef.hashCode()

  override protected def actor = mainRef.actor

  override def getChannel = mainRef.getChannel

  override def channel = mainRef.channel

  override def getLinkedActors() = mainRef.getLinkedActors()

  override def getSupervisor() = mainRef.getSupervisor()

  override def getMailboxSize() = mainRef.getMailboxSize()

  override def mailboxSize = mainRef.mailboxSize

  override def exit() { mainRef.exit() }

  @scala.deprecated("Will be removed without replacement, doesn't make any sense to have in the face of `become` and `unbecome`")
  override def getActorClassName() = mainRef.getActorClassName()

  @scala.deprecated("Will be removed without replacement, doesn't make any sense to have in the face of `become` and `unbecome`")
  override def getActorClass() = mainRef.getActorClass()

  override def replySafe(message: AnyRef) = mainRef.replySafe(message)

  override def replyUnsafe(message: AnyRef) { mainRef.replyUnsafe(message) }

  override def forward(message: AnyRef, sender: ActorRef) { mainRef.forward(message, sender) }

  override def sendRequestReplyFuture[T <: AnyRef](message: AnyRef, timeout: Long, sender: ActorRef) = mainRef.sendRequestReplyFuture(message, timeout, sender)

  override def sendRequestReplyFuture[T <: AnyRef](message: AnyRef, sender: ActorRef) = mainRef.sendRequestReplyFuture(message, sender)

  override def sendRequestReplyFuture[T <: AnyRef](message: AnyRef) = mainRef.sendRequestReplyFuture(message)

  override def sendRequestReply(message: AnyRef, timeout: Long, sender: ActorRef) = mainRef.sendRequestReplyFuture(message, timeout, sender)

  override def sendRequestReply(message: AnyRef, sender: ActorRef) = mainRef.sendRequestReplyFuture(message, sender)

  override def sendRequestReply(message: AnyRef) = mainRef.sendRequestReplyFuture(message)

  override def sendOneWay(message: AnyRef, sender: ActorRef) { mainRef.sendOneWay(message, sender) }

  override def sendOneWay(message: AnyRef) { mainRef.sendOneWay(message) }

  override protected def uuid_=(uid: _root_.akka.actor.Uuid) { mainRef.uuid_=(uid) }

  @scala.deprecated("Will be removed without replacement, it's just not reliable in the face of `become` and `unbecome`")
  override def isDefinedAt(message: Any) = mainRef.isDefinedAt(message)

  override def isUnstarted = mainRef.isUnstarted

  override def isShutdown = mainRef.isShutdown

  override def isRunning = mainRef.isRunning

  override def isBeingRestarted = mainRef.isBeingRestarted

  override def getSenderFuture() = mainRef.getSenderFuture()

  override def getSender() = mainRef.getSender()

  override def uuid = mainRef.uuid

  override def getUuid() = mainRef.getUuid()

  override def compareTo(other: ActorRef) = mainRef.compareTo(other)

  override protected var currentMessage = mainRef.currentMessage
  override protected var hotswap = mainRef.hotswap

  @scala.deprecated("Remoting will become fully transparent in the future")
  override def getHomeAddress() = mainRef.getHomeAddress()

  override def getDispatcher() = mainRef.getDispatcher()

  override def setDispatcher(dispatcher: MessageDispatcher) { mainRef.setDispatcher(dispatcher) }

  override def getReceiveTimeout() = mainRef.getReceiveTimeout()

  override def setReceiveTimeout(timeout: Long) { mainRef.setReceiveTimeout() }

  override var receiveTimeout = mainRef.receiveTimeout

  @scala.deprecated("Will be replaced by implicit-scoped timeout on all methods that needs it, will default to timeout specified in config")
  override def setTimeout(x$1: Long) { mainRef.setTimeout(x$1) }

  @scala.deprecated("Will be replaced by implicit-scoped timeout on all methods that needs it, will default to timeout specified in config")
  @scala.deprecated("Will be replaced by implicit-scoped timeout on all methods that needs it, will default to timeout specified in config")
  override def getTimeout() = mainRef.getTimeout()

  override var timeout = mainRef.timeout

  override def setId(x$1: String) { mainRef.setId(x$1) }

  override def getId() = mainRef.getId()

  override var id = mainRef.id
  override protected[this] var _status = mainRef._status
  override protected var _uuid = mainRef._uuid

  override def !(message: Any)(implicit sender: Option[ActorRef] = None): Unit = {
    println("Inside !")
    if (isRunning) postMessageToMailbox(message, sender)
    else throw new ActorInitializationException(
      "Actor has not been started, you need to invoke 'actor.start()' before using it")
  }

  override def !!(message: Any, timeout: Long = this.timeout)(implicit sender: Option[ActorRef] = None): Option[Any] = {
    if (isRunning) {
      val future = postMessageToMailboxAndCreateFutureResultWithTimeout[Any](message, timeout, sender, None)
      val isMessageJoinPoint = if (isTypedActorEnabled) TypedActorModule.resolveFutureIfMessageIsJoinPoint(message, future)
      else false
      try {
        future.await
      } catch {
        case e: FutureTimeoutException ⇒
          if (isMessageJoinPoint) {
            EventHandler.error(e, this, e.getMessage)
            throw e
          } else None
      }
      future.resultOrException
    } else throw new ActorInitializationException(
      "Actor has not been started, you need to invoke 'actor.start()' before using it")
  }

  override def !!![T](message: Any, timeout: Long = this.timeout)(implicit sender: Option[ActorRef] = None): Future[T] = {
    if (isRunning) postMessageToMailboxAndCreateFutureResultWithTimeout[T](message, timeout, sender, None)
    else throw new ActorInitializationException(
      "Actor has not been started, you need to invoke 'actor.start()' before using it")
  }

}
*/



