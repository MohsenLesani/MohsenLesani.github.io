package lesani.actor.cases.pure.tree

case class Message(cno: Int, mno: Int)
