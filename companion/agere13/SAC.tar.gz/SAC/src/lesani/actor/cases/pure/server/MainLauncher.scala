package lesani.actor.cases.pure.server

import akka.checker.core.Actor._
import akka.actor.ActorRef



object MainLauncher {

  val clientCount = 7

  def main(args: Array[String]) {
//    play({
    replay({
//    detached({
      val server = actorOf(new Server)
      server.start()

      val clients = new Array[ActorRef](clientCount)
      for(i <- 0 until clientCount) {
        clients(i) = actorOf(new Client(i, server))
        clients(i).start()
      }
    })
  }

}


