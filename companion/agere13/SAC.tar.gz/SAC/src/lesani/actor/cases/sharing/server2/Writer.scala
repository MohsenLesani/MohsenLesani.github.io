package lesani.actor.cases.sharing.server2

//import akka.actor.Actor
import akka.checker.core.Actor


class Writer(map: Map[Int, Int]) extends Actor {
  import MainLauncher._


  override def preStart() {
    super.preStart()
    self ! "update"
  }

  def receive = {
    case "update" =>
      // update the map
      //if (updates == enough updates)
      //  self.stop()
  }

}
