package lesani.actor.cases.sharing.server1

//import akka.actor.Actor
//import akka.sharing.core.Actor
import akka.sharing.checker.core.Actor
import akka.sharing.map.core.ReadMap


class Reader(map: ReadMap[Int, Int]) extends Actor {
  import MainLauncher._

  override def preStart() {
    super.preStart()
    self ! "ReadValue"
  }

  var count = 0
  def receive = {
    case "ReadValue" =>
      val option = map.get(0)
      val v = option match {
        case Some(vp) =>
          vp
        case None =>
          "No value yet"
      }
      println("The value: " + v)
      count += 1
      if (count == readCount)
        self.stop()
      else
        self ! "ReadValue"

/*
    case m@_ =>
      println("Actor " + actorNo + ": Processed " + m)
*/
  }
}

