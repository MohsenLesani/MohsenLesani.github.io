package lesani.actor.cases.pure.tree

//import akka.actor.Actor

import akka.checker.core.Actor
import akka.checker.core.Actor._


class Client1(clientNo: Int) extends Actor {
  import MainLauncher._

  override def preStart() {
    super.preStart()
    self ! "SendMessage"
  }

  def receive = {
    case "SendMessage" =>
      for(i <- 0 until clinetCount)
        actorOf(new Client2(i)).start()
      self.stop()

/*
    case m@_ =>
      println("Actor " + actorNo + ": Processed " + m)
*/
  }

}