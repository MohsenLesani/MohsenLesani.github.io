package lesani.actor.cases.sharing.server2

case class Message(cno: Int, mno: Int)
