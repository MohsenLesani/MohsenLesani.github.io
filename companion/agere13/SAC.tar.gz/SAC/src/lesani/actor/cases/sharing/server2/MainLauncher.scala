package lesani.actor.cases.sharing.server2

import akka.checker.core.Actor._
import akka.actor.ActorRef
import akka.sharing.map.reference.MapImp

object MainLauncher {

  val readerCount = 7

  def main(args: Array[String]) {
    play({
//    replay({
//    detached({

//      val map = new MapImp()
//
//      val writer = actorOf(new Writer(map))
//      writer.start()
//
//      val readers = new Array[ActorRef](readerCount)
//      for(i <- 0 until readerCount) {
//        readers(i) = actorOf(new Reader(i))
//        val mapReadRef = map.newReadRef(readers(i))
//        readers(i).mapReadRef = mapReadRef
//        readers(i).start()
//      }
//
//      val server = actorOf(new Server(readers))
//      server.start()

    })
  }
}


