package lesani.actor.cases.sharing.server1

//import akka.actor.Actor
//import akka.sharing.core.Actor
import akka.sharing.checker.core.Actor
import akka.sharing.map.core.Map


class Writer(map: Map[Int, Int]) extends Actor {
  import MainLauncher._

  override def preStart() {
    super.preStart()
    self ! "SelfMessage"
  }

  var count = 0
  def receive = {
    case "SelfMessage" =>
      count += 1
      map.put(0, count)
//      println("Updating to " + count)
      if (count == updateCount)
        self.stop()
      else
        self ! "SelfMessage"
  }

}
