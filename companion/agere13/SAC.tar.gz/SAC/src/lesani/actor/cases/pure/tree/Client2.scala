package lesani.actor.cases.pure.tree

//import akka.actor.Actor
import akka.checker.core.Actor

import akka.actor.ActorRef


class Client2(clientNo: Int) extends Actor {

  override def preStart() {
    super.preStart()
    self ! "SendMessage"
  }

  def receive = {
    case "SendMessage" =>
      self.stop()
/*
    case m@_ =>
      println("Actor " + actorNo + ": Processed " + m)
*/
  }

}