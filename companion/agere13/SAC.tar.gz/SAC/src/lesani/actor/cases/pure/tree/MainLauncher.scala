package lesani.actor.cases.pure.tree

import akka.checker.core.Actor._
import akka.actor.ActorRef


object MainLauncher {

  val clinetCount = 3

  def main(args: Array[String]) {
    play({
//    replay({
//    detached({

      for(i <- 0 until clinetCount)
        actorOf(new Client1(i)).start()
    })
  }

}

