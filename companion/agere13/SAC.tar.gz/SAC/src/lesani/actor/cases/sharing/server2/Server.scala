package lesani.actor.cases.sharing.server2

//import akka.actor.Actor
import akka.checker.core.Actor


class Server extends Actor {
  var clients = 0

  def receive = {
    case m@Message(cno, mno) =>
//      val no = cno*3 + mno
//      println("Processed message no. " + no)
//      clients += 1
//      if (clients == clientCount * 3)
//        self.stop()
  }

}


// if a message is send by !! it should be replied by reply not !.