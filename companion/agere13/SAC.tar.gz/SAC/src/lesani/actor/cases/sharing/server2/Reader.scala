package lesani.actor.cases.sharing.server2

//import akka.actor.Actor
import akka.checker.core.Actor
import akka.sharing.map.core.ReadMap


class Reader(clientNo: Int) extends Actor {
  var mapReadRef: ReadMap[Int, Int] = _

  override def preStart() {
    super.preStart()
    self ! "SendMessage"
  }

  def receive = {
    case "SendMessage" =>
//      server ! Message(clientNo, 1)
//      self ! "SendMessage2"
//    case "SendMessage2" =>
//      server ! Message(clientNo, 2)
//      self ! "SendMessage3"
//    case "SendMessage3" =>
//      server ! Message(clientNo, 3)
//      self.stop()
/*
    case m@_ =>
      println("Actor " + actorNo + ": Processed " + m)
*/
  }

}