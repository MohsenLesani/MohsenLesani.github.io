package lesani.actor.cases.sharing.server1

import akka.sharing.checker.core.Actor._

object MainLauncher {

  val updateCount = 50
  val readCount = 50

  def main(args: Array[String]) {

    play({
      import akka.sharing.map.optimized.MapImp

//    replay({
//      import akka.sharing.map.reference.MapImp

//    detached({
//      import akka.sharing.map.reference.MapImp

      val map = new MapImp[Int, Int]()

      val readMap = map.newReadRef()

      val writer = actorOf(new Writer(map))

      val reader = actorOf(new Reader(readMap))
      readMap.setReader(reader)

      writer.start()
      reader.start()

    })
  }
}

