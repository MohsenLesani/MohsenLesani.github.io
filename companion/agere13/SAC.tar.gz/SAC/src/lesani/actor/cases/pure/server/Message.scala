package lesani.actor.cases.pure.server

case class Message(cno: Int, mno: Int)
