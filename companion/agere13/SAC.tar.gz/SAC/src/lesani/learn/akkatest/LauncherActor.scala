package lesani.learn.akkatest

//import lesani.actor.core.Actor
//
//class LauncherActor(code: => Unit) extends Actor {
//
//  protected def receive = {
//    case "finish" =>
//      akka.actor.Actor.registry.shutdownAll()
//
//    case "ok" =>
//    case _ =>
//      code
//      self ! "finish"
//  }
//}

