package lesani.learn.akkatest

import akka.actor.Actor._
import akka.stm._
import akka.actor.{ActorRef, Actor}


object AkkaLauncher {

  val ref = Ref(0)

  class Actor1(a2: ActorRef) extends Actor {
    def receive = {
      case "Test" => {
        atomic {
          a2 ! "Test"
          while(true) {}
        }
      }
      case _ => println("Default")
    }
  }

  class Actor2 extends Actor {
    def receive = {
      case "Test" => {
        atomic {
          ref alter (_ + 2)
        }
        atomic {
          println (ref.get)
        }
      }
      case _ => println("Default")
    }
  }

  def main(args: Array[String]) {
    val a2 = actorOf[Actor2]
    a2.start()
    val a1 = actorOf(new Actor1(a2))
    a1.start()
    a1 ! "Test"
  }
}

/*
  def main(args: Array[String]) {
    val a = actorOf(new MyActor(10))

    a.start()

    a ! "TestMessage"
    a ! "AMessage"


    a.stop()
  }
*/

/*
  class LauncherActor extends Actor {

    def initCode() {
      val a = actorOf(new Server())

      a.start()

      a ! "TestMessage"
      a !! "AMessage"

      a.stop()
    }

    protected def receive = {
      case "finish" =>
        akka.actor.Actor.registry.shutdownAll()
      case "ok" =>
      case _ =>
        initCode()
        self ! "finish"
    }
  }

  def main(args: Array[String]) {

    val a = actorOf(new LauncherActor)
    a.start()
    a ! "start"
  }
*/





// TODO:
// (parent, parent, current) scheme for actor no.