package lesani.actor.test


class Packet(s: String)