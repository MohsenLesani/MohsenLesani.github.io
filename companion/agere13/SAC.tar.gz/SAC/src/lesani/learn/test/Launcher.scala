package lesani.actor.test



object Launcher {

  def main(args: Array[String]) {

//    val actor1 = new Actor ({
//      case /*lesani.learn.test.*/Packet(s) =>
//        println("Actor 1")
//      case _ =>
//        println("_")
//    })

    class C1 {
      def m1() { println("C1.m1") }
    }

    class C2 extends C1 {
      override def m1() { println("C2.m1") }
      def m2() { println("C2.m2") }
    }

    trait T1 extends C1 {
      def f() { println("T1.f") }
      override def m1() { println("T1.m1") }
    }

    class C3 extends C2 with T1 {
      override def f() { println("C3.f") }
    }

    val c3 = new C3()

    c3.f
    c3.m1
    c3.m2

  }

}