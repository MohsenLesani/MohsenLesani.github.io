package lesani.actor.test


object AnApplication extends App {
  println("Echo" + (args mkString " "))
}