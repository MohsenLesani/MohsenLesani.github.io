package lesani.learn.test

object Launcher2 {

  def main(args: Array[String]) {
//    val actor1 = new Actor ({
//      case /*lesani.learn.test.*/Packet(s) =>
//        println("Actor 1")
//      case _ =>
//        println("_")
//    })

/*
    class C1 {
      def m1() { println("C1.m1") }
    }

    trait T1 {
      /*override*/ def m1() { println("T1.m1") }
    }

    class C3 extends C1 with T1 {
      override def m1() {
        println("C3.m1")
        super.m1
//        this.T1.m1
      }
    }

    val c3 = new C3()

//    c3.f
    c3.m1
*/



  }

}