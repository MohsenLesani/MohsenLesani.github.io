package lesani.learn.test

import collection.mutable.ListBuffer


object Launcher3 {

  def main(args: Array[String]) {

    var list = new ListBuffer[Int]()

    list += 1
    list += 2
    list += 3

    list foreach(i =>
      println(i)
    )

    val list2 = list :+ 4

    println("list")
    list foreach(i =>
      println(i)
    )

    println("list2")
    list2 foreach(i =>
      println(i)
    )


//    var iter = list.iterator
//    while (iter.hasNext) {
//      val i = list.iterator.next()
//      println(i)
//      list -= i
//      iter = list.iterator
//    }

  }

}