Sharing Actors Checker


Note that this releases only the checker and not the optimized implementation.




