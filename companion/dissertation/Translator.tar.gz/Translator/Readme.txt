
/src
   The java source folder.
   The main class is
   speclang.xlator.Launcher
/cases/specs/
   The specifications folder


