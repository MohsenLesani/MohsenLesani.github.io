package test;

public class Test {
   public static void main(String[] args) {
      String val = "(- 123)";
      val = val.substring(3, val.length() - 1);
      System.out.println(val);
   }
}
