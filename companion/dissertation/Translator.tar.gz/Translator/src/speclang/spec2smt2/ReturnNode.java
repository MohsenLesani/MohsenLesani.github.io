package speclang.spec2smt2;

import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import speclang.spec.ast.tree.expression.op.atom.Val;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.statement.Return;
import speclang.spec.ast.visitor.SVisitor;

public class ReturnNode extends XNode {

   public Return theReturn;

   public ReturnNode(Return theReturn, GCond cond, int tId, int indent) {
      super(cond, tId, indent);
      this.theReturn = theReturn;
   }


   @Override
   public String getLabel() {
      return getLabel(theReturn);
   }

   @Override
   public String toString() {

      final ExpPrinter printer = new ExpPrinter(preLabel);

      String s = printFlatLabel();
//      String s = "";
      for (int i = 0; i < level*3; i++) {
         s += " ";
      }

      s += "return ";
      s += theReturn.varl.apply(
         new Fun0<String>() {
            public String apply() {
               return "";
            }
         },
         new Fun<Varl, String>() {
            public String apply(Varl varl) {
               return varl.accept(printer);
            }
         }
      );


//      return s + methodCall.toString();
      return s;
   }

}
