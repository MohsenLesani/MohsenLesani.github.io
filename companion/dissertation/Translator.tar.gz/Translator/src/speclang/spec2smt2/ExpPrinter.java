package speclang.spec2smt2;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.tree.expression.op.Op;
import speclang.spec.ast.tree.expression.op.atom.Val;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.visitor.SVisitor;

class ExpPrinter implements SVisitor.BoolExpVisitor<String> {
   public String preLabel = "";

   ExpPrinter() {
   }

   ExpPrinter(String preLabel) {
      this.preLabel = preLabel;
   }

   public String visitDistch(BoolExp exp) {
      return exp.accept(this);
   }
   public String visit(Op op) {
      String s = "";
      if (op.getOperands().length == 1) {
         s += op.getLexeme();
         s += visitDistch(op.getOperands()[0]);
      } else {
         s += visitDistch(op.getOperands()[0]);
         s += op.getLexeme();
         s += visitDistch(op.getOperands()[1]);
      }
      return s;
   }

   public String visit(Varl varl) {
      SVisitor.VarlVisitor<String> varlVisitor = new SVisitor.VarlVisitor<String>() {
         public String visit(Var var) {
            // To have the variables prefixed:
            // return new GVar(preLabel, var).getFlatName();
            return new GVar("", var).getFlatName();
         }

         public String visit(Val val) {
            return val.toString();
         }
      };

      return varl.accept(varlVisitor);
   }
}