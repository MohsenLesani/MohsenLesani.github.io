package speclang.spec2smt2.xtras;

import lesani.compiler.texttree.Snippet;
import lesani.compiler.texttree.Text;
import speclang.spec.ast.tree.statement.Statement;

public class Label {
   public static Text gen(Statement statement) {
      final String s = "L<" + statement.lineNo + "." + statement.columnNo + ">";
      return new Snippet(s);
   }
}
