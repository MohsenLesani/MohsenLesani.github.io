package speclang.spec2smt2;

import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import lesani.collection.option.Option;
import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.statement.MethodCall;
import speclang.spec.ast.tree.statement.Statement;

import java.util.Set;

public class ThisCallRetNode extends XNode {
   public Set<GNode> nesteds;
   public ThisCallInvNode invNode;
   public Set<ReturnNode> returnNodes;
   public MethodCall methodCall;

   public ThisCallRetNode(MethodCall methodCall, GCond cond, int tId, int level) {
      super(cond, tId, level);
      this.methodCall = methodCall;
   }


   @Override
   public String getLabel() {
      return getLabel(methodCall) + "_Ret";
   }

   public Option<String> getFlatVarName() {
      return methodCall.retv.apply(
         new Fun<Var, String>() {
            public String apply(Var var) {
               final String varName = var.id.name;
               return (preLabel.equals("")) ? varName : preLabel + "." + varName;
            }
         }
      );
   }

   @Override
   public String toString() {
      String s = printFlatLabel();
//      String s = "";
      for (int i = 0; i < level *3; i++) {
         s += " ";
      }

//      String args = "";
//      for (int i = 0; i < methodCall.args.length; i++) {
//         Varl arg = methodCall.args[i];
//         args += arg.toString();
//         if (i != methodCall.args.length - 1)
//            args += ", ";
//      }
//      s += methodCall.obj.name + "." + methodCall.name.name +
//            "(" + args + ")";
      s += "ret(";
      s += methodCall.retv.apply(
         new Fun0<String>() {
            public String apply() {
               return "";
            }
         },
         new Fun<Var, String>() {
            public String apply(Var var) {
               return var.id.name;
            }
         }
      );
      s += ")";
//      return s + methodCall.toString();
      return s;
   }

//   @Override
//   public Option<String> getFlatVarName() {
//      return super.getFlatVarName().apply(
//            new Fun<String, String>() {
//               public String apply(String s) {
//                  return "Ret" + s;
//               }
//            }
//      );
//   }

   //   @Override
//   public boolean isExec() {
//      for (GNode nested : nesteds) {
//         if (nested.isExec())
//            return true;
//      }
//      return false;
//   }
}
