package speclang.spec.astbuild.intastnodes.expressions;


import speclang.spec.ast.tree.expression.BoolExp;
import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;

public class IntExp extends LocInfo implements Node {
    public BoolExp expression;

    public IntExp(BoolExp expression) {
        this.expression = expression;
    }
}
