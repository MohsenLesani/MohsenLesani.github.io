package speclang.spec.astbuild.intastnodes.declarations;

import speclang.spec.ast.tree.token.Id;
import lesani.compiler.ast.Node;


public class FunOutput implements Node {

    public Id[] outputParams;

    public FunOutput(Id[] outputParams) {
        this.outputParams = outputParams;
    }
}
