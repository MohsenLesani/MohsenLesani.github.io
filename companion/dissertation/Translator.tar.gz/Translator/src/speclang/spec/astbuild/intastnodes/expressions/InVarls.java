package speclang.spec.astbuild.intastnodes.expressions;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.expression.op.atom.Varl;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Dec 9, 2010
 * Time: 3:40:24 PM
  */
public class InVarls extends LocInfo implements Node {
   public Varl[] varls;

   public InVarls(Varl[] varls) {
      this.varls = varls;
   }
}