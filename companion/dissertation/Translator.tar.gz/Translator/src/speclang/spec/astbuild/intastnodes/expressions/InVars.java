package speclang.spec.astbuild.intastnodes.expressions;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.expression.op.atom.Var;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Dec 9, 2010
 * Time: 3:40:24 PM
  */
public class InVars extends LocInfo implements Node {
   public Var[] vars;

   public InVars(Var[] vars) {
      this.vars = vars;
   }
}

