package speclang.spec.astbuild.intastnodes.assertion;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.assertion.Asser;

public class InAsser extends LocInfo implements Node {
   public Asser asser;

   public InAsser(Asser asser) {
      this.asser = asser;
   }
}
