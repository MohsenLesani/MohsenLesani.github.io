package speclang.spec.astbuild.intastnodes;

import lesani.collection.option.Option;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.declaration.Label;

public class InLabel implements Node {
   public Option<Label> labelOption;

   public InLabel(Option<Label> labelOption) {
      this.labelOption = labelOption;
   }
}
