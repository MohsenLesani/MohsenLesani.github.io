package speclang.spec.astbuild.intastnodes.statement;

import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.statement.Statement;
import speclang.spec.ast.visitor.SVisitor;

/*
 User: lesani, Date: Nov 2, 2009, Time: 1:50:45 PM
*/

public class Block implements Node {

    public Statement[] statements;

    public Block(Statement[] statements) {
        this.statements = statements;
    }
}