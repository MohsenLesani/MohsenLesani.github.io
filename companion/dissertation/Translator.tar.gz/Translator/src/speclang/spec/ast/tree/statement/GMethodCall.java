package speclang.spec.ast.tree.statement;

import lesani.collection.option.None;
import lesani.collection.option.Option;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;


public abstract class GMethodCall extends Statement {

   public Id obj;
   public Option<Varl> index = None.instance();
   public Id name;
   public Varl[] args;
   public Option<Var> retv;

   public GMethodCall(Option<Label> label, Id obj, Id name, Varl[] args, Option<Var> retv) {
      super(label);
      this.obj = obj;
      this.name = name;
      this.args = args;
      this.retv = retv;
   }

   public Option<Label> getLabel() {
      return label;
   }

   @Override
   public String toString() {
      return label + ">  " + obj.name + "." + name.name + "(...)";
   }
}

