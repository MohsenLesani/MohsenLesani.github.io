package speclang.spec.ast.tree.expression.op.relational;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.tree.expression.op.Op;
import speclang.spec.ast.visitor.SVisitor;


public abstract class RelationalOp extends Op {
    public BoolExp operand1;
    public BoolExp operand2;

    protected RelationalOp(BoolExp operand1, BoolExp operand2) {
        this.operand1 = operand1;
        this.operand2 = operand2;
    }

    public <R> R accept(SVisitor.BoolExpVisitor.OpVisitor<R> v) {
        return v.visit(this);
    }

    public abstract <R> R accept(SVisitor.BoolExpVisitor.OpVisitor.RelationalVisitor<R> v);

    @Override
    public BoolExp[] getOperands() {
        return new BoolExp[]{operand1, operand2};
    }

}
