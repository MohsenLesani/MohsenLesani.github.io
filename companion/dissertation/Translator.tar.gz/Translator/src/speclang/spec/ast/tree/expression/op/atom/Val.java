package speclang.spec.ast.tree.expression.op.atom;

import speclang.spec.ast.tree.token.IntLiteral;
import speclang.spec.ast.visitor.SVisitor;

/**
 * User: lesani, Date: 5-Nov-2009, Time: 12:41:55 PM
 */
public class Val extends Varl {

   public IntLiteral intLiteral;

   public Val(IntLiteral intLiteral) {
      this.intLiteral = intLiteral;
   }

   @Override
   public <R> R accept(SVisitor.VarlVisitor<R> v) {
        return v.visit(this);
    }

   @Override
   public String toString() {
      return intLiteral.lexeme;
   }
}

