package speclang.spec.ast.tree.declaration;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.statement.Statement;
import speclang.spec.ast.visitor.SVisitor;

public class Def extends LocInfo implements Node {
   public Id name;
   public Var[] inParams;
   public Statement[] statements;

   public Def(Id name, Var[] inParams, Statement[] statements) {
      this.name = name;
      this.inParams = inParams;
      this.statements = statements;
   }

   public <R> R accept(SVisitor.DefVisitor<R> v) {
      return v.visit(this);
   }
}
