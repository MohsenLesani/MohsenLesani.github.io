package speclang.spec.ast.tree.declaration.type;

import speclang.spec.ast.visitor.SVisitor;
//import speclang.typeinference.type.TypeVar;


public class TryLock extends Type {
//    private static TryLock theInstance = new TryLock();
//
//    public static TryLock instance() {
//        return theInstance;
//    }


   public TryLock(Integer arraySize, boolean local) {
      super(arraySize, local);
   }
   public TryLock() {
      super(false);
   }

   @Override
    public String toString() {
        return "TryLock";
    }

    @Override
    public <T> T accept(SVisitor.TypeVisitor<T> visitor) {
        return visitor.visit(this);
    }

}