package speclang.spec.ast.tree.statement;

import lesani.collection.option.None;
import lesani.collection.option.Option;
import lesani.collection.option.Some;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.visitor.SVisitor;

/*
 User: lesani, Date: Nov 2, 2009, Time: 1:50:45 PM
*/

public class Return extends Statement {

   public Option<Varl> varl;

   public Return(Option<Label> label, Varl varl) {
      super(label);
      this.varl = new Some<Varl>(varl);
   }

   public Return(Option<Label> label) {
      super(label);
      this.varl = None.instance();
   }


   public <R> R accept(SVisitor.StatementVisitor<R> v) {
        return v.visit(this);
    }

   public Option<Label> getLabel() {
      return label;
   }

   public <S, A> S accept(SVisitor.StatementVisitorArg<S, A> v, A a) {
      return v.visit(this, a);
   }
}