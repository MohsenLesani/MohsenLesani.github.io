package speclang.spec.ast.tree.statement;

import lesani.collection.option.Option;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.visitor.SVisitor;
import speclang.spec.astbuild.intastnodes.statement.Block;

public class While extends Statement {
   public BoolExp condition;
   public Statement[] statements;

   public While(Option<Label> label, BoolExp condition, Statement[] statements) {
      super(label);
      this.condition = condition;
      this.statements = statements;
   }

   public <R> R accept(SVisitor.StatementVisitor<R> v) {
      return v.visit(this);
   }

   public <S, A> S accept(SVisitor.StatementVisitorArg<S, A> v, A a) {
      return v.visit(this, a);
   }

}
