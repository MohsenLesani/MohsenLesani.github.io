package speclang.spec.ast.tree.declaration;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;

public class Struct extends LocInfo implements Node {
   public Id name;
   public Decl[] decls;
//   public Def[] defs;
//   public Main main;
//   public POrder pOrder;
//   public Spec spec;


   public Struct(Id name, Decl[] decls) {
      this.name = name;
      this.decls = decls;
   }

}
