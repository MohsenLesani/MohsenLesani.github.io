package speclang.spec.ast.tree.declaration.type;

import speclang.spec.ast.visitor.SVisitor;
//import speclang.typeinference.type.TypeVar;


public class AtomicRegister extends Type {
   //ToDo: Have two separate types for AtomicRegister and AtomicCASRegister
//    private static AtomicRegister theInstance = new AtomicRegister();
//
//    public static AtomicRegister instance() {
//        return theInstance;
//    }
//


   public AtomicRegister(Integer arraySize, boolean local) {
      super(arraySize, local);
   }

   public AtomicRegister() {
      super(false);
   }

   @Override
    public String toString() {
        return "AtomicRegister";
    }

    @Override
    public <T> T accept(SVisitor.TypeVisitor<T> visitor) {
        return visitor.visit(this);
    }

}