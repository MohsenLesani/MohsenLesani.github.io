package speclang.spec.ast.tree.statement;

import lesani.collection.option.Option;
import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.visitor.SVisitor;

import java.util.HashSet;
import java.util.Set;


/**
 * User: lesani, Date: Nov 3, 2009, Time: 9:11:16 AM
 */
public abstract class Statement extends LocInfo implements Node {
   public Option<Label> label;
   //public Set<Statement> dependents = new HashSet<Statement>();

   protected Statement(Option<Label> label) {
      this.label = label;
   }

   public abstract <S> S accept(SVisitor.StatementVisitor<S> v);

   public abstract <S, A> S accept(SVisitor.StatementVisitorArg<S, A> v, A a);


//    public <R> R accept(SVisitor<R> v) {
//        return v.visit(this);
//    }

}

