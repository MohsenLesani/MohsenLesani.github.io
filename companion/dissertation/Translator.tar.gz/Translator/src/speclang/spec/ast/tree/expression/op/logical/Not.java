package speclang.spec.ast.tree.expression.op.logical;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.visitor.SVisitor;


/**
 * User: lesani, Date: Nov 3, 2009, Time: 3:57:38 PM
 */
public class Not extends LogicalOp {
    public BoolExp operand;
    public static String name = "$Not";
    public static String lexeme = "!";

    public Not(BoolExp operand) {
        this.operand = operand;
    }

   public <R> R accept(SVisitor.BoolExpVisitor.OpVisitor.LogicalOpVisitor<R> v) {
        return v.visit(this);
    }

    @Override
    public BoolExp[] getOperands() {
        return new BoolExp[]{operand};
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getLexeme() {
        return lexeme;
    }

   @Override
   public String toString() {
      return "(!" + operand + ")";
   }

}