package speclang.spec.ast.tree.expression.op.atom;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.visitor.SVisitor;

public abstract class Varl extends BoolExp {
//   public Either<Var, Val> varl;
//
//   protected Varl(Either<Var, Val> varl) {
//      this.varl = varl;
//   }

   //    public <R> R accept(SVisitor<R> v) {
//        return v.visit(this);
//    }


   abstract public <R> R accept(SVisitor.VarlVisitor<R> v);

   public <R> R accept(SVisitor.BoolExpVisitor<R> v) {
      return v.visit(this);
   }

}
