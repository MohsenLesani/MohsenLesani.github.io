package speclang.spec.ast.tree.statement;

import lesani.collection.option.Option;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.visitor.SVisitor;

public abstract class MathOp extends Statement {

   public Var left;
   public Varl operand1;
   public Varl operand2;

   public MathOp(Option<Label> label, Var left, Varl operand1, Varl operand2) {
      super(label);
      this.left = left;
      this.operand1 = operand1;
      this.operand2 = operand2;
   }

   public abstract String getOperator();

   public abstract <R> R accept(SVisitor.StatementVisitor<R> v);

   public Option<Label> getLabel() {
      return label;
   }

   @Override
   public String toString() {
      String s = label + ">  ";
      return s +
            left.toString() + " = " +
            operand1.toString() + " " + getOperator() + " " + operand2.toString();
   }

}


