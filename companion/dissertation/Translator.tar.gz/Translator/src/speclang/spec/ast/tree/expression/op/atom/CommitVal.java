package speclang.spec.ast.tree.expression.op.atom;

import speclang.spec.ast.tree.token.IntLiteral;

/**
 * User: lesani, Date: 5-Nov-2009, Time: 12:41:55 PM
 */
public class CommitVal extends Val {

   public CommitVal() {
      super(new IntLiteral(8888888));
   }

   @Override
   public String toString() {
      return "\\C";
   }

}

