package speclang.spec.ast.tree.declaration;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.statement.Statement;
import speclang.spec.ast.visitor.SVisitor;

public class Main extends LocInfo implements Node {
   public Statement[][] blocks;

   public Main(Statement[][] blocks) {
      this.blocks = blocks;
   }

   public <R> R accept(SVisitor.MainVisitor<R> v) {
     return v.visit(this);
   }
}
