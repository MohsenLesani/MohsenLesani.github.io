package speclang.spec.ast.tree.statement;

import lesani.collection.option.Option;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;


public class FieldMethodCall extends GMethodCall {

   public Var ref;

   public FieldMethodCall(Option<Label> label, Var ref, Id obj, Option<Varl> index, Id name, Varl[] args, Option<Var> retv) {
      super(label, obj, name, args, retv);
      this.ref = ref;
      this.index = index;
   }

   public <R> R accept(SVisitor.StatementVisitor<R> v) {
      return v.visit(this);
   }

   @Override
   public <S, A> S accept(SVisitor.StatementVisitorArg<S, A> v, A a) {
      return v.visit(this, a);
   }

}

