package speclang.spec.ast.tree.statement;

import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.visitor.SVisitor;
import lesani.collection.option.*;

public class If extends Statement {

   public BoolExp condition;
   public Statement[] thenStatements;
   public Option<Statement[]> elseStatements = None.instance();

   public If(Option<Label> label, BoolExp condition, Statement[] thenStatements, Statement[] elseStatements) {
      super(label);
      this.condition = condition;
      this.thenStatements = thenStatements;
      this.elseStatements = new Some<Statement[]>(elseStatements);
   }
   public If(Option<Label> label, BoolExp condition, Statement[] thenStatements) {
      super(label);
      this.condition = condition;
      this.thenStatements = thenStatements;
   }

   public If(Option<Label> label, BoolExp condition, Statement[] thenStatements, Option<Statement[]> elseStatements) {
      super(label);
      this.condition = condition;
      this.thenStatements = thenStatements;
      this.elseStatements = elseStatements;
   }

   public <R> R accept(SVisitor.StatementVisitor<R> v) {
      return v.visit(this);
   }

   public Option<Label> getLabel() {
      return label;
   }

   @Override
   public String toString() {
      String s = label + ">  ";
      return s + "if " + condition.toString();

   }

   public <S, A> S accept(SVisitor.StatementVisitorArg<S, A> v, A a) {
      return v.visit(this, a);
   }
}


