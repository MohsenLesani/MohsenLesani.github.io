package speclang.spec.ast.tree.declaration;

import lesani.collection.option.Option;
import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;

public class Specification extends LocInfo implements Node {
   public Id name;
   public Decl[] decls;
   public Def[] defs;
   public Main main;
   public POrder pOrder;
   public Spec spec;
   public Option<Struct> structOption;

   public Specification(Id name, Decl[] decls, Def[] defs, Main main, POrder pOrder, Spec spec,
                        Option<Struct> structOption) {
      this.name = name;
      this.decls = decls;
      this.defs = defs;
      this.main = main;
      this.pOrder = pOrder;
      this.spec = spec;
      this.structOption = structOption;
   }

   public <R> R accept(SVisitor<R> v) {
     return v.visit(this);
   }
}
