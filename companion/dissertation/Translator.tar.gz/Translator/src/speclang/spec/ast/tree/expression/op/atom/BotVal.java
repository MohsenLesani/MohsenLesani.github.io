package speclang.spec.ast.tree.expression.op.atom;

import speclang.spec.ast.tree.token.IntLiteral;
import speclang.spec.ast.visitor.SVisitor;

/**
 * User: lesani, Date: 5-Nov-2009, Time: 12:41:55 PM
 */
public class BotVal extends Val {

   public BotVal() {
      super(new IntLiteral(9999999));
   }

   @Override
   public String toString() {
      return "\\bot";
   }
}

