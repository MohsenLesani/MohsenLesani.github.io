package speclang.spec.ast.tree.expression.op.logical;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.visitor.SVisitor;


/**
 * User: lesani, Date: Nov 3, 2009, Time: 2:19:53 PM
 */
public class Or extends LogicalOp {
    public static String name = "$Or";
    public static String lexeme = "||";

    public BoolExp operand1;
    public BoolExp operand2;

    public Or(BoolExp operand1, BoolExp operand2) {
        this.operand1 = operand1;
        this.operand2 = operand2;
    }

   public <R> R accept(SVisitor.BoolExpVisitor.OpVisitor.LogicalOpVisitor<R> v) {
        return v.visit(this);
    }

    @Override
    public BoolExp[] getOperands() {
        return new BoolExp[]{operand1, operand2};
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getLexeme() {
        return lexeme;
    }

   @Override
   public String toString() {
      return "(" + operand1 + "||" + operand2 + ")";
   }
}

