package speclang.spec.ast.tree.declaration.type;

import lesani.collection.option.None;
import lesani.collection.option.Option;
import lesani.collection.option.Some;
import speclang.spec.ast.tree.Node;
import speclang.spec.ast.visitor.SVisitor;
//import lesani.collection.xtolook.Either;
//import lesani.compiler.typing.Type;
//import lesani.compiler.typing.substitution.VarSubst;

public abstract class Type implements Node {

   //public boolean isArray;
   public Option<Integer> arraySize;
   public boolean isTLocal;
   public boolean isStructMember;

   public boolean isArray() {
      return arraySize.isPresent();
   }
   protected Type(boolean TLocal) {
      arraySize = None.instance();
      isTLocal = TLocal;
   }

   protected Type(Integer arraySize, boolean TLocal) {
      this.arraySize = new Some<Integer>(arraySize);
      isTLocal = TLocal;
   }

   public boolean isStructMember() {
      return isStructMember;
   }

   public void setStructMember() {
      isStructMember = true;
   }

   public <R> R accept(SVisitor<R> v) {
      return null;
   }

   public abstract <T> T accept(SVisitor.TypeVisitor<T> visitor);
//    public Either<Type, Integer> apply(VarSubst varSubst) {
//        return new Either.Left<Type, Integer>(this);
//    }

}
