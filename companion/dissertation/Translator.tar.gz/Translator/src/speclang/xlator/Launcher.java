package speclang.xlator;

import lesani.gui.console.Logger;

import static lesani.file.Launcher.processFiles;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Mar 2, 2010
 * Time: 1:45:08 PM
 */

public class Launcher {
   public static void main(String[] args) {

      // Arg1: The spec source folder
      // Arg2: The trace output folder
      // Arg3: The smt2 output folder

//        Logger.setOn();
      Logger.setOff();

      String defaultSource =
            "/media/MOHSENHD/1.Works/3.Research/0.Topics/1.Project/2.NonOpacity/2.Code/Translator/src/speclang/xlator/Sources.list";
      String processDir =
            "/media/MOHSENHD/1.Works/3.Research/0.Topics/1.Project/2.NonOpacity/2.Code/Translator/cases/process/"; // Let's keep / at the end ;)

      if (args.length >= 3) {
         processDir = args[2];
         String[] args2 = new String[2];
         args2[0] = args[0];
         args2[1] = args[1];
         args = args2;
      }

      FileProcessor fileProcessor = new FileProcessor(processDir);

      processFiles(fileProcessor, args, defaultSource, "spec", "inter");
   }
}

