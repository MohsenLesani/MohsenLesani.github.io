#!/bin/sh

/media/MOHSENHD/Prog/Z3/bin/z3 -smt2 $1 > $2
