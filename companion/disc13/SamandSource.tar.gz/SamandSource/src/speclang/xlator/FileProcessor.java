package speclang.xlator;

import lesani.collection.Pair;
import lesani.collection.option.Option;
import lesani.collection.option.Some;
import lesani.compiler.texttree.Printable;
import lesani.compiler.texttree.Snippet;
import lesani.compiler.texttree.seq.TextSeq;
import lesani.file.*;
import speclang.spec.ast.tree.declaration.Specification;
import speclang.spec.astbuild.ASTBuilder;
import speclang.spec.syntaxanalysis.parser.ParseException;
import speclang.spec.syntaxanalysis.parser.SpecParser;
import speclang.spec.syntaxanalysis.parser.Token;
import speclang.spec2smt2.SpecProcessor;

import java.io.*;
import java.lang.Process;
import java.util.List;
import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Nov 1, 2010
 * Time: 5:12:00 PM
 */

public class FileProcessor extends SingleFileProcess {

   final String processDir;
   Frame frame = new Frame();

   public FileProcessor(String processDir) {
      this.processDir = processDir;
      frame.setVisible(true);
   }

   @Override
   public Option<Printable> process(File file, Logger logger) throws Exception {

      frame.openSpecFile(file);

      logger.startLine("\t\tParsing spec ...");
      speclang.spec.syntaxanalysis.syntaxtree.File root;
      SpecParser parser = constructParserFor(file, logger);
      try {
         root = parser.File();
      }
      catch (ParseException e) {
         String fileName = file.getName();
         logger.endLine(" Fail");
         logger.println("\t\t\tParse Error:");
         logger.startLine("\t\t\t\t" + fileName);
         printParseError(logger, e);
         throw new SkipException();
      }
      logger.endLine(" OK");

      logger.startLine("\t\tBuilding AST ...");
      Specification specification = new ASTBuilder(root).build();
      logger.endLine(" OK");

      logger.startLine("\t\tGenerating constraints ...");
      SpecProcessor specProcessor = new SpecProcessor(specification);
      Printable res = specProcessor.generate();
      logger.endLine(" OK");

      logger.startLine("\t\tRunning SMT solver ...");
      InputStream z3Out = runz3On(res, file);
      logger.endLine(" OK");

      logger.startLine("\t\tReading SMT solver output ...");
      Pair<Boolean, List<String>[]> result =
            specProcessor.renderInterleaving(new Scanner(z3Out));
      logger.endLine(" OK");

      logger.startLine("\t\tGenerating output ...");
      show(result, file);
      Printable printable = print(result);
      logger.endLine(" OK");

      return new Some<Printable>(printable);
   }

   private InputStream runz3On(Printable printable, File file) {
      try {
         String name = file.getName();
         String baseName = name.replaceFirst("[.][^.]+$", "");

         String smt2FilePath = processDir + baseName + ".smt2";
         String z3OutFilePath = processDir + "out/" + baseName + ".txt";
         File smt2File = new File(smt2FilePath);
         PrintWriter writer = new PrintWriter(new FileOutputStream(smt2File));
         printable.print(writer);
         writer.close();

         // String z3FilePath = processDir + baseName + "out";

         String[] command = {
               processDir + "RunScript.sh",
               smt2FilePath, z3OutFilePath};
//         String[] command = {"/home/lesani/Prog/Command/lz3", name};
//         String[] command = {"lz3", name};
//         String[] command = {"echo", "$PATH"};
//         String[] command = {"ls"};
         ProcessBuilder builder = new ProcessBuilder(command);
         builder.directory(new File(processDir));
//         for (String s : builder.command()) {
//            System.out.println(s);
//         }
//         Map<String, String> env = builder.environment();
//         env.put("PATH", "/home/lesani/Prog/Command/");
         Process process = builder.start();
         process.waitFor();
         FileInputStream fileInputStream = new FileInputStream(z3OutFilePath);
         return fileInputStream;
      } catch (Exception e) {
         throw new RuntimeException("Error in launching z3: " + e.getMessage());
      }
   }

   private Printable print(Pair<Boolean, List<String>[]> result) {
      boolean specMet = result._1();
      List<String>[] lists = result._2();
      if (specMet) {
         return new Snippet("Specification is satisfied.");
      } else if (lists != null) {
         TextSeq seq = new TextSeq();
         seq.add("The specification is violated by the following counter example.\n");
         for (int i = 0; i < lists.length; i++) {
            seq.add("-- Thread " + i + " ---------------------------\n");
            List<String> strings = lists[i];
            for (String string : strings) {
               seq.add(string);
               seq.add("\n");
            }
         }
//         seq.add("---------------------------------------\n");
         return seq.get();
      } else {
         return new Snippet("Check the generated z3 file.");
      }
   }

   private void show(Pair<Boolean, List<String>[]> result, File file) {
      String name = file.getName();
      String baseName = name.replaceFirst("[.][^.]+$", "");

      boolean specMet = result._1();
      List<String>[] lists = result._2();
      if (specMet) {
         frame.render(baseName, "The specification is met.", null);
      } else if (lists != null) {
         String message = "The specification is violated by the following counter example.";
         frame.render(baseName, message, lists);
      } else {
         String message = "Z3 file to be checked.";
         frame.render(file.getName(), message, lists);
      }
   }

   private SpecParser parser = null;
   private SpecParser constructParserFor(File file, Logger logger) {
      try {
         if (parser == null)
            parser = new SpecParser(new FileInputStream(file));
         else
            parser.ReInit(new FileInputStream(file));
         return parser;
      } catch (java.io.FileNotFoundException e) {
         logger.println("File " + file.getName() + " not found.");
         System.exit(1);
      }
      return null;
   }


   static void printParseError(Logger logger, ParseException e) {
      Token currentToken = e.currentToken;
      int[][] expectedTokenSequences = e.expectedTokenSequences;
      String[] tokenImage = e.tokenImage;

      logger.endLine(" at " + currentToken.next.beginLine + ":" + currentToken.next.beginColumn);

      int maxSize = 0;
      for (int[] expectedTokenSequence : expectedTokenSequences) {
         if (maxSize < expectedTokenSequence.length)
            maxSize = expectedTokenSequence.length;
      }

      logger.println("\t\t\t\t Encountered:");

      String st = "";
      Token tok = currentToken.next;
      for (int i = 0; i < maxSize; i++) {
         if (i != 0)
            st += " ";
         if (tok.kind == 0) {
            st += tokenImage[0];
            break;
         }
         st += " " + tokenImage[tok.kind];
         tok = tok.next;
      }
      logger.println("\t\t\t\t\t" + st);

      if (expectedTokenSequences.length == 1)
         logger.println("\t\t\t\tWas expecting:");
      else
         logger.println("\t\t\t\tWas expecting one of:");

      st = "";
      for (int i = 0; i < expectedTokenSequences.length; i++) {
         for (int j = 0; j < expectedTokenSequences[i].length; j++)
            st += tokenImage[expectedTokenSequences[i][j]] + " ";

         if (expectedTokenSequences[i][expectedTokenSequences[i].length - 1] != 0) {
            st += "...";
         }
         logger.println("\t\t\t\t\t" + st);
      }
   }

   @Override
   public void exceptionHandler(Exception exception) {
      if (!(exception instanceof SkipException))
         exception.printStackTrace();
   }

}

class SkipException extends Exception {}

