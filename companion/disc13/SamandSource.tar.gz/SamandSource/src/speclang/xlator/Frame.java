package speclang.xlator;


import lesani.gui.frame.BaseJFrame;
import lesani.gui.layout.HPanel;
import lesani.gui.layout.VPanel;
import lesani.gui.menu.HorizontalMenu;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Frame extends BaseJFrame {

   private TraceTabbedPane tabbedPane;
   private JFileChooser fileChooser = new JFileChooser();

   public Frame() {
      super("Concurrent Object Language");

      JMenuBar menuBar = new JMenuBar();
      menuBar.setLayout(new BoxLayout(menuBar, BoxLayout.PAGE_AXIS));

      menuBar.setBorder(BorderFactory.createMatteBorder(0,0,0,1,
              Color.BLACK));

      JMenu m = new HorizontalMenu("File");

      JMenuItem openMenu = new JMenuItem("Open ...");
//      JMenuItem saveMenu = new JMenuItem("Save");
      JMenuItem exitMenu = new JMenuItem("Exit");

      openMenu.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            int returnVal = fileChooser.showOpenDialog(Frame.this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                final File selectedFile = fileChooser.getSelectedFile();
                openFile(selectedFile);
            }
         }
      });
      exitMenu.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            System.exit(0);
         }
      });
      m.add(openMenu);
//      m.add(saveMenu);
      m.add(exitMenu);

//      JMenu m2 = new HorizontalMenu(/*menuBar, */"Run");
//      JMenuItem runMenu = new JMenuItem("Run");
//      m2.add(runMenu);

      menuBar.add(m);
//      menuBar.add(m2);

      setLeftMenu(menuBar);

      tabbedPane = new TraceTabbedPane();
      setCenter(tabbedPane);

      setLocation(60, 60);
      setSize(1000, 800);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

   }

   private void openFile(File file) {
      String name = file.getName();
      String extension = "";
      int i = name.lastIndexOf('.');
      if (i > 0)
          extension = name.substring(i+1);

      if (extension.equals("inter")) {
         openInterFile(file);
      } else if (extension.equals("spec")) {
         openSpecFile(file);
      }
   }

   public void openSpecFile(File file) {
      try {
         List<String> lines = new LinkedList<String>();
         Scanner scanner = new Scanner(new FileInputStream(file));
         while (scanner.hasNext()) {
            String line = scanner.nextLine();
            lines.add(line);
         }
         String name = file.getName();

         tabbedPane.addTab(name, lines);
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      }
   }

   public void openInterFile(File file) {
      try {
         Scanner scanner = new Scanner(new FileInputStream(file));
         List<List<String>> lists = new LinkedList<List<String>>();
         List<String> cList = null;
         scanner.nextLine();
         while (scanner.hasNext()) {
            String line = scanner.nextLine();
            if (line.startsWith("--")) {
               if (cList != null)
                  lists.add(cList);
               cList = new LinkedList<String>();
            } else {
               cList.add(line);
            }
         }
         if (cList != null)
            lists.add(cList);
         List<String>[] listArray =  new List[lists.size()];
         lists.toArray(listArray);
         String message = "The specification is violated by the following counter example.";
         String name = file.getName();
         String baseName = name.replaceFirst("[.][^.]+$", "");

         render(name, message, listArray);

      } catch (FileNotFoundException e) {
         e.printStackTrace();
      }
   }

   public void render(String title, String message, List<String>[] lists) {
      tabbedPane.addTab(title, message, lists);
   }

}
