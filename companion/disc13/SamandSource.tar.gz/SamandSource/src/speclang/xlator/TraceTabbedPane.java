package speclang.xlator;

import lesani.gui.layout.HPanel;
import lesani.gui.layout.VPanel;
import lesani.gui.layout.VSpring;
import lesani.gui.widgets.ClosableTabbedPane;

import javax.swing.*;
import java.awt.*;
import java.util.List;


/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Mar 5, 2010
 * Time: 2:35:17 PM
 */

public class TraceTabbedPane extends ClosableTabbedPane {
   public TraceTabbedPane() {
      super(JTabbedPane.LEFT);

   }

   public void addTab(String title, String message, List<String>[] lists) {
      JPanel panel = buildPanel(message, lists);
      addTab(title, panel);
      setSelectedIndex(getTabCount() - 1);

   }


   public JPanel buildPanel(String m, List<String>[] lists) {
      JLabel message = new JLabel(m);
      if ((lists != null) && (lists.length != 0)) {
         int threadCount = lists.length;
         JTextArea[] textAreas;
         JLabel[] labels;
         textAreas = new JTextArea[threadCount];
         labels = new JLabel[threadCount];

         JComponent[] vPanels = new JComponent[threadCount];

         for (int i=0; i < threadCount; i++) {
            textAreas[i] = new JTextArea();

            textAreas[i].setFont(new Font("Monospaced", Font.PLAIN, 12));
            textAreas[i].setMargin(new Insets(5,5,5,5));
   //        textAreas(i) = new JTextArea(7, 7)
            labels[i] = new JLabel();
            vPanels[i] = new VPanel(
                  new JLabel("Thread no. " + i),
                  new JScrollPane(textAreas[i]),
                  labels[i]
            );
         }
         HPanel hPanel = new HPanel(vPanels);
         VPanel vPanel = new VPanel(new HPanel(new JLabel(" "), message), hPanel);
         for (int i = 0; i < lists.length; i++) {
            java.util.List<String> list = lists[i];
            for (String s : list) {
               textAreas[i].append(s + "\n");
            }
         }
         return vPanel;
      } else {
         return new VPanel(new HPanel(new JLabel(" "), message), new VSpring());
      }
   }

   public void addTab(String title, List<String> lines) {
      JComponent panel = buildPanel(lines);
      addTab(title, panel);
      setSelectedIndex(getTabCount() - 1);

   }

   private JComponent buildPanel(List<String> lines) {
      JTextArea textArea = new JTextArea("", 50, 40);
      textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
      textArea.setMargin(new Insets(5,5,5,5));

      for (String line : lines) {
         textArea.append(line);
         textArea.append("\n");
      }
      return new HPanel(new JScrollPane(textArea));
   }

}

