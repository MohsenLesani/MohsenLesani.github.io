package speclang.spec.astbuild.intastnodes.statement;

import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.statement.Statement;

public class Else implements Node {
    public Node statement;

    public Else(Node statement) {
        this.statement = statement;
    }
}
