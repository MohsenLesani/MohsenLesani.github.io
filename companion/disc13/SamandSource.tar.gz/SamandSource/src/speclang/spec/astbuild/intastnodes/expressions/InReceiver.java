package speclang.spec.astbuild.intastnodes.expressions;

import lesani.collection.option.Option;
import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.token.Id;

/**
 * Created by IntelliJ IDEA.
 * User: lesani
 * Date: Dec 9, 2010
 * Time: 3:40:24 PM
  */
public class InReceiver extends LocInfo implements Node {

   public Id id;
   public Option<Varl> index;

   public InReceiver(Id id, Option<Varl> index) {
      this.id = id;
      this.index = index;
   }
}

