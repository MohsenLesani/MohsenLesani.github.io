package speclang.spec.astbuild;

import lesani.collection.Pair;
import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import lesani.collection.option.None;
import lesani.collection.option.Option;
import lesani.collection.option.Some;
import lesani.compiler.ast.*;
import lesani.compiler.ast.Node;
import lesani.compiler.ast.NodeChoice;
import lesani.compiler.ast.NodeList;
import lesani.compiler.ast.NodeSequence;
import speclang.spec.ast.tree.assertion.*;
import speclang.spec.ast.tree.declaration.*;
import speclang.spec.ast.tree.declaration.type.*;
import speclang.spec.ast.tree.expression.op.atom.*;
import speclang.spec.ast.tree.expression.op.logical.And;
import speclang.spec.ast.tree.expression.op.logical.Not;
import speclang.spec.ast.tree.expression.op.logical.Or;
import speclang.spec.ast.tree.expression.op.relational.Equality;
import speclang.spec.ast.tree.expression.op.relational.GreaterThan;
import speclang.spec.ast.tree.expression.op.relational.LessThan;
import speclang.spec.ast.tree.statement.*;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.tree.token.IntLiteral;
import speclang.spec.astbuild.intastnodes.InLabel;
import speclang.spec.astbuild.intastnodes.expressions.InReceiver;
import speclang.spec.astbuild.intastnodes.expressions.InVarls;
import speclang.spec.astbuild.intastnodes.expressions.InVars;
import speclang.spec.astbuild.intastnodes.expressions.IntExp;
import speclang.spec.astbuild.intastnodes.statement.Block;
import speclang.spec.astbuild.intastnodes.statement.Else;
import speclang.spec.syntaxanalysis.syntaxtree.*;
import speclang.spec.syntaxanalysis.syntaxtree.AndAsser;
import speclang.spec.syntaxanalysis.syntaxtree.BoolExp;
import speclang.spec.syntaxanalysis.syntaxtree.Decl;
import speclang.spec.syntaxanalysis.syntaxtree.Def;
import speclang.spec.syntaxanalysis.syntaxtree.False;
import speclang.spec.syntaxanalysis.syntaxtree.FieldMethodCall;
import speclang.spec.syntaxanalysis.syntaxtree.Label;
import speclang.spec.syntaxanalysis.syntaxtree.MethodCall;
import speclang.spec.syntaxanalysis.syntaxtree.NotAsser;
import speclang.spec.syntaxanalysis.syntaxtree.Obj;
import speclang.spec.syntaxanalysis.syntaxtree.OrAsser;
import speclang.spec.syntaxanalysis.syntaxtree.Order;
import speclang.spec.syntaxanalysis.syntaxtree.Return;
import speclang.spec.syntaxanalysis.syntaxtree.Statement;
import speclang.spec.syntaxanalysis.syntaxtree.Struct;
import speclang.spec.syntaxanalysis.syntaxtree.True;
import speclang.spec.syntaxanalysis.syntaxtree.Val;
import speclang.spec.syntaxanalysis.syntaxtree.Var;
import speclang.spec.syntaxanalysis.syntaxtree.Varl;
import speclang.spec.syntaxanalysis.visitor.GJNoArguDepthFirst;
import lesani.compiler.ast.optional.SomeNode;
import lesani.compiler.ast.optional.NoneNode;
import lesani.compiler.ast.optional.OptionalNode;

import java.util.Enumeration;
import java.util.Iterator;

public class ASTBuilder extends GJNoArguDepthFirst<Node> {

   private speclang.spec.syntaxanalysis.syntaxtree.File file;

   public ASTBuilder(speclang.spec.syntaxanalysis.syntaxtree.File file) {
      this.file = file;
   }

   public Specification build() {
      return (Specification) this.file.accept(this);

   }

   private Node visitDispatch(speclang.spec.syntaxanalysis.syntaxtree.Node node) {
      return node.accept(this);
   }

   //
   //  Auto class visitors
   //
   private Node visitList(Enumeration<speclang.spec.syntaxanalysis.syntaxtree.Node> e) {
      //System.out.println("In Enumeration");
      NodeList nodeList = new NodeList();
      while (e.hasMoreElements()) {
         speclang.spec.syntaxanalysis.syntaxtree.Node parseNode = e.nextElement();
         Node node = visitDispatch(parseNode);
//            if (node == null)
//                System.out.println("null in Enumeration");
         nodeList.add(node);
      }
      return nodeList;
   }

   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.NodeList n) {
      //System.out.println("In NodeList");
      return visitList(n.elements());
   }

   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.NodeListOptional n) {
      return visitList(n.elements());
   }

   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.NodeOptional n) {
      if (n.present()) {
         Node node = visitDispatch(n.node);
         return new SomeNode(node);
      }
      else
         return NoneNode.instance();
   }

   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.NodeSequence n) {
      int count = n.size();
      Node[] nodes = new Node[count];

      for (int i = 0; i < count; i++)
         nodes[i] = visitDispatch(n.elementAt(i));

      return new NodeSequence(nodes);
   }


   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.NodeChoice n) {
//        System.out.println("In visit(NodeChoice)");
      return new NodeChoice(visitDispatch(n.choice), n.which);
   }

   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.NodeToken n) {
      return new Token(n);
   }

//====================================================================================

   private void setLoc(LocInfo locInfo, NodeToken token) {
      locInfo.lineNo = token.beginLine;
      locInfo.columnNo = token.beginColumn;
   }

   /**
    * f0 -> Identifier()
    * f1 -> "{"
    * f2 -> ( Decl() )*
    * f3 -> "}"
    */
   public Node visit(Struct n) {
      Id name = (Id) visitDispatch(n.f0);
      NodeList<speclang.spec.ast.tree.declaration.Decl> declList =
            (NodeList<speclang.spec.ast.tree.declaration.Decl>) visitDispatch(n.f2);
      speclang.spec.ast.tree.declaration.Decl[] decls =
            new speclang.spec.ast.tree.declaration.Decl[declList.size()];
      int i = 0;
      Iterator<speclang.spec.ast.tree.declaration.Decl> iterator =
            declList.iterator();
      while (iterator.hasNext()) {
         speclang.spec.ast.tree.declaration.Decl decl =
               iterator.next();
         decls[i] = decl;
         i++;
      }
      return new speclang.spec.ast.tree.declaration.Struct(name, decls);
   }

   /**
    * f0 -> ( Struct() )?
    * f1 -> Identifier()
    * f2 -> "{"
    * f3 -> ( Decl() )*
    * f4 -> ( Def() )*
    * f5 -> "main"
    * f6 -> "{"
    * f7 -> ParBlocks()
    * f8 -> "}"
    * f9 -> ( "order" "{" Orders() "}" )?
    * f10 -> "spec"
    * f11 -> "{"
    * f12 -> Asser()
    * f13 -> "}"
    * f14 -> "}"
    * f15 -> <EOF>
    */
   public Node visit(File n) {
      OptionalNode OptionalNode = (OptionalNode) visitDispatch(n.f0);
      Option<speclang.spec.ast.tree.declaration.Struct> structOption = OptionalNode.apply(
         new Fun0<Option<speclang.spec.ast.tree.declaration.Struct>>() {
            public Option<speclang.spec.ast.tree.declaration.Struct> apply() {
               return None.instance();
            }
         },
         new Fun<Node, Option<speclang.spec.ast.tree.declaration.Struct>>() {
            public Option<speclang.spec.ast.tree.declaration.Struct> apply(Node node) {
               return new Some<speclang.spec.ast.tree.declaration.Struct>((speclang.spec.ast.tree.declaration.Struct) node);
            }
         }
      );

      Id name = (Id) visitDispatch(n.f1);
      NodeList<speclang.spec.ast.tree.declaration.Decl> declList =
            (NodeList<speclang.spec.ast.tree.declaration.Decl>) visitDispatch(n.f3);
      NodeList<speclang.spec.ast.tree.declaration.Def> defList =
            (NodeList<speclang.spec.ast.tree.declaration.Def>) visitDispatch(n.f4);

      Main main = (Main) visitDispatch(n.f7);

      //POrder pOrders = (POrder) visitDispatch(n.f8);
      OptionalNode pOrdersOption = (OptionalNode) visitDispatch(n.f9);
      POrder pOrders = pOrdersOption.apply(
         new Fun0<POrder>() {
            public POrder apply() {
               return new POrder(new speclang.spec.ast.tree.declaration.Order[0]);
            }
         },
         new Fun<Node, POrder>() {
            public POrder apply(Node node) {
               return (POrder)(((NodeSequence) node).nodes[2]);
            }
         }
      );

      Spec spec = (Spec) visitDispatch(n.f12);

      speclang.spec.ast.tree.declaration.Decl[] decls =
            new speclang.spec.ast.tree.declaration.Decl[declList.size()];
      int i = 0;
      Iterator<speclang.spec.ast.tree.declaration.Decl> iterator =
            declList.iterator();
      while (iterator.hasNext()) {
         speclang.spec.ast.tree.declaration.Decl decl =
               iterator.next();
         decls[i] = decl;
         i++;
      }

      speclang.spec.ast.tree.declaration.Def[] defs =
            new speclang.spec.ast.tree.declaration.Def[defList.size()];
      i = 0;
      Iterator<speclang.spec.ast.tree.declaration.Def> iterator2 =
            defList.iterator();
      while (iterator2.hasNext()) {
         speclang.spec.ast.tree.declaration.Def def =
               iterator2.next();
         defs[i] = def;
//         System.out.println("spec " + def);
         i++;
      }

      return new Specification(name, decls, defs, main, pOrders, spec, structOption);
   }


   private void setLoc(LocInfo locInfo, LocInfo locInfo2) {
      locInfo.lineNo = locInfo2.lineNo;
      locInfo.columnNo = locInfo2.columnNo;
   }

//====================================================================================

   /**
    * f0 -> AtomicRegDecl()
    *       | RegDecl()
    *       | LockDecl()
    *       | TryLockDecl()
    */
   public Node visit(Decl n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> Obj()
    * f1 -> ":"
    * f2 -> ( "TLocal" )?
    * f3 -> "AtomicRegister"
    * f4 -> ( "[" IntegerLiteral() "]" )?
    */
   public Node visit(AtomicRegDecl n) {

      Id obj = (Id) visitDispatch(n.f0);

      final Type type = new AtomicRegister();
      if (((OptionalNode) visitDispatch(n.f2)).isPresent())
         type.isTLocal = true;

      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f4);
      optionalNode.apply(
         new Fun0<None>() {
            public None apply() {
               return None.instance();
            }
         },
         new Fun<Node, None>() {
            public None apply(Node node) {
               NodeSequence seq = (NodeSequence) node;
               IntLiteral intLiteral = (IntLiteral) seq.nodes[1];
               type.arraySize = new Some<Integer>(Integer.parseInt(intLiteral.lexeme));
               return None.instance();
            }
         }
      );

      speclang.spec.ast.tree.declaration.Decl decl =
         new speclang.spec.ast.tree.declaration.Decl(obj, type);


      setLoc(decl, n.f1);
      return decl;
   }

   /**
    * f0 -> Obj()
    * f1 -> ":"
    * f2 -> ( "TLocal" )?
    * f3 -> "AtomicCASRegister"
    * f4 -> ( "[" IntegerLiteral() "]" )?
    */
   public Node visit(AtomicCASRegDecl n) {
      Id obj = (Id) visitDispatch(n.f0);

      final Type type = new AtomicRegister();
      if (((OptionalNode) visitDispatch(n.f2)).isPresent())
         type.isTLocal = true;

      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f4);
      optionalNode.apply(
         new Fun0<None>() {
            public None apply() {
               return None.instance();
            }
         },
         new Fun<Node, None>() {
            public None apply(Node node) {
               NodeSequence seq = (NodeSequence) node;
               IntLiteral intLiteral = (IntLiteral) seq.nodes[1];
               type.arraySize = new Some<Integer>(Integer.parseInt(intLiteral.lexeme));
               return None.instance();
            }
         }
      );

      speclang.spec.ast.tree.declaration.Decl decl =
         new speclang.spec.ast.tree.declaration.Decl(obj, type);


      setLoc(decl, n.f1);
      return decl;
   }

   /**
    * f0 -> Obj()
    * f1 -> ":"
    * f2 -> ( "TLocal" )?
    * f3 -> "BasicRegister"
    * f4 -> ( "[" IntegerLiteral() "]" )?
    */
   public Node visit(RegDecl n) {
      Id obj = (Id) visitDispatch(n.f0);

      final Type type = new BasicRegister();
      if (((OptionalNode) visitDispatch(n.f2)).isPresent())
         type.isTLocal = true;

      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f4);
      optionalNode.apply(
         new Fun0<None>() {
            public None apply() {
               return None.instance();
            }
         },
         new Fun<Node, None>() {
            public None apply(Node node) {
               NodeSequence seq = (NodeSequence) node;
               IntLiteral intLiteral = (IntLiteral) seq.nodes[1];
               type.arraySize = new Some<Integer>(Integer.parseInt(intLiteral.lexeme));
               return None.instance();
            }
         }
      );

      speclang.spec.ast.tree.declaration.Decl decl =
         new speclang.spec.ast.tree.declaration.Decl(obj, type);

      setLoc(decl, n.f1);
      return decl;
   }

   /**
    * f0 -> Obj()
    * f1 -> ":"
    * f2 -> ( "TLocal" )?
    * f3 -> "Lock"
    * f4 -> ( "[" IntegerLiteral() "]" )?
    */
   public Node visit(LockDecl n) {
      Id obj = (Id) visitDispatch(n.f0);

      final Type type = new Lock();
      if (((OptionalNode) visitDispatch(n.f2)).isPresent())
         type.isTLocal = true;

      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f4);
      optionalNode.apply(
         new Fun0<None>() {
            public None apply() {
               return None.instance();
            }
         },
         new Fun<Node, None>() {
            public None apply(Node node) {
               NodeSequence seq = (NodeSequence) node;
               IntLiteral intLiteral = (IntLiteral) seq.nodes[1];
               type.arraySize = new Some<Integer>(Integer.parseInt(intLiteral.lexeme));
               return None.instance();
            }
         }
      );

      speclang.spec.ast.tree.declaration.Decl decl =
         new speclang.spec.ast.tree.declaration.Decl(obj, type);

      setLoc(decl, n.f1);
      return decl;
   }

   /**
    * f0 -> Obj()
    * f1 -> ":"
    * f2 -> ( "TLocal" )?
    * f3 -> "TryLock"
    * f4 -> ( "[" IntegerLiteral() "]" )?
    */
   public Node visit(TryLockDecl n) {
      Id obj = (Id) visitDispatch(n.f0);

      final Type type = new TryLock();
      if (((OptionalNode) visitDispatch(n.f2)).isPresent())
         type.isTLocal = true;

      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f4);
      optionalNode.apply(
         new Fun0<None>() {
            public None apply() {
               return None.instance();
            }
         },
         new Fun<Node, None>() {
            public None apply(Node node) {
               NodeSequence seq = (NodeSequence) node;
               IntLiteral intLiteral = (IntLiteral) seq.nodes[1];
               type.arraySize = new Some<Integer>(Integer.parseInt(intLiteral.lexeme));
               return None.instance();
            }
         }
      );

      speclang.spec.ast.tree.declaration.Decl decl =
         new speclang.spec.ast.tree.declaration.Decl(obj, type);

      setLoc(decl, n.f1);
      return decl;
   }

   /**
    * f0 -> Identifier()
    */
   public Node visit(Obj n) {
      return visitDispatch(n.f0);
//      Id id = (Id) visitDispatch(n.f0);
//      final speclang.ast.tree.declaration.Obj obj = new speclang.ast.tree.declaration.Obj(id.name);
//      setLoc(obj, id);
//      return obj;
   }

   /**
    * f0 -> "def"
    * f1 -> Name()
    * f2 -> "("
    * f3 -> Vars()
    * f4 -> ")"
    * f5 -> StatementBlock()
    */
   public Node visit(Def n) {
      n.f0.accept(this);
      Id name = (Id) visitDispatch(n.f1);
      InVars inVars = (InVars) visitDispatch(n.f3);
      speclang.spec.ast.tree.expression.op.atom.Var[] vars =
         inVars.vars;
      Block block =
         (Block) visitDispatch(n.f5);

      final speclang.spec.ast.tree.declaration.Def def = new speclang.spec.ast.tree.declaration.Def(name, vars, block.statements);
      setLoc(def, n.f0);
//      System.out.println("def " + def);
      return def;
   }

   /**
    * f0 -> Identifier()
    */
   public Node visit(Name n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> MethodCall()
    *       | IfThenElse()
    *       | StatementBlock()
    *       | Return()
    */
   public Node visit(Statement n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> Label()
    * f1 -> [ Var() "=" ]
    * f2 -> ( Receiver() )?
    * f3 -> Name()
    * f4 -> "("
    * f5 -> Varls()
    * f6 -> ")"
    */
   public Node visit(MethodCall n) {
      final InLabel inLabel = (InLabel) n.f0.accept(this);

      OptionalNode optional = (OptionalNode) visitDispatch(n.f2);
      Pair<Id, Option<speclang.spec.ast.tree.expression.op.atom.Varl>> objAndIndex = optional.apply(
         new Fun0<Pair<Id, Option<speclang.spec.ast.tree.expression.op.atom.Varl>>>() {
            public Pair<Id, Option<speclang.spec.ast.tree.expression.op.atom.Varl>> apply() {
               return new Pair<Id, Option<speclang.spec.ast.tree.expression.op.atom.Varl>>(
                  new Id("this"), None.instance());
            }
         },
         new Fun<Node, Pair<Id, Option<speclang.spec.ast.tree.expression.op.atom.Varl>>>() {
            public Pair<Id, Option<speclang.spec.ast.tree.expression.op.atom.Varl>> apply(Node node) {
               InReceiver inReceiver = (InReceiver) node;

               return new Pair<Id, Option<speclang.spec.ast.tree.expression.op.atom.Varl>>(
                     inReceiver.id, inReceiver.index);
            }
         }
      );
      Id obj = objAndIndex._1();
      Option<speclang.spec.ast.tree.expression.op.atom.Varl> index = objAndIndex._2();

      Id name = (Id) visitDispatch(n.f3);

      InVarls inVarls = (InVarls) visitDispatch(n.f5);
      final speclang.spec.ast.tree.expression.op.atom.Varl[] varls =
            inVarls.varls;

      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f1);
      Option<speclang.spec.ast.tree.expression.op.atom.Var> retv = optionalNode.apply(
         new Fun0<Option<speclang.spec.ast.tree.expression.op.atom.Var>>() {
            public Option<speclang.spec.ast.tree.expression.op.atom.Var> apply() {
               return None.instance();
            }
         },
         new Fun<Node, Option<speclang.spec.ast.tree.expression.op.atom.Var>>() {
            public Option<speclang.spec.ast.tree.expression.op.atom.Var> apply(Node node) {
               NodeSequence ns = (NodeSequence) node;
               speclang.spec.ast.tree.expression.op.atom.Var var =
                     (speclang.spec.ast.tree.expression.op.atom.Var) ns.nodes[0];
               return new Some<speclang.spec.ast.tree.expression.op.atom.Var>(var);
            }
         }
      );

      final speclang.spec.ast.tree.statement.MethodCall methodCall =
            new speclang.spec.ast.tree.statement.MethodCall(inLabel.labelOption, obj, name, varls, retv);
      methodCall.index = index;
      setLoc(methodCall, n.f4);
      return methodCall;
   }

   /**
    * f0 -> Label()
    * f1 -> ( Var() "=" )?
    * f2 -> Var()
    * f3 -> "."
    * f4 -> Receiver()
    * f5 -> Name()
    * f6 -> "("
    * f7 -> Varls()
    * f8 -> ")"
    */
   public Node visit(FieldMethodCall n) {
      final InLabel inLabel = (InLabel) n.f0.accept(this);

      speclang.spec.ast.tree.expression.op.atom.Var rec =
            (speclang.spec.ast.tree.expression.op.atom.Var) visitDispatch(n.f2);

      InReceiver inReceiver = (InReceiver) visitDispatch(n.f4);
      Id obj = inReceiver.id;
      Option<speclang.spec.ast.tree.expression.op.atom.Varl> index = inReceiver.index;

      Id name = (Id) visitDispatch(n.f5);

      InVarls inVarls = (InVarls) visitDispatch(n.f7);
      final speclang.spec.ast.tree.expression.op.atom.Varl[] varls =
            inVarls.varls;

      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f1);
      Option<speclang.spec.ast.tree.expression.op.atom.Var> retv = optionalNode.apply(
         new Fun0<Option<speclang.spec.ast.tree.expression.op.atom.Var>>() {
            public Option<speclang.spec.ast.tree.expression.op.atom.Var> apply() {
               return None.instance();
            }
         },
         new Fun<Node, Option<speclang.spec.ast.tree.expression.op.atom.Var>>() {
            public Option<speclang.spec.ast.tree.expression.op.atom.Var> apply(Node node) {
               NodeSequence ns = (NodeSequence) node;
               speclang.spec.ast.tree.expression.op.atom.Var var =
                     (speclang.spec.ast.tree.expression.op.atom.Var) ns.nodes[0];
               return new Some<speclang.spec.ast.tree.expression.op.atom.Var>(var);
            }
         }
      );

      final speclang.spec.ast.tree.statement.FieldMethodCall fieldMethodCall =
            new speclang.spec.ast.tree.statement.FieldMethodCall(
                  inLabel.labelOption, rec, obj, index, name, varls, retv);
      fieldMethodCall.index = index;
      setLoc(fieldMethodCall, n.f6);

      return fieldMethodCall;
   }

   /**
    * f0 -> "["
    * f1 -> Varl()
    * f2 -> "]"
    */
   public Node visit(Index n) {
      return visitDispatch(n.f1);
   }

   /**
    * f0 -> Obj()
    * f1 -> ( Index() )?
    * f2 -> "."
    */
   public Node visit(Receiver n) {
      Id id = (Id)visitDispatch(n.f0);

      OptionalNode indexOption =
            (OptionalNode) visitDispatch(n.f1);

      Option<speclang.spec.ast.tree.expression.op.atom.Varl> index = indexOption.apply(
         new Fun0<Option<speclang.spec.ast.tree.expression.op.atom.Varl>>() {
            public Option<speclang.spec.ast.tree.expression.op.atom.Varl> apply() {
               return None.instance();
            }
         },
         new Fun<Node, Option<speclang.spec.ast.tree.expression.op.atom.Varl>>() {
            public Option<speclang.spec.ast.tree.expression.op.atom.Varl> apply(Node node) {
               speclang.spec.ast.tree.expression.op.atom.Varl varl =
                     (speclang.spec.ast.tree.expression.op.atom.Varl) node;
               return new Some<speclang.spec.ast.tree.expression.op.atom.Varl>(varl);
            }
         }
      );

      return new InReceiver(id, index);
   }


   /**
    * f0 -> Label()
    * f1 -> "if"
    * f2 -> "("
    * f3 -> BoolExp()
    * f4 -> ")"
    * f5 -> Statement()
    * f6 -> [ ElseClause() ]
    */
   public Node visit(IfThenElse n) {
      final InLabel inLabel = (InLabel) n.f0.accept(this);
      speclang.spec.ast.tree.expression.BoolExp cond =
            (speclang.spec.ast.tree.expression.BoolExp) visitDispatch(n.f3);

      Node thenStatement = visitDispatch(n.f5);

      speclang.spec.ast.tree.statement.Statement[] thenStatements =
            toArrayStatements(thenStatement);

      OptionalNode optional = (OptionalNode) visitDispatch(n.f6);
      Option<speclang.spec.ast.tree.statement.Statement[]> elseStatementOption =
            optional.apply(
         new Fun0<Option<speclang.spec.ast.tree.statement.Statement[]>>() {
            public Option<speclang.spec.ast.tree.statement.Statement[]> apply() {
               return None.instance();
            }
         },
         new Fun<Node, Option<speclang.spec.ast.tree.statement.Statement[]>>() {
            public Option<speclang.spec.ast.tree.statement.Statement[]> apply(Node node) {
               Else elseStatement = (Else) node;
               final Node statement= elseStatement.statement;
               speclang.spec.ast.tree.statement.Statement[] elseStatements =
                     toArrayStatements(statement);
               return new Some<speclang.spec.ast.tree.statement.Statement[]>
                     (elseStatements);
            }

         }
      );

      If theIf = new If(inLabel.labelOption, cond, thenStatements, elseStatementOption);
      setLoc(theIf, n.f1);
      return theIf;
   }

   private speclang.spec.ast.tree.statement.Statement[] toArrayStatements(
         Node statement) {
      if (statement instanceof Block)
         return ((Block) statement).statements;
      else
         return new speclang.spec.ast.tree.statement.Statement[] {
               (speclang.spec.ast.tree.statement.Statement) statement};
   }

   /**
    * f0 -> "else"
    * f1 -> Statement()
    */
   public Node visit(ElseClause n) {
      Node statement = visitDispatch(n.f1);
      return new Else(statement);
   }

   /**
    * f0 -> "{"
    * f1 -> ( Statement() )*
    * f2 -> "}"
    */
   public Node visit(StatementBlock n) {
      NodeList<speclang.spec.ast.tree.statement.Statement> statementNodeList =
            (NodeList<speclang.spec.ast.tree.statement.Statement>)visitDispatch(n.f1);
      speclang.spec.ast.tree.statement.Statement[] statements =
            new speclang.spec.ast.tree.statement.Statement[statementNodeList.size()];
      int i = 0;
      Iterator<speclang.spec.ast.tree.statement.Statement> iterator =
            statementNodeList.iterator();
      while (iterator.hasNext()) {
         speclang.spec.ast.tree.statement.Statement var =
               iterator.next();
         statements[i] = var;
         i++;
      }
      final Block block = new Block(statements);
      //setLoc(block, n.f0);
      return block;
   }

   /**
    * f0 -> Label()
    * f1 -> Var()
    * f2 -> "="
    * f3 -> "new"
    * f4 -> Identifier()
    * f5 -> "("
    * f6 -> ")"
    */
   public Node visit(NewStatement n) {
      final InLabel inLabel = (InLabel) visitDispatch(n.f0);
      speclang.spec.ast.tree.expression.op.atom.Var var =
            (speclang.spec.ast.tree.expression.op.atom.Var)visitDispatch(n.f1);
      Id id = (Id)visitDispatch(n.f4);
      return new New(inLabel.labelOption, var, id);
   }

   /**
    * f0 -> Label()
    * f1 -> Var()
    * f2 -> "="
    * f3 -> Varl()
    * f4 -> "+"
    * f5 -> Varl()
    */
   public Node visit(PlusStatement n) {
      final InLabel inLabel = (InLabel) visitDispatch(n.f0);
      speclang.spec.ast.tree.expression.op.atom.Var left =
            (speclang.spec.ast.tree.expression.op.atom.Var) visitDispatch(n.f1);
      speclang.spec.ast.tree.expression.op.atom.Varl operand1 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) visitDispatch(n.f3);
      speclang.spec.ast.tree.expression.op.atom.Varl operand2 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) visitDispatch(n.f5);
      return new Plus(inLabel.labelOption, left, operand1, operand2);
   }

   /**
    * f0 -> Label()
    * f1 -> Var()
    * f2 -> "="
    * f3 -> Varl()
    * f4 -> "-"
    * f5 -> Varl()
    */
   public Node visit(MinusStatement n) {
      final InLabel inLabel = (InLabel) visitDispatch(n.f0);
      speclang.spec.ast.tree.expression.op.atom.Var left =
            (speclang.spec.ast.tree.expression.op.atom.Var) visitDispatch(n.f1);
      speclang.spec.ast.tree.expression.op.atom.Varl operand1 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) visitDispatch(n.f3);
      speclang.spec.ast.tree.expression.op.atom.Varl operand2 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) visitDispatch(n.f5);
      return new Minus(inLabel.labelOption, left, operand1, operand2);
   }

   /**
    * f0 -> [ Var() ( VarsRest() )* ]
    */

   public Node visit(Vars n) {
      OptionalNode node = (OptionalNode) visitDispatch(n.f0);
      return node.apply(
            new Fun0<Node>() {
               public Node apply() {
                  return new InVars(new speclang.spec.ast.tree.expression.op.atom.Var[0]);
               }
            },
            new Fun<Node, Node>() {
               public Node apply(Node node) {
                  NodeSequence ns = (NodeSequence) node;
                  speclang.spec.ast.tree.expression.op.atom.Var var0 =
                        (speclang.spec.ast.tree.expression.op.atom.Var) ns.nodes[0];
                  NodeList<speclang.spec.ast.tree.expression.op.atom.Var> varlList =
                        (NodeList<speclang.spec.ast.tree.expression.op.atom.Var>) ns.nodes[1];
                  speclang.spec.ast.tree.expression.op.atom.Var[] vars =
                        new speclang.spec.ast.tree.expression.op.atom.Var[varlList.size() + 1];
                  vars[0] = var0;
                  int i = 1;
                  Iterator<speclang.spec.ast.tree.expression.op.atom.Var> iterator =
                        varlList.iterator();
                  while (iterator.hasNext()) {
                     speclang.spec.ast.tree.expression.op.atom.Var var =
                           iterator.next();
                     vars[i] = var;
                     i++;
                  }
                  return new InVars(vars);
               }
            }
      );
   }

   /**
    * f0 -> ","
    * f1 -> Var()
    */
   public Node visit(VarsRest n) {
      return visitDispatch(n.f1);
   }

   /**
    * f0 -> Varl()
    * f1 -> ( VarlsRest() )*
    */
   public Node visit(Varls n) {
      OptionalNode node = (OptionalNode) visitDispatch(n.f0);
      return node.apply(
            new Fun0<Node>() {
               public Node apply() {
                  return new InVarls(new speclang.spec.ast.tree.expression.op.atom.Varl[0]);
               }
            },
            new Fun<Node, Node>() {
               public Node apply(Node node) {
                  NodeSequence ns = (NodeSequence) node;
                  speclang.spec.ast.tree.expression.op.atom.Varl varl0 =
                        (speclang.spec.ast.tree.expression.op.atom.Varl) ns.nodes[0];
                  NodeList<speclang.spec.ast.tree.expression.op.atom.Varl> varlList =
                        (NodeList<speclang.spec.ast.tree.expression.op.atom.Varl>) ns.nodes[1];
                  speclang.spec.ast.tree.expression.op.atom.Varl[] varls =
                        new speclang.spec.ast.tree.expression.op.atom.Varl[varlList.size() + 1];
                  varls[0] = varl0;
                  int i = 1;
                  Iterator<speclang.spec.ast.tree.expression.op.atom.Varl> iterator =
                        varlList.iterator();
                  while (iterator.hasNext()) {
                     speclang.spec.ast.tree.expression.op.atom.Varl varl =
                           iterator.next();
                     varls[i] = varl;
                     i++;
                  }
                  return new InVarls(varls);
               }
            }
      );
   }

   /**
    * f0 -> ","
    * f1 -> Varl()
    */
   public Node visit(VarlsRest n) {
      return visitDispatch(n.f1);
   }

   /**
    * f0 -> Var()
    *     | Val()
    */
   public Node visit(Varl n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> Identifier()
    */
   public Node visit(Var n) {
      Id id = (Id) visitDispatch(n.f0);
      return new speclang.spec.ast.tree.expression.op.atom.Var(id);
   }

   /**
    * f0 -> IntVal()
    *       | Bot()
    *       | Abort()
    *       | Commit()
    *       | Ok()
    */
   public Node visit(Val n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> IntegerLiteral()
    */
   public Node visit(IntVal n) {
      IntLiteral intLiteral = (IntLiteral) visitDispatch(n.f0);
      return new speclang.spec.ast.tree.expression.op.atom.Val(intLiteral);
   }

   /**
    * f0 -> "\\bot"
    */
   public Node visit(Bot n) {
      return new BotVal();
   }

   /**
    * f0 -> "\\A"
    */
   public Node visit(Abort n) {
      return new AbortVal();
   }

   /**
    * f0 -> "\\C"
    */
   public Node visit(Commit n) {
      return new CommitVal();
   }

   /**
    * f0 -> "\\Ok"
    */
   public Node visit(Ok n) {
      return new OKVal();
   }

   /**
    * f0 -> "\\R"
    */
   public Node visit(Running n) {
      return new RunningVal();
   }

   /**
    * f0 -> OrExp()
    */
   public Node visit(BoolExp n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> AndExp()
    * f1 -> ( OrExpRest() )*
    */
   public Node visit(OrExp n) {
      speclang.spec.ast.tree.expression.BoolExp operand1 = (speclang.spec.ast.tree.expression.BoolExp)visitDispatch(n.f0);
      NodeList<IntExp> operands = (NodeList<IntExp>) visitDispatch(n.f1);
      Iterator<IntExp> iterator = operands.iterator();
      while (iterator.hasNext()) {
          IntExp intExp = iterator.next();
          speclang.spec.ast.tree.expression.BoolExp operand2 = intExp.expression;
          operand1 = new Or(operand1, operand2);
          setLoc(operand1, intExp);
      }
      return operand1;
   }

   /**
    * f0 -> "||"
    * f1 -> AndExp()
    */
   public Node visit(OrExpRest n) {
      final speclang.spec.ast.tree.expression.BoolExp op = (speclang.spec.ast.tree.expression.BoolExp)visitDispatch(n.f1);
      IntExp intExp = new IntExp(op);
      setLoc(intExp, n.f0);
      return intExp;
   }

   /**
    * f0 -> NotExp()
    * f1 -> ( AndExpRest() )*
    */
   public Node visit(AndExp n) {
      speclang.spec.ast.tree.expression.BoolExp operand1 = (speclang.spec.ast.tree.expression.BoolExp)visitDispatch(n.f0);
      NodeList<IntExp> operands = (NodeList<IntExp>)visitDispatch(n.f1);
      Iterator<IntExp> iterator = operands.iterator();
      while (iterator.hasNext()) {
          IntExp intExp = iterator.next();
          speclang.spec.ast.tree.expression.BoolExp operand2 = intExp.expression;
          operand1 = new And(operand1, operand2);
          setLoc(operand1, intExp);
      }
      return operand1;
   }

   /**
    * f0 -> "&&"
    * f1 -> NotExp()
    */
   public Node visit(AndExpRest n) {
      final speclang.spec.ast.tree.expression.BoolExp op = (speclang.spec.ast.tree.expression.BoolExp)visitDispatch(n.f1);
      IntExp intExp = new IntExp(op);
      setLoc(intExp, n.f0);
      return intExp;
   }

   /**
    * f0 -> ( "!" )?
    * f1 -> Atom()
    */
   public Node visit(NotExp n) {
      final speclang.spec.ast.tree.expression.BoolExp exp =
            (speclang.spec.ast.tree.expression.BoolExp) visitDispatch(n.f1);
      OptionalNode optional = (OptionalNode) visitDispatch(n.f0);
      return optional.apply(
         new Fun0<Node>() {
            public Node apply() {
               return exp;
            }
         },
         new Fun<Node, Node>() {
            public Node apply(Node node) {
               Not not = new Not(exp);
               //setLoc(not, (NodeToken) node);
               return not;
            }
         }
      );
   }

   /**
    * f0 -> ParExp()
    *       | RelExp()
    */
   public Node visit(Atom n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> "("
    * f1 -> BoolExp()
    * f2 -> ")"
    */
   public Node visit(ParExp n) {
      return visitDispatch(n.f1);
   }


   /**
    * f0 -> EqExp()
    *       | IneqExp()
    *       | LTExp()
    *       | GTExp()
    */
   public Node visit(RelExp n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> Varl()
    * f1 -> "="
    * f2 -> Varl()
    */
   public Node visit(EqExp n) {
      speclang.spec.ast.tree.expression.op.atom.Varl varl1 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) n.f0.accept(this);
      speclang.spec.ast.tree.expression.op.atom.Varl varl2 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) n.f2.accept(this);
      Equality relOp = new Equality(varl1,  varl2);
      setLoc(relOp, n.f1);
      return relOp;
   }

   /**
    * f0 -> Varl()
    * f1 -> "!="
    * f2 -> Varl()
    */
   public Node visit(IneqExp n) {
      speclang.spec.ast.tree.expression.op.atom.Varl varl1 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) n.f0.accept(this);
      speclang.spec.ast.tree.expression.op.atom.Varl varl2 =
            (speclang.spec.ast.tree.expression.op.atom.Varl) n.f2.accept(this);
      Equality relOp = new Equality(varl1,  varl2);
      setLoc(relOp, n.f1);
      Not notExp = new Not(relOp);
      setLoc(notExp, n.f1);
      return notExp;
   }

   /**
    * f0 -> Varl()
    * f1 -> "<"
    * f2 -> Varl()
    */
   public Node visit(LTExp n) {
      speclang.spec.ast.tree.expression.op.atom.Varl varl1 = (speclang.spec.ast.tree.expression.op.atom.Varl) n.f0.accept(this);
      speclang.spec.ast.tree.expression.op.atom.Varl varl2 = (speclang.spec.ast.tree.expression.op.atom.Varl) n.f2.accept(this);
      LessThan relOp = new LessThan(varl1,  varl2);
      setLoc(relOp, n.f1);
      return relOp;
   }

   /**
    * f0 -> Varl()
    * f1 -> ">"
    * f2 -> Varl()
    */
   public Node visit(GTExp n) {
      speclang.spec.ast.tree.expression.op.atom.Varl varl1 = (speclang.spec.ast.tree.expression.op.atom.Varl) n.f0.accept(this);
      speclang.spec.ast.tree.expression.op.atom.Varl varl2 = (speclang.spec.ast.tree.expression.op.atom.Varl) n.f2.accept(this);
      GreaterThan relOp = new GreaterThan(varl1,  varl2);
      setLoc(relOp, n.f1);
      return relOp;
   }

   /**
    * f0 -> StatementBlock()
    * f1 -> ( ParBlocksRest() )*
    */
   public Node visit(ParBlocks n) {
      Block block0 =
            (Block) visitDispatch(n.f0);
      NodeList<Block> blockList =
            (NodeList<Block>)visitDispatch(n.f1);
      speclang.spec.ast.tree.statement.Statement[][] blocks =
            new speclang.spec.ast.tree.statement.Statement[blockList.size() + 1][];
      blocks[0] = block0.statements;
      int i = 1;
      Iterator<Block> iterator = blockList.iterator();
      while (iterator.hasNext()) {
         Block block = iterator.next();
         blocks[i] = block.statements;
         i++;
      }
      return new Main(blocks);
   }

   /**
    * f0 -> "||"
    * f1 -> StatementBlock()
    */
   public Node visit(ParBlocksRest n) {
      return visitDispatch(n.f1);
   }


   /**
    * f0 -> OrAsser()
    */
   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.Asser n) {
//      return new SpecAsser(((InAsser)visitDispatch(n.f0)).asser);
      return new Spec((speclang.spec.ast.tree.assertion.Asser)visitDispatch(n.f0));
   }

   /**
    * f0 -> AndAsser()
    * f1 -> ( OrAsserRest() )*
    */
   public Node visit(OrAsser n) {
      speclang.spec.ast.tree.assertion.Asser operand1 = (speclang.spec.ast.tree.assertion.Asser)visitDispatch(n.f0);
      NodeList<speclang.spec.ast.tree.assertion.Asser> operands =
            (NodeList<speclang.spec.ast.tree.assertion.Asser>) visitDispatch(n.f1);
      Iterator<speclang.spec.ast.tree.assertion.Asser> iterator = operands.iterator();
      while (iterator.hasNext()) {
         speclang.spec.ast.tree.assertion.Asser operand2 = iterator.next();
         operand1 = new speclang.spec.ast.tree.assertion.OrAsser(operand1, operand2);
         setLoc(operand1, operand2);
      }
      return operand1;
   }

   /**
    * f0 -> "\\/"
    * f1 -> AndAsser()
    */
   public Node visit(OrAsserRest n) {
      return visitDispatch(n.f1);
   }

   /**
    * f0 -> NotAsser()
    * f1 -> ( AndAsserRest() )*
    */
   public Node visit(AndAsser n) {
      speclang.spec.ast.tree.assertion.Asser operand1 = (speclang.spec.ast.tree.assertion.Asser)visitDispatch(n.f0);
      NodeList<speclang.spec.ast.tree.assertion.Asser> operands =
            (NodeList<speclang.spec.ast.tree.assertion.Asser>) visitDispatch(n.f1);
      Iterator<speclang.spec.ast.tree.assertion.Asser> iterator = operands.iterator();
      while (iterator.hasNext()) {
         speclang.spec.ast.tree.assertion.Asser operand2 = iterator.next();
         operand1 = new speclang.spec.ast.tree.assertion.AndAsser(operand1, operand2);
         setLoc(operand1, operand2);
      }
      return operand1;
   }

   /**
    * f0 -> "/\\"
    * f1 -> NotAsser()
    */
   public Node visit(AndAsserRest n) {
      return visitDispatch(n.f1);
   }

   /**
    * f0 -> ( "~" )?
    * f1 -> AtomAsser()
    */
   public Node visit(NotAsser n) {
      final speclang.spec.ast.tree.assertion.Asser asser =
            (speclang.spec.ast.tree.assertion.Asser) visitDispatch(n.f1);

      OptionalNode optional = (OptionalNode) visitDispatch(n.f0);
      return optional.apply(
         new Fun0<Node>() {
            public Node apply() {
               return asser;
            }
         },
         new Fun<Node, Node>() {
            public Node apply(Node input) {
               return new speclang.spec.ast.tree.assertion.NotAsser(asser);
            }
         }
      );
   }

   @Override
   public Node visit(False n) {
      return new speclang.spec.ast.tree.assertion.False();
   }

   @Override
   public Node visit(True n) {
      return new speclang.spec.ast.tree.assertion.True();
   }

   /**
    * f0 -> EqualAsser()
    *       | ExecAsser()
    *       | ParAsser()
    */
   public Node visit(AtomAsser n) {
      return visitDispatch(n.f0);
   }

   /**
    * f0 -> "("
    * f1 -> Asser()
    * f2 -> ")"
    */
   public Node visit(ParAsser n) {
      return visitDispatch(n.f1);
   }

   /**
    * f0 -> Var()
    * f1 -> "="
    * f2 -> Val()
    */
   public Node visit(EqualAsser n) {
      speclang.spec.ast.tree.expression.op.atom.Var var = (speclang.spec.ast.tree.expression.op.atom.Var) n.f0.accept(this);
      speclang.spec.ast.tree.expression.op.atom.Val val = (speclang.spec.ast.tree.expression.op.atom.Val) n.f2.accept(this);
      EqAsser eqAsser = new EqAsser(var, val);
      setLoc(eqAsser, n.f1);
      return eqAsser;
   }

   /**
    * f0 -> "exec"
    * f1 -> "("
    * f2 -> Identifier()
    * f3 -> ")"
    */
   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.ExecAsser n) {
      Id id = (Id) visitDispatch(n.f2);
      speclang.spec.ast.tree.declaration.Label label = new speclang.spec.ast.tree.declaration.Label(id);
      return new speclang.spec.ast.tree.assertion.ExecAsser(label);
   }

   /**
    * f0 -> Identifier()
    * f1 -> "\\prec"
    * f2 -> Identifier()
    */
   public Node visit(speclang.spec.syntaxanalysis.syntaxtree.OrderAsser n) {
      Id id1 = (Id) visitDispatch(n.f0);
      speclang.spec.ast.tree.declaration.Label label1 = new speclang.spec.ast.tree.declaration.Label(id1);
      Id id2 = (Id) visitDispatch(n.f2);
      speclang.spec.ast.tree.declaration.Label label2 = new speclang.spec.ast.tree.declaration.Label(id2);
      return new speclang.spec.ast.tree.assertion.OrderAsser(label1, label2);
   }

   /**
    * f0 -> Label()
    * f1 -> "return"
    * f2 -> ( Varl() )?
    */
   public Node visit(Return n) {
      final InLabel inLabel = (InLabel) n.f0.accept(this);
      OptionalNode optionalNode = (OptionalNode) n.f2.accept(this);
      final speclang.spec.ast.tree.statement.Return ret = optionalNode.apply(
         new Fun0<speclang.spec.ast.tree.statement.Return>() {
            public speclang.spec.ast.tree.statement.Return apply() {
               return new speclang.spec.ast.tree.statement.Return(inLabel.labelOption);
            }
         },
         new Fun<Node, speclang.spec.ast.tree.statement.Return>() {
            public speclang.spec.ast.tree.statement.Return apply(Node node) {
               speclang.spec.ast.tree.expression.op.atom.Varl varl =
                     (speclang.spec.ast.tree.expression.op.atom.Varl) node;
               return new speclang.spec.ast.tree.statement.Return(inLabel.labelOption, varl);
            }
         }
      );
      setLoc(ret, n.f1);
      return ret;
   }

   /**
    * f0 -> (Identifier() ">" )?
    */
   public Node visit(Label n) {
      OptionalNode optionalNode = (OptionalNode) visitDispatch(n.f0);
      Option<speclang.spec.ast.tree.declaration.Label> label = optionalNode.apply(
         new Fun0<Option<speclang.spec.ast.tree.declaration.Label>>() {
            public Option<speclang.spec.ast.tree.declaration.Label> apply() {
               return None.instance();
            }
         },
         new Fun<Node, Option<speclang.spec.ast.tree.declaration.Label>>() {
            public Option<speclang.spec.ast.tree.declaration.Label> apply(Node node) {
               NodeSequence nodeSeq = (NodeSequence) node;
               Id id = (Id) nodeSeq.nodes[0];
               final speclang.spec.ast.tree.declaration.Label label1 = new speclang.spec.ast.tree.declaration.Label(id);
               setLoc(label1, id);
               return new Some<speclang.spec.ast.tree.declaration.Label>(label1);
            }
         }
      );
      return new InLabel(label);
   }

   /**
    * f0 -> Order()
    * f1 -> ( OrdersRest() )*
    */
   public Node visit(Orders n) {
      speclang.spec.ast.tree.declaration.Order order0 =
            (speclang.spec.ast.tree.declaration.Order)visitDispatch(n.f0);
      NodeList<speclang.spec.ast.tree.declaration.Order> orderList =
            (NodeList<speclang.spec.ast.tree.declaration.Order>) visitDispatch(n.f1);

      speclang.spec.ast.tree.declaration.Order[] orders =
            new speclang.spec.ast.tree.declaration.Order[orderList.size() + 1];
      orders[0] = order0;
      int i = 1;
      Iterator<speclang.spec.ast.tree.declaration.Order> iterator = orderList.iterator();
      while (iterator.hasNext()) {
         speclang.spec.ast.tree.declaration.Order order = iterator.next();
         orders[i] = order;
         i++;
      }
      return new POrder(orders);
   }

   /**
    * f0 -> "&&"
    * f1 -> Order()
    */
   public Node visit(OrdersRest n) {
      final speclang.spec.ast.tree.declaration.Order order =
            (speclang.spec.ast.tree.declaration.Order) visitDispatch(n.f1);
      return order;

   }

   /**
    * f0 -> Identifier()
    * f1 -> "->"
    * f2 -> Identifier()
    */
   public Node visit(Order n) {
      Id id1 = (Id) visitDispatch(n.f0);
      Id id2 = (Id) visitDispatch(n.f2);
      speclang.spec.ast.tree.declaration.Order order =
            new speclang.spec.ast.tree.declaration.Order(
                  new speclang.spec.ast.tree.declaration.Label(id1),
                  new speclang.spec.ast.tree.declaration.Label(id2)
                  );
      return order;
   }

   /**
    * f0 -> <INTEGER_LITERAL>
    */
   public Node visit(IntegerLiteral n) {
      final IntLiteral intLiteral = new IntLiteral(n.f0.toString());
      setLoc(intLiteral, n.f0);
      return intLiteral;
   }

   /**
    * f0 -> <IDENTIFIER>
    */
   public Node visit(Identifier n) {
      final String name = n.f0.toString();
      final Id id = new Id(name);
      setLoc(id, n.f0);
      return id;
   }

   /**
    * f0 -> <STRING_LITERAL>
    */
   public Node visit(StringLiteral n) {
      return null;
      // we currently do not have string literals.
   }



//====================================================================================
}
    
    
