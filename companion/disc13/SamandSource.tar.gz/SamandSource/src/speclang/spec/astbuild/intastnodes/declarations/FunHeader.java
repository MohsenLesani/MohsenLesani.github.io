package speclang.spec.astbuild.intastnodes.declarations;

import lesani.collection.option.Option;
import lesani.collection.option.Some;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.token.Id;

public class FunHeader implements Node {
    public Option<Id[]> outputParams;
    public Id name;
    public Option<Id[]> inputParams;

    public FunHeader(Id[] outputParams, Id name, Id[] inputParams) {
        this.outputParams = new Some<Id[]>(outputParams);
        this.name = name;
        this.inputParams = new Some<Id[]>(inputParams);
    }

    public FunHeader(Option<Id[]> outputParams, Id name, Option<Id[]> inputParams) {
        this.outputParams = outputParams;
        this.name = name;
        this.inputParams = inputParams;
    }
}
