package speclang.spec.ast.tree.declaration.type;

import speclang.spec.ast.visitor.SVisitor;
//import speclang.typeinference.type.TypeVar;


public class BasicRegister extends Type {
//    private static UnsafeRegister theInstance = new UnsafeRegister();
//
//    public static UnsafeRegister instance() {
//        return theInstance;
//    }


   public BasicRegister(Integer arraySize, boolean local) {
      super(arraySize, local);
   }

   public BasicRegister() {
      super(false);
   }

   @Override
    public String toString() {
        return "UnsafeRegister";
    }

    @Override
    public <T> T accept(SVisitor.TypeVisitor<T> visitor) {
        return visitor.visit(this);
    }

}