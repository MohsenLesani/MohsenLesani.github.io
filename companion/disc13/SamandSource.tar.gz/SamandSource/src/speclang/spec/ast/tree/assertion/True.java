package speclang.spec.ast.tree.assertion;


import speclang.spec.ast.visitor.SVisitor;

public class True extends Asser {

   public True() {
   }

   public <R> R accept(SVisitor.AssertionVisitor<R> v) {
     return v.visit(this);
   }

//   public <R> R accept(SVisitor.ConstraintVisitor<R> v) {
//       return v.visit(this);
//   }
}
