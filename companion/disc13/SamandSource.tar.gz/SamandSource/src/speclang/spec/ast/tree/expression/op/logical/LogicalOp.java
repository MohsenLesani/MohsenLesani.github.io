package speclang.spec.ast.tree.expression.op.logical;

import speclang.spec.ast.tree.expression.op.Op;
import speclang.spec.ast.visitor.SVisitor;

public abstract class LogicalOp extends Op {

    public <R> R accept(SVisitor.BoolExpVisitor.OpVisitor<R> v) {
        return v.visit(this);
    }

    public abstract <R> R accept(SVisitor.BoolExpVisitor.OpVisitor.LogicalOpVisitor<R> v);

}
