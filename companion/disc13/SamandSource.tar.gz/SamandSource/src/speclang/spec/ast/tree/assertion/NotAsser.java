package speclang.spec.ast.tree.assertion;


import lesani.compiler.ast.LocInfo;
import speclang.spec.ast.visitor.SVisitor;

public class NotAsser extends Asser {
   public Asser op;

   public NotAsser(Asser op) {
      this.op = op;
   }

   public <R> R accept(SVisitor.AssertionVisitor<R> v) {
     return v.visit(this);
   }

//   public <R> R accept(SVisitor.ConstraintVisitor<R> v) {
//       return v.visit(this);
//   }
}
