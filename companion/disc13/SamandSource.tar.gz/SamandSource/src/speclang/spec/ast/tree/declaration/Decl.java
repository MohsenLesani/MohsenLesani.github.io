package speclang.spec.ast.tree.declaration;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.declaration.type.Type;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;

public class Decl extends LocInfo implements Node {

   public Id id;
   public Type type;

   public Decl(Id id, Type type) {
      this.type = type;
      this.id = id;
   }

   public <R> R accept(SVisitor.DeclVisitor<R> v) {
      return v.visit(this);
   }
}
