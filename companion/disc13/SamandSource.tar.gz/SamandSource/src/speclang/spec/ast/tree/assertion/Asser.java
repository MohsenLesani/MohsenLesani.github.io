package speclang.spec.ast.tree.assertion;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.visitor.SVisitor;

public abstract class Asser extends LocInfo implements Node {

   public abstract <R> R accept(SVisitor.AssertionVisitor<R> v);

}
