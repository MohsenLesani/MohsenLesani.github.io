package speclang.spec.ast.visitor;

import speclang.spec.ast.tree.assertion.*;
import speclang.spec.ast.tree.declaration.*;
import speclang.spec.ast.tree.declaration.type.*;
import speclang.spec.ast.tree.expression.op.atom.Val;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.expression.op.Op;
import speclang.spec.ast.tree.expression.op.logical.*;
import speclang.spec.ast.tree.expression.op.relational.*;
import speclang.spec.ast.tree.statement.*;

public interface SVisitor<R> {

   R visit(Specification sepc);

   public interface DeclVisitor<S> {
      S visit(Decl decl);
   }
   public interface TypeVisitor<S> {
      S visit(AtomicRegister register);
      S visit(BasicRegister register);
      S visit(Lock lock);
      S visit(TryLock tryLock);
   }

   public interface DefVisitor<S> {
      S visit(Def def);
   }

   public interface MainVisitor<S> {
      S visit(Main main);
   }

   public interface SpecVisitor<S> {
      S visit(Spec spec);
   }
   public interface AssertionVisitor<S> {
      S visit(OrAsser orAsser);
      S visit(AndAsser andAsser);
      S visit(NotAsser notAsser);
      S visit(EqAsser eqAssertion);
      S visit(ExecAsser execAssertion);
      S visit(OrderAsser orderAsser);
      S visit(False aFalse);
      S visit(True aTrue);
   }

   public interface POrderVisitor<S> {
      S visit(POrder pOrder);
   }

   //R visit(Statement statement);
   public interface StatementVisitor<S> {
      S visit(MethodCall methodCall);
      S visit(If anIf);
      S visit(Return aReturn);
      S visit(While aWhile);
      S visit(New aNew);
      S visit(FieldMethodCall fieldMethodCall);
      
      S visit(Plus plus);
      S visit(Minus minus);

   }

   public interface StatementVisitorArg<S, A> {
      S visit(MethodCall methodCall, A a);
      S visit(If anIf, A a);
      S visit(Return aReturn, A a);
      S visit(While aWhile, A a);
      S visit(New aNew, A a);
      S visit(FieldMethodCall fieldMethodCall, A a);

      S visit(Plus plus, A a);
      S visit(Minus minus, A a);

   }


   public interface BoolExpVisitor<U> {

      U visit(Op op);
      public interface OpVisitor<S> {

         S visit(LogicalOp logicalOp);
         public interface LogicalOpVisitor<T> {
            T visit(And and);
            T visit(Or or);
            T visit(Not not);
         }

         S visit(RelationalOp relationalOp);
         public interface RelationalVisitor<T> {
            T visit(Equality equality);
            T visit(LessThan lessThan);
            T visit(GreaterThan greaterThan);
            T visit(LessThanEqual lessThanEqual);
            T visit(GreaterThanEqual greaterThanEqual);
         }
      }
      U visit(Varl varl);
   }

   public interface VarlVisitor<S> {
      S visit(Var var);
      S visit(Val val);
   }

}

