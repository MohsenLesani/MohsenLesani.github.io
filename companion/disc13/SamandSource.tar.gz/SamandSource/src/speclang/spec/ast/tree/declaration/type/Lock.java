package speclang.spec.ast.tree.declaration.type;

import speclang.spec.ast.visitor.SVisitor;
//import speclang.typeinference.type.TypeVar;


public class Lock extends Type {
//    private static Lock theInstance = new Lock();

//    public static Lock instance() {
//        return theInstance;
//    }


   public Lock(Integer arraySize, boolean local) {
      super(arraySize, local);
   }

   public Lock() {
      super(false);
   }

   @Override
    public String toString() {
        return "Lock";
    }

    @Override
    public <T> T accept(SVisitor.TypeVisitor<T> visitor) {
        return visitor.visit(this);
    }

}