package speclang.spec.ast.tree.declaration;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.visitor.SVisitor;

public class POrder extends LocInfo implements Node {
   public Order[] orders;

   public POrder(Order[] orders) {
      this.orders = orders;
   }

   public <R> R accept(SVisitor.POrderVisitor<R> v) {
     return v.visit(this);
   }
}
