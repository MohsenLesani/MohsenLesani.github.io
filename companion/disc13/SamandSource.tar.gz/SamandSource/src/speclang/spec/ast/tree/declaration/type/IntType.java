package speclang.spec.ast.tree.declaration.type;

public class IntType extends TypeArg {
    private static IntType theInstance = new IntType();

    public static IntType instance() {
        return theInstance;
    }

    private IntType() {
    }

    @Override
    public String toString() {
        return "Int";
//        return "Int" + super.toString();
    }

//    public <T> T accept(SVisitor.TypeVisitor<T> visitor) {
//        return visitor.visit(this);
//    }
}
