package speclang.spec.ast.tree.expression.op;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.visitor.SVisitor;


public abstract class Op extends BoolExp {

    public abstract String getName();
    public abstract String getLexeme();

    public abstract BoolExp[] getOperands();


    public <R> R accept(SVisitor.BoolExpVisitor<R> v) {
        return v.visit(this);
    }

    abstract public <R> R accept(SVisitor.BoolExpVisitor.OpVisitor<R> v);

}
