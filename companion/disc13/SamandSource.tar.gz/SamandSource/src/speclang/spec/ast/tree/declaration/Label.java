package speclang.spec.ast.tree.declaration;

import lesani.compiler.ast.LocInfo;
import speclang.spec.ast.tree.Node;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;

public class Label extends LocInfo {
   public Id id;

   public Label(Id id) {
      this.id = id;
   }

   @Override
   public String toString() {
      return id.name;
   }
}
