package speclang.spec.ast.tree.expression.op.atom;

import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;

/**
 * User: lesani, Date: 5-Nov-2009, Time: 10:08:25 AM
 */

public class Var extends Varl {

   public Id id;

   public Var(Id id) {
      this.id = id;
   }

   public <R> R accept(SVisitor.VarlVisitor<R> v) {
        return v.visit(this);
    }

   @Override
   public String toString() {
      return id.name;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      Var var = (Var) o;

      if (!id.equals(var.id)) return false;

      return true;
   }

   @Override
   public int hashCode() {
      return id.hashCode();
   }
}

