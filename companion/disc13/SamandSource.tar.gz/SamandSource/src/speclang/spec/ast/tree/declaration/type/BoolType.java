package speclang.spec.ast.tree.declaration.type;

//import speclang.typeinference.type.TypeVar;


public class BoolType extends TypeArg {
    private static BoolType theInstance = new BoolType();

    public static BoolType instance() {
        return theInstance;
    }

    private BoolType() {
    }

    @Override
    public String toString() {
        return "Bool";
    }

//    @Override
//    public <T> T accept(SVisitor.TypeVisitor<T> visitor) {
//        return visitor.visit(this);
//    }

}