package speclang.spec.ast.tree.statement;

import lesani.collection.option.Option;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.visitor.SVisitor;

public class Minus extends MathOp {

   public Minus(Option<Label> label, Var left, Varl operand1, Varl operand2) {
      super(label, left, operand1, operand2);
   }

   public String getOperator() {
      return "-";
   }

   public <R> R accept(SVisitor.StatementVisitor<R> v) {
      return v.visit(this);
   }

   public Option<Label> getLabel() {
      return label;
   }

   public <S, A> S accept(SVisitor.StatementVisitorArg<S, A> v, A a) {
      return v.visit(this, a);
   }
}


