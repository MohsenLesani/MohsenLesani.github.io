package speclang.spec.ast.tree.assertion;


import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.visitor.SVisitor;

public class OrderAsser extends Asser {
   public Label label1;
   public Label label2;

   public OrderAsser(Label label1, Label label2) {
      this.label1 = label1;
      this.label2 = label2;
   }

   public <R> R accept(SVisitor.AssertionVisitor<R> v) {
     return v.visit(this);
   }

   //   public <R> R accept(SVisitor.ConstraintVisitor<R> v) {
//       return v.visit(this);
//   }
}
