package speclang.spec.ast.tree.declaration;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.tree.assertion.Asser;
import speclang.spec.ast.visitor.SVisitor;

public class Spec extends LocInfo implements Node {
   public Asser asser;

   public Spec(Asser asser) {
      this.asser = asser;
   }

   public <R> R accept(SVisitor.SpecVisitor<R> v) {
     return v.visit(this);
   }
}
