package speclang.spec.ast.tree.assertion;


import lesani.compiler.ast.LocInfo;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.visitor.SVisitor;

public class OrAsser extends Asser {
   public Asser op1;
   public Asser op2;

   public OrAsser(Asser op1, Asser op2) {
      this.op1 = op1;
      this.op2 = op2;
   }

   public <R> R accept(SVisitor.AssertionVisitor<R> v) {
     return v.visit(this);
   }

//   public <R> R accept(SVisitor.ConstraintVisitor<R> v) {
//       return v.visit(this);
//   }
}
