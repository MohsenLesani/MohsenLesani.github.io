package speclang.spec.ast.tree.expression.op.atom;

import speclang.spec.ast.tree.token.IntLiteral;

/**
 * User: lesani, Date: 5-Nov-2009, Time: 12:41:55 PM
 */
public class AbortVal extends Val {

   public AbortVal() {
      super(new IntLiteral(7777777));
   }

   @Override
   public String toString() {
      return "\\A";
   }

}

