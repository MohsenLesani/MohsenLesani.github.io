package speclang.spec.ast.tree.declaration.type;

import speclang.spec.ast.tree.Node;
import speclang.spec.ast.visitor.SVisitor;
//import lesani.collection.xtolook.Either;
//import lesani.compiler.typing.Type;
//import lesani.compiler.typing.substitution.VarSubst;

public abstract class TypeArg implements Node {

    public <R> R accept(SVisitor<R> v) {
        return null;
    }

//    public abstract <T> T accept(SVisitor.TypeVisitor<T> visitor);

//    public Either<Type, Integer> apply(VarSubst varSubst) {
//        return new Either.Left<Type, Integer>(this);
//    }

}
