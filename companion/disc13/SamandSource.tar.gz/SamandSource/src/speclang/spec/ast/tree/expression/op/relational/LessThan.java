package speclang.spec.ast.tree.expression.op.relational;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.visitor.SVisitor;


/**
 * User: lesani, Date: Nov 3, 2009, Time: 2:19:53 PM
 */
public class LessThan extends RelationalOp {
    public static String name = "$LessThan";
    public static String lexeme = "<";

    public LessThan(BoolExp operand1, BoolExp operand2) {
        super(operand1, operand2);
    }

    public <R> R accept(SVisitor.BoolExpVisitor.OpVisitor.RelationalVisitor<R> v) {
        return v.visit(this);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getLexeme() {
        return lexeme;
    }

   public String toString() {
      return "(" + operand1 + " < " + operand2 + ")";
   }

}
