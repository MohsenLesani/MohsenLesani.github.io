package speclang.spec.ast.tree.assertion;


import lesani.compiler.ast.LocInfo;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.visitor.SVisitor;

public class ExecAsser extends Asser {
   public Label label;

   public ExecAsser(Label label) {
      this.label = label;
   }

   public <R> R accept(SVisitor.AssertionVisitor<R> v) {
     return v.visit(this);
   }

   //   public <R> R accept(SVisitor.ConstraintVisitor<R> v) {
//       return v.visit(this);
//   }
}
