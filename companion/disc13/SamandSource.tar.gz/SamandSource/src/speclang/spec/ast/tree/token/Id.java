package speclang.spec.ast.tree.token;

import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;

/**
 * User: lesani, Date: 5-Nov-2009, Time: 10:08:25 AM
 */

public class Id extends LocInfo implements Node { // extends BoolExp {

    public String name;

    public Id(String name) {
        this.name = name;
    }

//    public <R> R accept(SVisitor.StatementVisitor.BoolExpVisitor<R> v) {
//        return v.visit(this);
//    }


   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      Id id = (Id) o;

      if (!name.equals(id.name)) return false;

      return true;
   }

   @Override
   public int hashCode() {
      return name.hashCode();
   }
}

