package speclang.spec.ast.tree.statement;

import lesani.collection.option.Option;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;

public class New extends Statement {

   public Var left;
   public Id clazz;

   public New(Option<Label> label, Var var, Id clazz) {
      super(label);
      this.left = var;
      this.clazz = clazz;
   }

   public <R> R accept(SVisitor.StatementVisitor<R> v) {
      return v.visit(this);
   }

   public Option<Label> getLabel() {
      return label;
   }

   public <S, A> S accept(SVisitor.StatementVisitorArg<S, A> v, A a) {
      return v.visit(this, a);
   }
}


