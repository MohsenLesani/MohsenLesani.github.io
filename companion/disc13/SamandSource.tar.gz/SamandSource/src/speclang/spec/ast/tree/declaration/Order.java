package speclang.spec.ast.tree.declaration;

import lesani.collection.Pair;
import lesani.compiler.ast.LocInfo;
import lesani.compiler.ast.Node;
import speclang.spec.ast.visitor.SVisitor;

public class Order extends LocInfo implements Node {
   public Pair<Label, Label> order;

   public Order(Pair<Label, Label> order) {
      this.order = order;
   }

   public Order(Label l1, Label l2) {
      this.order = new Pair<Label, Label>(l1, l2);
   }

}


