package speclang.smt2.ast;

public interface Node {
}
