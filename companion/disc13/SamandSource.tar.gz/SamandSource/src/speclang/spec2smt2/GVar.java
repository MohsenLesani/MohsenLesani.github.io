package speclang.spec2smt2;

import speclang.spec.ast.tree.expression.op.atom.Var;

public class GVar {
   public String preLabel;
   public Var var;
   public GNode node;

   public GVar(String preLabel, Var var) {
      this.preLabel = preLabel;
      this.var = var;
   }

   public String getFlatName() {
//      final String preLabel = getPreLabel();
      final String varName = var.id.name;
//      System.out.println(varName);
      String s = (preLabel.equals("")) ? varName : preLabel + "." + varName;
//      System.out.println(s);
      return s;
   }

   @Override
   public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;

      GVar gVar = (GVar) o;

      if (!preLabel.equals(gVar.preLabel)) return false;
      if (!var.equals(gVar.var)) return false;

      return true;
   }

   @Override
   public int hashCode() {
      int result = preLabel.hashCode();
      result = 31 * result + var.hashCode();
      return result;
   }
}
