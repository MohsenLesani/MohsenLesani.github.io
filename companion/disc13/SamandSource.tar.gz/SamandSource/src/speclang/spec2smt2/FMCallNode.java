package speclang.spec2smt2;

import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import lesani.collection.option.Option;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.statement.FieldMethodCall;
import speclang.spec.ast.tree.statement.GMethodCall;

public class FMCallNode extends GMCallNode {

   public FieldMethodCall methodCall;

   public FMCallNode(FieldMethodCall methodCall, GCond cond, int tId, int level) {
      super(cond, tId, level);
      this.methodCall = methodCall;
   }

   @Override
   public String toString() {
      String s = printFlatLabel();
      final ExpPrinter printer = new ExpPrinter(preLabel);
//      String s = "";
      for (int i = 0; i < level*3; i++) {
         s += " ";
      }

      String args = "";
      for (int i = 0; i < methodCall.args.length; i++) {
         Varl arg = methodCall.args[i];
//         args += arg.toString();
         args += printer.visitDistch(arg);
         if (i != methodCall.args.length - 1)
            args += ", ";
      }

      if (retNodeOption.isPresent())
         s += "Inv(";
      s += methodCall.retv.apply(
         new Fun0<String>() {
            public String apply() {
               return "";
            }
         },
         new Fun<Var, String>() {
            public String apply(Var var) {
               String s = "";
               s += printer.visitDistch(var) + " = ";
               return s;
            }
         }
      );
      s += methodCall.ref.id.name + ".";
      s += methodCall.obj.name.equals("this") ? "" : methodCall.obj.name;

      s += methodCall.index.apply(
         new Fun0<String>() {
            public String apply() {
               return "";
            }
         },
         new Fun<Varl, String>() {
            public String apply(Varl varl) {
               return "[" + printer.visit(varl) + "]";
            }
         }
      );

      s += "." + methodCall.name.name +
           "(" + args + ")";
      if (retNodeOption.isPresent())
         s += ")";

//      return s + methodCall.toString();
      return s;
   }

   @Override
   public GMethodCall getGMethodCall() {
      return methodCall;
   }

}

