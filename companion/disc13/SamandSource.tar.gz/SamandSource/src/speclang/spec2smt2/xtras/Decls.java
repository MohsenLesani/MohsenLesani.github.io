package speclang.spec2smt2.xtras;

import lesani.compiler.texttree.Snippet;
import speclang.spec.ast.tree.declaration.Decl;

public class Decls extends Snippet {

   public Decls(Decl[] decls) {
      super(gen(decls));
   }

   private static String gen(Decl[] decls) {
      String s =
         "(declare-datatypes () (\n" +
         "\t(Obj\n";
//      for (Decl decl : decls) {
//         s += "\t" + decl.id.toString() + "\n";
//      }
      s +=
         "\t)\n" +
         "))\n";
      return s;
   }
}
