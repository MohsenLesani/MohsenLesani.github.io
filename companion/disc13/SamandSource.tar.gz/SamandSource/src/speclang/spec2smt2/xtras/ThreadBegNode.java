package speclang.spec2smt2.xtras;

import speclang.spec.ast.tree.statement.Statement;
import speclang.spec2smt2.GNode;

public class ThreadBegNode {

   public ThreadBegNode(int tId, int indent) {
   }

   public Statement getStatement() {
      return null;  //To change body of implemented methods use File | Settings | File Templates.
   }

   public boolean isExec() {
      return false;  //To change body of implemented methods use File | Settings | File Templates.
   }
}
