package speclang.spec2smt2.xtras;

import lesani.compiler.texttree.Text;
import lesani.compiler.texttree.seq.TextSeq;
import speclang.spec.ast.tree.declaration.Def;
import speclang.spec.ast.tree.declaration.Main;
import speclang.spec.ast.tree.statement.*;

public class Labels {

   public static Text gen(Main main, Def[] defs) {
      TextSeq seq = new TextSeq();
      seq.put(
         "(declare-datatypes () (\n" +
         "\t(Label\n");
      seq.put(
         "\t\t");

      for (Statement[] block : main.blocks) {
         for (Statement statement : block) {
//            SVisitor.StatementVisitor<Text> statementVisitor = new SVisitor.StatementVisitor<Text>() {

//               public Text visit(MethodCall methodCall) {
//                  SVisitor.DefVisitor<Text> statementVisitor = new SVisitor.DefVisitor<Text>() {
//                     public Text visit(Def def) {
//                        def.statement;
//                     }
//                  }
//
//                  return null;
//               }

//               public Text visit(If anIf) {
//                  return Label.gen(anIf);
//               }
//
//               public Text visit(Block block) {
//                  TextSeq seq2 = new TextSeq();
//                  for (Statement inStatement : block.statements) {
//                     Text t = inStatement.accept(this);
//                     seq2.put(t);
//                  }
//                  return seq2.get();
//               }
//
//               public Text visit(Return aReturn) {
//                  return null;
//               }
//
//               public Text visit(While aWhile) {
//                  return null;
//               }
//            };
//            Text t = statement.accept(statementVisitor);
//            seq.put(t);
         }
      }

      seq.put(
         "\n");
      seq.put(
         "\t)\n" +
         "))\n");

      return seq.get();
   }

}
