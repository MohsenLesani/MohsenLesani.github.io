package speclang.spec2smt2;

import lesani.collection.func.Fun;
import lesani.collection.option.None;
import lesani.collection.option.Option;
import lesani.collection.option.Some;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.statement.GMethodCall;

public abstract class GMCallNode extends XNode {

   public Option<RetNode> retNodeOption = None.instance();

   public GMCallNode(GCond cond, int tId, int level) {
      super(cond, tId, level);
   }

   public abstract GMethodCall getGMethodCall();

   public Option<String> getFlatVarName() {
      return getGMethodCall().retv.apply(
         new Fun<Var, String>() {
            public String apply(Var var) {
               final String varName = var.id.name;
               return (preLabel.equals("")) ? varName : preLabel + "." + varName;
            }
         }
      );
   }

   @Override
   public String getLabel() {
      String s = getLabel(getGMethodCall());
      if (!retNodeOption.isPresent())
         return s;
      return s + "_Inv";
   }

   public boolean isInvNode() {
      return retNodeOption.isPresent();
   }

   public void setRetNode(RetNode retNode) {
      this.retNodeOption = new Some<RetNode>(retNode);
   }

}

