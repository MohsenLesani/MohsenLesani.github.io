package speclang.spec2smt2;

import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.statement.Statement;

import java.util.HashSet;
import java.util.Set;

public abstract class XNode extends GNode {
   public Set<GCond> conds;

   public XNode(GCond cond, int tId, int level) {
      super(tId, level);
      this.conds = new HashSet<GCond>();
      this.conds.add(cond);
   }


   public abstract String getLabel();

   public String getFlatLabel() {
      String name = getLabel();
      return (preLabel.equals("")) ? name : preLabel + "." + name;

/*
      final Statement statement = getStatement();
      return statement.label.apply(
         new Fun0<String>() {
            public String apply() {
               throw new RuntimeException(
                  "Explicit Labels needed for statement " + statement.getLoc());
            }
         },
         new Fun<Label, String>() {
            public String apply(Label label) {
               String name = label.id.name;
               return (preLabel.equals("")) ? name : preLabel + "." + name;
            }
         }
      );
*/
   }


}
