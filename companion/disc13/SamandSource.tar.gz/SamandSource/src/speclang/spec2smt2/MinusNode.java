package speclang.spec2smt2;

import speclang.spec.ast.tree.statement.Minus;
import speclang.spec.ast.tree.statement.Plus;
import speclang.spec.ast.tree.statement.Statement;


public class MinusNode extends MathOpNode {
   public Minus minus;

   public MinusNode(String preLabel, Minus minus, GCond cond, int tId, int indent) {
      super(preLabel, minus, cond, tId, indent);
      this.minus = minus;
   }

   public Statement getStatement() {
      return minus;
   }

   @Override
   public String getLabel() {
      return getLabel(minus);
   }

   @Override
   public String toString() {
      String s = printFlatLabel();
      for (int i = 0; i < level *3; i++)
         s += " ";
      ExpPrinter printer = new ExpPrinter(preLabel);
      String leftString = printer.visitDistch(minus.left);
      String op1String = printer.visitDistch(minus.operand1);
      String op2String = printer.visitDistch(minus.operand2);

      return s + leftString + " = " + op1String + " - " + op2String;
   }
}


