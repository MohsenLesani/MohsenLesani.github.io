package speclang.spec2smt2;

import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.tree.expression.op.atom.Var;

import java.util.Set;

public class GCond {
   public  String preLabel;
   public Set<BoolExp> conds;

   public GCond(String preLabel, Set<BoolExp> conds) {
      this.preLabel = preLabel;
      this.conds = conds;
   }
}
