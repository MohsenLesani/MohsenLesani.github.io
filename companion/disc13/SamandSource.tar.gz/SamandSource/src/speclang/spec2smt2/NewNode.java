package speclang.spec2smt2;

import speclang.spec.ast.tree.statement.New;
import speclang.spec.ast.tree.statement.Statement;


public class NewNode extends XNode {
   public New theNew;

   public NewNode(String preLabel, New theNew, GCond cond, int tId, int level) {
      super(cond, tId, level);
      this.preLabel = preLabel;
      this.theNew = theNew;
   }

   public Statement getStatement() {
      return theNew;
   }

   @Override
   public String getLabel() {
      return getLabel(theNew);
   }

   @Override
   public String toString() {
      String s = printFlatLabel();
      for (int i = 0; i < level *3; i++)
         s += " ";
      ExpPrinter printer = new ExpPrinter(preLabel);
      String leftString = printer.visitDistch(theNew.left);

      return s + leftString + " = new " + theNew.clazz.name + "()";
   }
}



