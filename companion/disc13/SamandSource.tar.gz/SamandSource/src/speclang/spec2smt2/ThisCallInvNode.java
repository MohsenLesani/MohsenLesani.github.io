package speclang.spec2smt2;

import speclang.spec.ast.tree.declaration.Def;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.statement.MethodCall;
import java.util.Set;

public class ThisCallInvNode extends XNode {
   public Set<GNode> nesteds;
   public ThisCallRetNode retNode;
   public MethodCall methodCall;
   public Def def;

   public ThisCallInvNode(MethodCall methodCall, GCond cond, int tId, int level) {
      super(cond, tId, level);
      this.methodCall = methodCall;
   }

   @Override
   public String getLabel() {
      return getLabel(methodCall) + "_Inv";
   }

   public String getMethodCallLabel() {
      return getLabel(methodCall);
   }

   @Override
   public String toString() {
      String s = printFlatLabel();
//      String s = "";
      for (int i = 0; i < level*3; i++) {
         s += " ";
      }

      String args = "";
      for (int i = 0; i < methodCall.args.length; i++) {
         Varl arg = methodCall.args[i];
         if (def != null) {
            args += def.inParams[i].id.name;
            args += "=";
         }
         args += arg.toString();
         if (i != methodCall.args.length - 1)
            args += ", ";
      }
      // methodCall.obj.name + "." +
      s += "inv(" + methodCall.name.name +
            "(" + args + ")";
      s += ")";
//      return s + methodCall.toString();
      return s;
   }


//   @java.lang.Override
//   public boolean isExec() {
//      for (GNode nested : nesteds) {
//         if (nested.isExec())
//            return true;
//      }
//      return false;
//   }

//   @Override
//   public Option<String> getFlatVarName() {
//      return super.getFlatVarName().apply(
//            new Fun<String, String>() {
//               public String apply(String s) {
//                  return "Inv" + s;
//               }
//            }
//      );
//   }

}
