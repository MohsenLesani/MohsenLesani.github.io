package speclang.spec2smt2;

import speclang.spec.ast.tree.statement.Statement;

import java.util.Map;
import java.util.Set;

public class ElseNode extends GNode {
   public IfNode theIf;
   public Set<GNode> nesteds;

   public ElseNode(IfNode theIf, int tId, int indent) {
      super(tId, indent);
      this.theIf = theIf;
   }


   public boolean isExec() {
      for (GNode nested : nesteds) {
         if (!(nested instanceof MathOpNode) && nested.isExec())
            return true;
      }
      return false;
   }

   @Override
   public String getLabel() {
      return "";
//      return theIf.getLabel() + "(else)";
   }

   @Override
   public String toString() {
//      String s = "";
//      for (int i = 0; i < level *3 + theIf.getFlatLabel().length() + 3; i++) {
//         s += " ";
//      }
//      s += "\t";
      String s = printFlatLabel();

      for (int i = 0; i < level *3; i++) {
         s += " ";
      }
      return s + "else";
   }



}
