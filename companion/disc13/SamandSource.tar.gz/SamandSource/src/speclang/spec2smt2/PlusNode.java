package speclang.spec2smt2;

import speclang.spec.ast.tree.statement.Plus;
import speclang.spec.ast.tree.statement.Statement;



public class PlusNode extends MathOpNode {
   public Plus plus;

   public PlusNode(String preLabel, Plus plus, GCond cond, int tId, int indent) {
      super(preLabel, plus, cond, tId, indent);
      this.plus = plus;
   }

   public Statement getStatement() {
      return plus;
   }

   @Override
   public String getLabel() {
      return getLabel(plus);
   }

   @Override
   public String toString() {
      String s = printFlatLabel();
      for (int i = 0; i < level *3; i++)
         s += " ";
      ExpPrinter printer = new ExpPrinter(preLabel);
      String leftString = printer.visitDistch(plus.left);
      String op1String = printer.visitDistch(plus.operand1);
      String op2String = printer.visitDistch(plus.operand2);

      return s + leftString + " = " + op1String + " + " + op2String;
   }
}


