package speclang.spec2smt2;

import speclang.spec.ast.tree.statement.MathOp;

public abstract class MathOpNode extends XNode {

   public MathOp mathOp;

   public MathOpNode(String preLabel, MathOp mathOp, GCond cond, int tId, int level) {
      super(cond, tId, level);
      this.preLabel = preLabel;
      this.mathOp = mathOp;
   }

   @Override
   public boolean isExec() {
      return parent.isExec();
//      return true;
   }
}
