package speclang.spec2smt2;

import lesani.alg.java.Graph;
import lesani.alg.java.TopologicalSort;
import lesani.collection.Pair;
import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import lesani.collection.func.Fun2;
import lesani.collection.option.None;
import lesani.collection.option.Option;
import lesani.collection.option.Some;
import lesani.compiler.texttree.Snippet;
import lesani.compiler.texttree.Text;
import lesani.compiler.texttree.seq.TextFact;
import lesani.compiler.texttree.seq.TextSeq;
import speclang.spec.ast.tree.assertion.*;
import speclang.spec.ast.tree.declaration.*;
import speclang.spec.ast.tree.declaration.type.*;
import speclang.spec.ast.tree.expression.BoolExp;
import speclang.spec.ast.tree.expression.op.Op;
import speclang.spec.ast.tree.expression.op.atom.Val;
import speclang.spec.ast.tree.expression.op.atom.Var;
import speclang.spec.ast.tree.expression.op.atom.Varl;
import speclang.spec.ast.tree.expression.op.logical.And;
import speclang.spec.ast.tree.expression.op.logical.LogicalOp;
import speclang.spec.ast.tree.expression.op.logical.Not;
import speclang.spec.ast.tree.expression.op.logical.Or;
import speclang.spec.ast.tree.expression.op.relational.RelationalOp;
import speclang.spec.ast.tree.statement.*;
import speclang.spec.ast.tree.token.Id;
import speclang.spec.ast.visitor.SVisitor;

import java.lang.reflect.Array;
import java.util.*;


public class SpecProcessor {

   private Specification specification;
   // Maps from name to defs and from labels to statements.
   // These maps are constructed directly from the spec
   private HashMap<String, Def> name2Defs = new HashMap<String, Def>();
   private HashMap<String, Type> name2Type = new HashMap<String, Type>();
   private HashMap<String, Statement> label2St = new HashMap<String, Statement>();

//   private Graph<String> pOrders = new Graph<String>();
//   private Map<Statement, Set<Statement>> deps = new HashMap<Statement, Set<Statement>>();
   private Graph<Statement> deps = new Graph<Statement>();
   // A map from each method call to the conditions of the if statements
   // that nest the method call.
   private HashMap<Statement, Set<BoolExp>> st2Conds = new HashMap<Statement, Set<BoolExp>>();

   // We order xNodes to have a define order of them for reading the relations
   // logged from the z3 model.
   // For the same reason we order vars too.
   private Set<XNode> xNodes = new HashSet<XNode>();
   private Set<GVar> vars = new HashSet<GVar>();
   private Set<ThisCallInvNode> thisCalls = new HashSet<ThisCallInvNode>();
   private Set<MathOpNode> mathOpNodes = new HashSet<MathOpNode>();
   private Set<NewNode> newNodes = new HashSet<NewNode>();

   private Graph<GNode> execGraph = new Graph<GNode>();

   private Map<String, Integer> valOf = new HashMap<String, Integer>();
   // Note: If we want to have the same labels in different defs,
   // we may need to define a Label type and use it instead of String.

   private Set<GNode>[] threadNodes;

   private TextFact textFact = new TextFact();
   public SpecProcessor(Specification specification) {
      this.specification = specification;
   }

   // --------------------------------------------------------------------------------
   public Text generate() {
      prepareDataStructures();
      return translate();
   }

   private void prepareDataStructures() {
      makeDefAndStMaps();
      makeDepsAndConds();
      makeGraphAndOrderMCallsAndVars();
   }

   private Text translate() {
      // To translate to z3 only the MCalls and their transitive p orders,
      // and also the if conditions.
      TextSeq seq = textFact.newText();

      seq.add(genPrelude());
      seq.add(genBaseObjects());
      seq.add(genLabels());
      seq.add(genVars());
      seq.add(genPredefs());
      seq.add(genP());
      seq.add(genThisCallRules());
      seq.add(genPrecX());
      seq.add(genBaseObjectsRules());
      seq.add(genConjecture());
      seq.add(genLogs());

      return seq.get();
   }

   // --------------------------------------------------------------------------------

   private void makeDefAndStMaps() {
      Def[] defs = specification.defs;
      for (Def def : defs) {
//         System.out.println(def);
         final String name = def.name.name;
         this.name2Defs.put(name, def);
      }

      Decl[] decls = specification.decls;
      for (Decl decl : decls) {
         final String name = decl.id.name;
         final Type type = decl.type;
         name2Type.put(name, type);
      }
      specification.structOption.apply(
         new Fun<Struct, Object>() {
            public Object apply(Struct struct) {
               //String name = struct.name.name;
               for (Decl decl : struct.decls) {
                  String name = "struct" + "." + decl.id.name;
                  final Type type = decl.type;
                  name2Type.put(name, type);
               }
               return null;
            }
         }
      );
      name2Type.put("lastObj", new AtomicRegister());

      SVisitor.StatementVisitor<None> statementVisitor = new SVisitor
            .StatementVisitor<None>() {
         Fun2<Option<Label>, Statement, Object> fun =
            new Fun2<Option<Label>, Statement, Object>() {
               public Object apply(Option<Label> label, final Statement statement) {
                  return label.apply(
                     new Fun0<Object>() {
                        public Object apply() {
                           throw new RuntimeException("Currently, we require explicit labels.");
                        }
                     },
                     new Fun<Label, Object>() {
                        public Object apply(Label label) {
                           String name = label.id.name;
                           label2St.put(name, statement);
                           return null;
                        }
                     }
                  );
               }
            };
         public None visitDispatch(Statement statement) {
            return statement.accept(this);
         }
         public None visit(MethodCall methodCall) {
            fun.apply(methodCall.label, methodCall);
            return None.instance();
         }

         public None visit(If anIf) {
            fun.apply(anIf.label, anIf);
            for (Statement thenStatement : anIf.thenStatements)
               visitDispatch(thenStatement);
            anIf.elseStatements.apply(
               new Fun<Statement[], Object>() {
                  public Object apply(Statement[] statements) {
                     for (Statement statement : statements)
                        visitDispatch(statement);
                     return null;
                  }
               }
            );
            return None.instance();
         }

         public None visit(Return aReturn) {
            fun.apply(aReturn.label, aReturn);
            return None.instance();
         }

         public None visit(While aWhile) {
            return None.instance();
         }

         public None visit(New aNew) {
            fun.apply(aNew.label, aNew);
            return None.instance();
         }

         public None visit(FieldMethodCall fieldMethodCall) {
            fun.apply(fieldMethodCall.label, fieldMethodCall);
            return None.instance();
         }

         public None visit(Plus plus) {
            fun.apply(plus.label, plus);
            return None.instance();
         }

         public None visit(Minus minus) {
            fun.apply(minus.label, minus);
            return None.instance();
         }
      };

      for (Def def : defs) {
         for (final Statement statement : def.statements) {
//            System.out.println(statement);
            statement.accept(statementVisitor);
         }
      }
      for (Statement[] block : specification.main.blocks) {
         for (Statement statement : block) {
            statement.accept(statementVisitor);
         }
      }
   }

   private void makeDepsAndConds() {
      // To build a graph of labels and program orders between them.
      // The graph is the transitive closure of declared orders, data dependencies and
      // control dependencies.
      // The graph is consulted when generating \prec_p.
      // conds: ...

//      for (String s : label2St.keySet())
//         pOrders.add(s);

      for (Order order : specification.pOrder.orders) {
         Statement s1 = label2St.get(order.order._1().id.name);
         Statement s2 = label2St.get(order.order._2().id.name);
         deps.add(s1, s2);
      }

      // Add data and control dependencies
      class StVisitor implements SVisitor.StatementVisitorArg<
               Map<String, Set<Statement>>, Map<String, Set<Statement>>
            > {
         // Data dependencies
         // We need to know the label of the MethodCall where a variable is introduced.
//         Map<String, Statement> varSource = new HashMap<String, Statement>();
         Set<String> paramVars = new HashSet<String>();
         // Control dependencies
         // We keep the nesting ifs
         Stack<Statement> ifStack = new Stack<Statement>();
         Stack<BoolExp> ifCondStack = new Stack<BoolExp>();

         /*
         private String getLabelString(Option<Label> label) {
            return label.apply(
               new Fun0<String>() {
                  public String apply() {
                     throw new RuntimeException(
                        "Currently, We require explicit labels.");
                  }
               },
               new Fun<Label, String>() {
                  public String apply(Label label) {
                     return label.id.name;
                  }
               }
            );
         }
         */
         public void reset() {
//            varSource = new HashMap<String, Statement>();
            ifStack = new Stack<Statement>();
            ifCondStack = new Stack<BoolExp>();
            paramVars = new HashSet<String>();
         }
         private void addControlDep(Statement statement) {
            for (Statement ifSt : ifStack)
               deps.add(ifSt, statement);
         }

         private void addDataDep(
               Map<String, Set<Statement>> varSource,
               Statement statement, String varString) {

            if (!paramVars.contains(varString) && !varString.equals("t")) {
               Set<Statement> sourceStatements = varSource.get(varString);
               if (sourceStatements == null || sourceStatements.size() == 0) {
                  System.out.println("The var source map is");
                  System.out.println(varSource);
                  throw new RuntimeException(
                     "Source statement not found for " + varString + " " +
                     "at " + statement.getLoc() + ".");
               }
               for (Statement sourceStatement : sourceStatements) {
                  deps.add(sourceStatement, statement);
               }
            }
         }
         private Map<String, Set<Statement>> merge(
               Map<String, Set<Statement>> varSource1,
               Map<String, Set<Statement>> varSource2) {
            for (Map.Entry<String, Set<Statement>> stringSetEntry : varSource2.entrySet()) {
               String var = stringSetEntry.getKey();
               Set<Statement> set = stringSetEntry.getValue();

               Set<Statement> set1 = varSource1.get(var);
               if (set1 == null)
                  varSource1.put(var, set);
               else
                  set1.addAll(set);
            }
//            System.out.println("After merge:");
//            System.out.println(varSource1);
            return varSource1;
         }

         public void addInputVar(String name) {
            paramVars.add(name);
         }

         class ExpVisitor implements SVisitor.BoolExpVisitor<None> {
            Statement currentStatement;
            Map<String, Set<Statement>> varSource;

            public void setCurrentStatement(Statement statement) {
               currentStatement = statement;
            }
            public void setVarSource(Map<String,Set<Statement>> varSource) {
               this.varSource = varSource;
            }

            public None visitDispatch(BoolExp exp) {
               return exp.accept(this);
            }
            public None visit(Op op) {
               for (BoolExp exp : op.getOperands())
                  visitDispatch(exp);
               return None.instance();
            }
            public None visit(Varl varl) {
               SVisitor.VarlVisitor<None> varlVisitor = new SVisitor.VarlVisitor<None>() {
                  public None visit(Var var) {
                     String varString = var.id.name;
                     addDataDep(varSource, currentStatement, varString);
                     return None.instance();
                  }

                  public None visit(Val val) {
                     return None.instance();
                  }
               };
               return varl.accept(varlVisitor);
            }
         }
         ExpVisitor expVisitor = new ExpVisitor();

         public Map<String, Set<Statement>> visitDispatch(Statement statement,
                                                          Map<String, Set<Statement>> varSource) {
            deps.add(statement);
            return statement.accept(this, varSource);
         }

         private void addVarSource(Map<String, Set<Statement>> varSource,
                                   String varString, Statement statement) {
            Set<Statement> statements = varSource.get(varString);
            if (statements == null) {
               statements = new HashSet<Statement>();
               statements.add(statement);
               varSource.put(varString, statements);
            } else
               statements.add(statement);
         }

         public Map<String, Set<Statement>> visit(final MethodCall methodCall,
                                                  final Map<String, Set<Statement>> varSource) {
            //final String labelString = getLabelString(methodCall.label);
            addControlDep(methodCall);
            expVisitor.setCurrentStatement(methodCall);
            expVisitor.setVarSource(varSource);
            methodCall.index.apply(
               new Fun<Varl, Object>() {
                  public Object apply(Varl varl) {
                     return expVisitor.visitDispatch(varl);
                  }
               }
            );

            for (Varl arg : methodCall.args)
               expVisitor.visitDispatch(arg);

            methodCall.retv.apply(
                  new Fun<Var, None>() {
                     public None apply(Var var) {
                        String varString = var.id.name;
                        addVarSource(varSource, varString, methodCall);
                        return None.instance();
                     }
                  }
            );

            Set<BoolExp> conds = new HashSet<BoolExp>();
            for (BoolExp boolExp : ifCondStack)
               conds.add(boolExp);
            st2Conds.put(methodCall, conds);

            return varSource;
         }

         public Map<String, Set<Statement>> visit(final FieldMethodCall methodCall,
                                                  final Map<String, Set<Statement>> varSource) {
            addControlDep(methodCall);
            expVisitor.setCurrentStatement(methodCall);
            expVisitor.setVarSource(varSource);

            expVisitor.visitDispatch(methodCall.ref);
            methodCall.index.apply(
                  new Fun<Varl, Object>() {
                     public Object apply(Varl varl) {
                        return expVisitor.visitDispatch(varl);
                     }
                  }
            );
            for (Varl arg : methodCall.args)
               expVisitor.visitDispatch(arg);

            methodCall.retv.apply(
               new Fun<Var, None>() {
                  public None apply(Var var) {
                     String varString = var.id.name;
                     addVarSource(varSource, varString, methodCall);
                     return None.instance();
                  }
               }
            );

            Set<BoolExp> conds = new HashSet<BoolExp>();
            for (BoolExp boolExp : ifCondStack)
               conds.add(boolExp);
            st2Conds.put(methodCall, conds);

            return varSource;
         }

         public Map<String, Set<Statement>> visit(final If theIf,
                                                  Map<String, Set<Statement>> varSource) {
            //String labelString = getLabelString(theIf.label);

            // Set its data deps.
            expVisitor.setCurrentStatement(theIf);
            expVisitor.setVarSource(varSource);
            expVisitor.visitDispatch(theIf.condition);

            addControlDep(theIf);

            Map<String, Set<Statement>> ifVarSource =
                  new HashMap<String, Set<Statement>>(varSource);
            final Map<String, Set<Statement>> elseVarSource =
                  new HashMap<String, Set<Statement>>(varSource);


            ifStack.push(theIf);
            ifCondStack.push(theIf.condition);
            for (Statement statement : theIf.thenStatements)
               ifVarSource = visitDispatch(statement, ifVarSource);

            Map<String, Set<Statement>> elseVarSourceRes =
            theIf.elseStatements.apply(
               new Fun0<Map<String, Set<Statement>>>() {
                  public Map<String, Set<Statement>> apply() {
                     return new HashMap<String, Set<Statement>>();
                  }
               },
               new Fun<Statement[], Map<String, Set<Statement>>>() {
                  public Map<String, Set<Statement>> apply(Statement[] statements) {
                     ifCondStack.pop();
                     ifCondStack.push(new Not(theIf.condition));
                     Map<String, Set<Statement>> elseVarSourceIn =
                           elseVarSource;

                     for (Statement statement : statements)
                        elseVarSourceIn = visitDispatch(statement, elseVarSourceIn);
                     return elseVarSourceIn;
                  }
               }
            );

            ifStack.pop();
            ifCondStack.pop();
            return merge(ifVarSource, elseVarSourceRes);
         }

         public Map<String, Set<Statement>> visit(New aNew,
                                                  Map<String, Set<Statement>> varSource) {
            addControlDep(aNew);
            String varString = aNew.left.id.name;
//            System.out.println(varString);
            addVarSource(varSource, varString, aNew);

            Set<BoolExp> conds = new HashSet<BoolExp>();
            for (BoolExp boolExp : ifCondStack)
               conds.add(boolExp);
            st2Conds.put(aNew, conds);

            return varSource;
         }

         public Map<String, Set<Statement>> visit(Return theReturn,
                                                  Map<String, Set<Statement>> varSource) {
            //String labelString = getLabelString(theReturn.label);
            addControlDep(theReturn);
            expVisitor.setCurrentStatement(theReturn);
            expVisitor.setVarSource(varSource);
            theReturn.varl.apply(
               new Fun<Varl, None>() {
                  public None apply(Varl varl) {
                     expVisitor.visitDispatch(varl);
                     return None.instance();
                  }
               }
            );

            Set<BoolExp> conds = new HashSet<BoolExp>();
            for (BoolExp boolExp : ifCondStack)
               conds.add(boolExp);
            st2Conds.put(theReturn, conds);

            return varSource;
         }

         public Map<String, Set<Statement>> visit(While aWhile,
                                                  Map<String, Set<Statement>> varSource) {
            // For later.
            return varSource;
         }

         public Map<String, Set<Statement>> visit(Plus plus,
                                                  Map<String, Set<Statement>> varSource) {
            addControlDep(plus);
            expVisitor.setCurrentStatement(plus);
            expVisitor.setVarSource(varSource);
            expVisitor.visitDispatch(plus.operand1);
            expVisitor.visitDispatch(plus.operand2);
            String varString = plus.left.id.name;
            addVarSource(varSource, varString, plus);

            Set<BoolExp> conds = new HashSet<BoolExp>();
            for (BoolExp boolExp : ifCondStack)
               conds.add(boolExp);
            st2Conds.put(plus, conds);

            return varSource;
         }

         public Map<String, Set<Statement>> visit(Minus minus,
                                                  Map<String, Set<Statement>> varSource) {
            addControlDep(minus);
            expVisitor.setCurrentStatement(minus);
            expVisitor.setVarSource(varSource);
            expVisitor.visitDispatch(minus.operand1);
            expVisitor.visitDispatch(minus.operand2);
            String varString = minus.left.id.name;
            addVarSource(varSource, varString, minus);

            Set<BoolExp> conds = new HashSet<BoolExp>();
            for (BoolExp boolExp : ifCondStack)
               conds.add(boolExp);
            st2Conds.put(minus, conds);

            return varSource;
         }
      }
      StVisitor statementVisitor = new StVisitor();

      Map<String, Set<Statement>> varSource = new HashMap<String, Set<Statement>>();
      for (Statement[] block : specification.main.blocks) {
         statementVisitor.reset();
         for (Statement statement : block)
            varSource = statementVisitor.visitDispatch(statement, varSource);
      }

      for (Def def : specification.defs) {
         statementVisitor.reset();
         for (Var inParam : def.inParams) {
            statementVisitor.addInputVar(inParam.id.name);
         }
         varSource = new HashMap<String, Set<Statement>>();
         for (Statement statement : def.statements)
            varSource = statementVisitor.visitDispatch(statement, varSource);
      }

      deps.selfExTransClosure();
   }

   private void makeGraphAndOrderMCallsAndVars() {
      // To keep a graph in the program that has nodes for inv and ret events,
      // if statements, method calls and return statements. The edges keep the
      // precedence of each if statements before the statements in it and that
      // each statement of a this method call is between its inv and ret).
      // The nodes of this graph keep the indentation level that is used when
      // rendering an interleaving.
      // xNodes and vars are populated here.

      class StVisitor implements SVisitor.StatementVisitor<Pair<Set<GNode>, Set<GNode>>> {
         int tId = 0;
         int level = 0;
//         int xNodeCount = 0;
//         int varCount = 0;
         // If we want to have nested this calls, we need to change this to a stack.
         String preLabel = "";

         // These two maps keep the mapping from each statement to generated nodes
         // for the statement and the other way around.
         Stack<Map<GNode, Statement>> node2St = new Stack<Map<GNode, Statement>>();
         Stack<Map<Statement, Set<GNode>>> st2Node = new Stack<Map<Statement, Set<GNode>>>();

         StVisitor() {
            node2St.push(new HashMap<GNode, Statement>());
            st2Node.push(new HashMap<Statement, Set<GNode>>());
         }

         // This keeps the set of generated nodes since the last reset.
         Set<GNode> nodes = new HashSet<GNode>();

         Set<GNode> prevFenceNodes = new HashSet<GNode>();
         Set<ReturnNode> returnNodes = new HashSet<ReturnNode>();

         public void reset() {
            node2St = new Stack<Map<GNode, Statement>>();
            st2Node = new Stack<Map<Statement, Set<GNode>>>();
            node2St.push(new HashMap<GNode, Statement>());
            st2Node.push(new HashMap<Statement, Set<GNode>>());
            nodes = new HashSet<GNode>();
            prevFenceNodes = new HashSet<GNode>();
            returnNodes = new HashSet<ReturnNode>();
         }

         // The first element of the pair is the set of direct nodes generated for
         // the statement.
         // The second element of the pair is the set of all nodes generated during
         // the visit of the statement.
         public Pair<Set<GNode>, Set<GNode>> visitDispatch(Statement statement) {
            HashSet<ReturnNode> returnNodes = new HashSet<ReturnNode>(this.returnNodes);
            Pair<Set<GNode>, Set<GNode>> res = statement.accept(this);
            Set<GNode> nodes = res._1();
            for (GNode node : nodes) {
               node.preLabel = preLabel;
               node.setPrecReturns(returnNodes);
               node2St.peek().put(node, statement);
               this.nodes.add(node);
               for (GNode prevFenceNode : prevFenceNodes)
//                  if (prevFenceNode != node)
                  if (!res._2().contains(prevFenceNode))
                     execGraph.add(prevFenceNode, node);
            }
            st2Node.peek().put(statement, nodes);
            return res;
         }

         private Pair<Set<GNode>, Set<GNode>> visitThisMethodCall(final MethodCall methodCall) {
            Set<GNode> prevNodes = new HashSet<GNode>(nodes);
            Set<GNode> prevFenceNodes = new HashSet<GNode>(this.prevFenceNodes);

            node2St.push(new HashMap<GNode, Statement>());
            st2Node.push(new HashMap<Statement, Set<GNode>>());

            returnNodes = new HashSet<ReturnNode>();
            preLabel = methodCall.label.apply(
               new Fun0<String>() {
                  public String apply() {
                     throw new RuntimeException(
                        "Explicit Labels needed for statement " + methodCall.getLoc());
                  }
               },
               new Fun<Label, String>() {
                  public String apply(Label label) {
                     String name = label.id.name;
//                     return (preLabel.equals("")) ? name : preLabel + "." + name;
                     return name;
                  }
               }
            );

            String methodName = methodCall.name.name;
            Def def = name2Defs.get(methodName);

            Set<BoolExp> conds = st2Conds.get(methodCall);
            GCond gCond = new GCond("", conds);
            final ThisCallInvNode invNode = new ThisCallInvNode(methodCall, gCond, tId, level);
//            xNodes.put(xNodeCount, invNode);
            xNodes.add(invNode);
//            xNodeCount++;
            final ThisCallRetNode retNode = new ThisCallRetNode(methodCall, gCond, tId, level);
//            xNodes.put(xNodeCount, retNode);
            xNodes.add(retNode);
//            xNodeCount++;
            // Add to vars if this method has a return value.
            methodCall.retv.apply(
               new Fun<Var, Object>() {
                  public Object apply(Var var) {
                     final GVar gVar = new GVar("", var);
                     gVar.node = retNode;
//                     vars.put(varCount, gVar);
                     vars.add(gVar);
//                     varCount++;
                     return null;
                  }
               }
            );
            for (Var inParam : def.inParams) {
               final GVar gVar = new GVar(preLabel, new Var(inParam.id));
               gVar.node = invNode;
//               vars.put(varCount, gVar);
               vars.add(gVar);
//               varCount++;
            }
            final GVar gVar = new GVar(preLabel, new Var(new Id("t"))); // For the implicit thread variable.
            gVar.node = invNode;
//            vars.put(varCount, gVar);
            vars.add(gVar);
//            varCount++;

            invNode.retNode = retNode;
            retNode.invNode = invNode;
            Set<GNode> nesteds = new HashSet<GNode>();
            Set<GNode> directNesteds = new HashSet<GNode>();
            level++;
            for (int i = 0; i < def.statements.length; i++) {
               Statement statement = def.statements[i];
               Pair<Set<GNode>, Set<GNode>> res = visitDispatch(statement);
               Set<GNode> nodes = res._1();
               for (GNode node : nodes) {
                  node.parent = invNode;
               }
               directNesteds.addAll(nodes);
               nesteds.addAll(res._2());
            }
            level--;

            // To have the nesteds execute between inv and ret.
            // If we do not add these deps, nesteds can be
            // put out of inv and ret.
            // This is like the control dependency that we need
            // to add here as it did not exist when we were
            // computing deps above.

            execGraph.add(invNode);
            execGraph.add(retNode);
            for (GNode node : nesteds) {
               execGraph.add(invNode, node);
               execGraph.add(node, retNode);
               if (node instanceof MCallNode) {
                  MCallNode mCallNode = (MCallNode) node;
                  mCallNode.conds.add(gCond);
               }
            }
            nesteds.add(invNode);
            nesteds.add(retNode);
            invNode.nesteds = directNesteds;
            retNode.nesteds = directNesteds;
            retNode.returnNodes = returnNodes;
            if (returnNodes.isEmpty())
               throw new RuntimeException(
                     "Missing return statements in method " +
                     methodCall.name.name);
            returnNodes = new HashSet<ReturnNode>();

            // Add a dependency from all the previous nodes to the nodes
            // generated for this method call.
            // because a method call is like a full fence.
            // Note that we assume that in a thread program
            // if there is a this method call, it is all this method
            // calls and no object method call. This because, we
            // set the dependencies to each this method call from
            // nodes above it (not below it). So, we need the last call
            // to be a this method call.

            for (GNode prevNode : prevNodes)
               for (GNode node : nesteds)
                  execGraph.add(prevNode, node);
            preLabel = "";

            invNode.def = name2Defs.get(methodCall.name.name);

            // We need to restore the prevFence nodes.
            // We do not want to get dep from fences inside
            // the method to the invocation event.
            this.prevFenceNodes = prevFenceNodes;
            //Should this be the invNode or retNode?
//            this.prevFenceNodes.add(invNode);
            this.prevFenceNodes.add(retNode);
            setDeps();
            node2St.pop();
            st2Node.pop();
            Set<GNode> invAndret = new HashSet<GNode>();
            invAndret.add(invNode);
            invAndret.add(retNode);
            thisCalls.add(invNode);
            return new Pair<Set<GNode>, Set<GNode>>(invAndret, nesteds);
         }

         public Pair<Set<GNode>, Set<GNode>> visit(MethodCall methodCall) {
            String receiver = methodCall.obj.name;
            if (receiver.equals("this"))
               return visitThisMethodCall(methodCall);

            Set<GNode> prevNodes = new HashSet<GNode>(nodes);

            Set<GNode> set = new HashSet<GNode>();
            Set<GNode> sSet = new HashSet<GNode>();

            Set<BoolExp> conds = st2Conds.get(methodCall);
            GCond gCond = new GCond(preLabel, conds);
            String objName = methodCall.obj.name;
            Type type =  name2Type.get(objName);
            final MCallNode mCallNode = new MCallNode(methodCall, gCond, tId, level);
            mCallNode.preLabel = preLabel;
            set.add(mCallNode);
            sSet.add(mCallNode);
            xNodes.add(mCallNode);
            execGraph.add(mCallNode);

            if (type instanceof BasicRegister) {
               RetNode retNode = new RetNode(mCallNode, gCond, tId, level);
               mCallNode.setRetNode(retNode);
               retNode.preLabel = preLabel;
               xNodes.add(retNode);
               set.add(retNode);
               sSet.add(retNode);
               execGraph.add(retNode);
               execGraph.add(mCallNode, retNode);
            }
//            xNodes.put(xNodeCount, mCallNode);

//            xNodeCount++;

            // Add to vars if this method has a return value.
            methodCall.retv.apply(
               new Fun<Var, Object>() {
                  public Object apply(Var var) {
                     final GVar gVar = new GVar(preLabel, var);
                     gVar.node = mCallNode;
//                     vars.put(varCount, gVar);
                     vars.add(gVar);
//                     varCount++;
                     return null;
                  }
               }
            );

            if ((type instanceof Lock) || (type instanceof TryLock)) {
               String methodName = methodCall.name.name;
               if (methodName.equals("lock") || methodName.equals("tryLock")) {
                  prevFenceNodes.add(mCallNode);
               } else if (methodName.equals("unlock")) {
                  for (GNode prevNode : prevNodes)
                     execGraph.add(prevNode, mCallNode);
               }
            }

            return new Pair<Set<GNode>, Set<GNode>>(sSet, set);
         }

         public Pair<Set<GNode>, Set<GNode>> visit(FieldMethodCall methodCall) {
            Set<GNode> prevNodes = new HashSet<GNode>(nodes);

            Set<GNode> set = new HashSet<GNode>();
            Set<GNode> sSet = new HashSet<GNode>();

            Set<BoolExp> conds = st2Conds.get(methodCall);
            GCond gCond = new GCond(preLabel, conds);
            Type type = name2Type.get("struct." + methodCall.obj.name);
            final FMCallNode mCallNode = new FMCallNode(methodCall, gCond, tId, level);
            mCallNode.preLabel = preLabel;
//            xNodes.put(xNodeCount, mCallNode);
            set.add(mCallNode);
            sSet.add(mCallNode);
            xNodes.add(mCallNode);
            execGraph.add(mCallNode);
//            xNodeCount++;
            if (type instanceof BasicRegister) {
               RetNode retNode = new RetNode(mCallNode, gCond, tId, level);
               mCallNode.setRetNode(retNode);
               retNode.preLabel = preLabel;
               xNodes.add(retNode);
               set.add(retNode);
               sSet.add(retNode);
               execGraph.add(retNode);
               execGraph.add(mCallNode, retNode);
            }

            // Add to vars if this method has a return value.
            methodCall.retv.apply(
               new Fun<Var, Object>() {
                  public Object apply(Var var) {
                     final GVar gVar = new GVar(preLabel, var);
                     gVar.node = mCallNode;
//                     vars.put(varCount, gVar);
                     vars.add(gVar);
//                     varCount++;
                     return null;
                  }
               }
            );


            if ((type instanceof Lock) || (type instanceof TryLock)) {
               String methodName = methodCall.name.name;
               if (methodName.equals("lock") || methodName.equals("tryLock")) {
                  prevFenceNodes.add(mCallNode);
               } else if (methodName.equals("unlock")) {
                  for (GNode prevNode : prevNodes)
                     execGraph.add(prevNode, mCallNode);
               }
            }

            return new Pair<Set<GNode>, Set<GNode>>(sSet, set);
         }

         public Pair<Set<GNode>, Set<GNode>> visit(Return theReturn) {
            Set<GNode> prevNodes = new HashSet<GNode>(nodes);
            Set<BoolExp> conds = st2Conds.get(theReturn);
            GCond gCond = new GCond(preLabel, conds);
            ReturnNode returnNode = new ReturnNode(theReturn, gCond, tId, level);
            xNodes.add(returnNode);
//            xNodes.put(xNodeCount, returnNode);
//            xNodeCount++;
            returnNodes.add(returnNode);
            execGraph.add(returnNode);

            // So that method calls do not jump down past the return nodes.
            for (GNode prevNode : prevNodes)
               execGraph.add(prevNode, returnNode);

            // So that method calls do not jump up past the return nodes.
            // The transitivity keeps the method calls before the return
            // before the method calls after the return.
            prevFenceNodes.add(returnNode);

            Set<GNode> set = new HashSet<GNode>();
            set.add(returnNode);
            Set<GNode> sSet = new HashSet<GNode>();
            sSet.add(returnNode);
            return new Pair<Set<GNode>, Set<GNode>>(sSet, set);
         }

         public Pair<Set<GNode>, Set<GNode>> visit(final If theIf) {
            final Set<GNode> allNodes = new HashSet<GNode>();

            final IfNode ifNode = new IfNode(theIf, tId, level);
            final ElseNode elseNode = new ElseNode(ifNode, tId, level);

            allNodes.add(ifNode);
            level++;
            final Statement[] thenStatements = theIf.thenStatements;
            Set<GNode> ifNestedNodes = new HashSet<GNode>();
            for (Statement thenStatement : thenStatements) {
               Pair<Set<GNode>, Set<GNode>> res = visitDispatch(thenStatement);
               Set<GNode> nodes = res._1();
               for (GNode node : nodes) {
                  ifNestedNodes.add(node);
                  node.parent = ifNode;
                  //ifNode.addDepended(node);
                  //stGraph.add(ifNode, node);
                  execGraph.add(ifNode, node);
                  if (theIf.elseStatements.isPresent())
                     //node.addDepended(elseNode);
                     execGraph.add(node, elseNode);
               }
               allNodes.addAll(res._2());
            }
            ifNode.nesteds = ifNestedNodes;
            level--;

            theIf.elseStatements.apply(
               new Fun<Statement[], None>() {
                  public None apply(Statement[] elseStatements) {
                     allNodes.add(elseNode);
                     //ifNode.addDepended(elseNode);
                     ifNode.elseNode = new Some<ElseNode>(elseNode);
                     execGraph.add(ifNode, elseNode);
                     level++;
                     Set<GNode> elseNestedNodes = new HashSet<GNode>();
                     for (int i = 0; i < elseStatements.length; i++) {
                        Statement elseStatement = elseStatements[i];
                        Pair<Set<GNode>, Set<GNode>> res = visitDispatch(elseStatement);
                        Set<GNode> nodes = res._1();
                        for (GNode node : nodes) {
                           node.parent = elseNode;
//                           System.out.println(node);
                           execGraph.add(elseNode, node);
                           elseNestedNodes.add(node);
                        }
                        allNodes.addAll(res._2());
                        //elseNode.addDepended(node);
                     }
                     elseNode.nesteds = elseNestedNodes;
                     level--;
                     return None.instance();
                  }
               }
            );
            execGraph.add(ifNode);
            Set<GNode> sSet = new HashSet<GNode>();
            sSet.add(ifNode);
            if (theIf.elseStatements.isPresent())
               sSet.add(elseNode);
            return new Pair<Set<GNode>, Set<GNode>>(sSet, allNodes);
         }

         public Pair<Set<GNode>, Set<GNode>> visit(While aWhile) {
            return null;
         }

         public Pair<Set<GNode>, Set<GNode>> visit(New theNew) {
            Set<BoolExp> conds = st2Conds.get(theNew);
            GCond gCond = new GCond(preLabel, conds);
            NewNode newNode = new NewNode(preLabel, theNew, gCond, tId, level);
            xNodes.add(newNode);
            newNodes.add(newNode);
            final GVar gVar = new GVar(preLabel, theNew.left);
            gVar.node = newNode;
//            vars.put(varCount, gVar);
            vars.add(gVar);
//            varCount++;

            Set<GNode> set1 = new HashSet<GNode>();
            set1.add(newNode);
            Set<GNode> set2 = new HashSet<GNode>();
            set2.add(newNode);

            return new Pair<Set<GNode>, Set<GNode>>(set1, set2);
         }

         public Pair<Set<GNode>, Set<GNode>> visit(Plus plus) {
            Set<BoolExp> conds = st2Conds.get(plus);
            GCond gCond = new GCond(preLabel, conds);
            PlusNode node = new PlusNode(preLabel, plus, gCond, tId, level);
            xNodes.add(node);
            mathOpNodes.add(node);
            Set<GNode> set1 = new HashSet<GNode>();
            set1.add(node);
            Set<GNode> set2 = new HashSet<GNode>();
            set2.add(node);
            final GVar gVar = new GVar(preLabel, plus.left);
            gVar.node = node;
//            vars.put(varCount, gVar);
            vars.add(gVar);
//            varCount++;
            return new Pair<Set<GNode>, Set<GNode>>(set1, set2);
         }

         public Pair<Set<GNode>, Set<GNode>> visit(Minus minus) {
            Set<BoolExp> conds = st2Conds.get(minus);
            GCond gCond = new GCond(preLabel, conds);
            MinusNode node = new MinusNode(preLabel, minus, gCond, tId, level);
            xNodes.add(node);
            mathOpNodes.add(node);
            Set<GNode> set1 = new HashSet<GNode>();
            set1.add(node);
            Set<GNode> set2 = new HashSet<GNode>();
            set2.add(node);
            final GVar gVar = new GVar(preLabel, minus.left);
            gVar.node = node;
//            vars.put(varCount, gVar);
            vars.add(gVar);
//            varCount++;
            return new Pair<Set<GNode>, Set<GNode>>(set1, set2);
         }

         // To add the dependencies computed for the
         // statements to the graph nodes.
         public void setDeps() {
            for (GNode node1 : node2St.peek().keySet()) {
               if (node1 instanceof ElseNode)
                  continue;
               // We skip else nodes because we do not want
               // the else node to get dependent on
               // the nodes of the then statements.

//               System.out.println(st1);
               Statement st1 = node2St.peek().get(node1);
               Set<Statement> sts = deps.adjacentsOf(st1);
               for (Statement st2 : sts) {
                  Set<GNode> nodes2 = st2Node.peek().get(st2);
                  if (nodes2 == null) {
                     System.out.println(st1);
                     System.out.println(st2);
                     throw new RuntimeException();
                  } else
                     for (GNode node2 : nodes2)
                        execGraph.add(node1, node2);
               }
            }
         }
      }
      StVisitor graphBuilder = new StVisitor();

      MCallNode superParent;
      superParent = new MCallNode(null, null, 0, 0);

      int lastTId = specification.main.blocks.length + 1;
      threadNodes = (Set<GNode>[]) Array.newInstance(Set.class, lastTId + 1);
      for (int i = 0; i < threadNodes.length; i++)
         threadNodes[i] = new HashSet<GNode>();

      Statement[][] blocks = specification.main.blocks;
      graphBuilder.tId = 0;
      for (Statement[] block : blocks) {
//         superParent = new MCallNode(null, null, 0, 0);
         graphBuilder.reset();
         graphBuilder.tId++;
         for (Statement statement : block) {
            Pair<Set<GNode>, Set<GNode>> pair = graphBuilder.visitDispatch(statement);
            for (GNode node : pair._1())
               node.parent = superParent;
            final Set<GNode> gNodes = pair._2();
            threadNodes[graphBuilder.tId].addAll(gNodes);
//            for (GNode firstNode : firstNodes)
//               execGraph.add(firstNode, node);
//            for (GNode lastNode : lastNodes)
//               execGraph.add(node, lastNode);
         }
         graphBuilder.setDeps();
      }

//      superParent = new MCallNode(null, null, 0, 0);
      final Def thisDef = name2Defs.get("this");
      if (thisDef != null) {
         Statement[] thisSts = thisDef.statements;
         graphBuilder.reset();
         graphBuilder.tId = 0;
         for (Statement statement : thisSts) {
            Pair<Set<GNode>, Set<GNode>> pair = graphBuilder.visitDispatch(statement);
            for (GNode node : pair._1())
               node.parent = superParent;
            threadNodes[0].addAll(pair._2());
         }
         graphBuilder.setDeps();
      }
      //Set<GNode> firstNodes = graphBuilder.nodes;

//      superParent = new MCallNode(null, null, 0, 0);

      graphBuilder.tId = lastTId;
      final Def deThisDef = name2Defs.get("~this");
      if (deThisDef != null) {
         Statement[] thisSts = deThisDef.statements;
         graphBuilder.reset();
         for (Statement statement : thisSts) {
            Pair<Set<GNode>, Set<GNode>> pair = graphBuilder.visitDispatch(statement);
            for (GNode node : pair._1())
               node.parent = superParent;
            threadNodes[lastTId].addAll(pair._2());
         }
         graphBuilder.setDeps();
      }
      //Set<GNode> lastNodes = graphBuilder.nodes;

      MethodCall lastMethodCall = new MethodCall(
         new Some<Label>(new Label(new Id("LAST"))),
         new Id("lastObj"),
         new Id("read"),
         new Varl[]{}, None.instance()
      );
      lastMethodCall.index = None.instance();
      Pair<Set<GNode>, Set<GNode>> pair = graphBuilder.visitDispatch(lastMethodCall);
      MCallNode last = (MCallNode) pair._1().iterator().next();
      last.conds = new HashSet<GCond>();
      last.parent = superParent;
      // That this statements are before all others
      // That ~this statements are after all others
      // The Last is after all of them.

      for (GNode node1 : execGraph.nodes()) {
         for (GNode node2 : execGraph.nodes()) {
            if ((node1.tId == 0) && (node2.tId != 0))
               execGraph.add(node1, node2);
            if ((node1.tId != lastTId) && (node2.tId == lastTId))
               execGraph.add(node1, node2);
         }
         if (node1 != last)
            execGraph.add(node1, last);
      }
   }

   // --------------------------------------------------------------------------------

   private Text genPrelude() {
      return new Snippet(
         "; --------------------------------------------------------------\n" +
         "; Settings\n" +
         ";(set-option :mbqi true)\n" +
         "(set-option :macro-finder true)\n" +
         "(set-option :pull-nested-quantifiers true)\n" +
         ";(set-option :produce-unsat-cores true)\n" +
         "; --------------------------------------------------------------\n" +
         "\n"
      );
   }

   private Text genBaseObjects() {
      final TextSeq seq = textFact.newText();
      seq.put(
         "(declare-datatypes () (\n" +
         "   (Obj\n"
      );

      final Fun<Pair<Decl, String>, String> paramGen = new Fun<Pair<Decl, String>, String>() {
         public String apply(Pair<Decl, String> pair) {
            Decl decl =  pair._1();
            String name = pair._2();
            if (!decl.type.isArray() && !decl.type.isTLocal)
               return "      (" + name + ")\n";
            else if (decl.type.isArray() && !decl.type.isTLocal)
               return "      (" + name + " (index Int))\n";
            else if (!decl.type.isArray() && decl.type.isTLocal)
               return "      (" + name + " (tId Int))\n";
            else // if (decl.type.isArray() && decl.type.isTLocal)
               return "      (" + name + " (tId Int)(index Int))\n";
         }
      };
      Decl[] decls = specification.decls;
      for (Decl decl : decls)
         seq.put(paramGen.apply(new Pair<Decl, String>(decl, decl.id.name)));

      specification.structOption.apply(
         new Fun<Struct, Object>() {
            public Object apply(Struct struct) {
               // String name = struct.name.name;
               for (Decl decl : struct.decls)
                  seq.put(paramGen.apply(new Pair<Decl, String>(decl, "mem_" + decl.id.name + " (loc Int)")));
               return null;
            }
         }
      );

      seq.put(
         "      lastObj\n" +
         "      thisEvObj\n" +
         "      returnObj\n" +
         "      noObj\n" +
         "   )\n" +
         "))\n"
      );

      seq.put("\n");

      Set<String> names = new HashSet<String>();
      names.add("read");
      names.add("write");
      names.add("cas");
      names.add("mlock");
      names.add("mtryLock");
      names.add("unlock");
      for (Def def : specification.defs)
         names.add(def.name.name);
      seq.put(
         "(declare-datatypes () (\n" +
//         ";   (Type\n" +
//         ";      AtomicReg\n" +
//         ";   )\n" +
         "   (Name\n");
      for (String name : names)
         seq.put("      " + name + "\n");
      seq.put(
            "   )\n" +
            "))\n"
      );
      seq.put(
            "\n");

      return seq.get();
   }

   private Text genLabels() {
      TextSeq seq = textFact.newText();
      seq.put(
         "(declare-datatypes () (\n" +
         "   (Label\n");
      seq.put(
         "      ");

      for (XNode box : xNodes) {
         seq.put(box.getFlatLabel() + " ");
      }

      seq.put(
         "\n");
      seq.put(
         "   )\n" +
         "))\n");
      seq.put(
         "\n");

      return seq.get();
   }

   private Text genVars() {
      TextSeq seq = textFact.newText();
      seq.put(
         "(declare-datatypes () (\n" +
         "   (Var\n");
      seq.put("      ");
      for (GVar var : vars)
         seq.put(var.getFlatName() + " ");

      if (vars.isEmpty()) {
         seq.put("dummyVar");
      }

      seq.put(
         "\n" +
         "   )\n" +
         "))\n");
      seq.put(
         "\n");

      return seq.get();
   }

   private Text genPredefs() {
      return new Snippet(
         "(declare-datatypes () (\n"+
         "   (Varl\n"+
         "      (var (unvar Var))\n"+
         "      (val (unval Int))\n"+
         "   )\n"+
         "))\n"+
         "\n"+
         "(declare-fun valOf (Var) Int)\n"+
         "\n"+
         "(declare-fun obj (Label) Obj)\n"+
         "(declare-fun method (Label) Name)\n"+
         "(declare-fun arg1 (Label) Varl)\n"+
         "(declare-fun arg2 (Label) Varl)\n"+
         "(declare-fun retv (Label) Var)\n"+
         "(declare-fun retEv (Label) Label)\n"+
         "\n"+
         "(define-fun valOfVarl ((v Varl)) Int\n"+
         "   (ite\n" +
         "      (is-var v)\n" +
         "      (valOf (unvar v))\n" +
         "      (unval v)\n" +
         "   )\n" +
         ")\n" +
         "(define-fun validEq ((v1 Varl)(v2 Varl)) Bool\n"+
         "   (= (valOfVarl v1) (valOfVarl v2))\n"+
//         "   (and\n"+
//         "      (=>\n"+
//         "         (is-var v2)\n"+
//         "         (= (valOf v1) (valOf (unvar v2)))\n"+
//         "      )\n"+
//         "      (=>\n"+
//         "         (is-val v2)\n"+
//         "         (=\n"+
//         "            (valOf v1) \n"+
//         "            (unval v2)\n"+
//         "         )\n"+
//         "      )\n"+
//         "   )\n"+
         ")\n"+
         "\n"+
         "\n"+
           //If we consider complete histories, then this can be iff
         "(declare-fun exec (Label) Bool)\n"+
//         "(declare-fun cond (Bool Label) Bool)\n"+
//         "(assert\n"+
//         "   (forall ((c Bool) (l Label))\n"+
//         "      (=>\n"+
//         "         (cond c l)\n"+
//         "         (iff\n"+
//         "            (exec l)\n"+
//         "            c\n"+
//         "         )\n"+
//         "      )\n"+
//         "   )\n"+
//         ")\n"+
//         "\n"+
         "(declare-fun /prec_p (Label Label) Bool)\n" +
//         "(declare-fun /prec_pp (Label Label) Bool)\n" +
         "(declare-fun /prec_X (Label Label) Bool)\n"+
//         "(assert\n"+
//         "   (forall ((l1 Label) (l2 Label) (l3 Label))\n"+
//         "      (=>\n"+
//         "         (and\n"+
//         "            (/prec_p l1 l2)\n"+
//         "            (/prec_p l2 l3)\n"+
//         "         )\n"+
//         "         (/prec_p l1 l3)\n"+
//         "      )\n"+
//         "   )\n"+
//         ")\n" +
            "(assert (exec LAST))\n"
      );
   }

   private Text genP() {

      final TextSeq seq = textFact.newText();
      seq.put("; ----------------------------------------------------------------\n");

      for (final XNode xNode : xNodes) {
//         if (!(xNode instanceof MathOpNode) && !(xNode instanceof NewNode))
         seq.put(
            "(assert\n" +
            "   (and\n"
         );
         if (xNode instanceof GMCallNode) {
            final GMCallNode gmCallNode = (GMCallNode) xNode;
            final String label = gmCallNode.getFlatLabel();
            final GMethodCall methodCall = gmCallNode.getGMethodCall();

            final String name = methodCall.obj.name;
            final String objName;
            if (xNode instanceof MCallNode)
               objName = name;
            else {
               final Var loc = ((FieldMethodCall) methodCall).ref;
               GVar gVar = new GVar(gmCallNode.preLabel, loc);
               objName = "mem_" + name + " (valOf " + gVar.getFlatName() + ")";
            }

            final Type type;
            if (xNode instanceof MCallNode)
               type = name2Type.get(name);
            else
               type = name2Type.get("struct." + name);
            if (type == null)
               throw new RuntimeException(
                     "Method call on undeclared object " + name +
                     " at " + methodCall.getLoc() + ".");
            //final String tId = mCallNode.preLabel + ".t";
            final int tId = gmCallNode.tId;

            String s = methodCall.index.apply(
               new Fun0<String>() {
                  public String apply() {
                     if (!type.isTLocal)
                        return objName;
                     else
//                        return name + " (valOf " + tId + ")";
                        return objName + " " + tId;
                  }
               },
               new Fun<Varl, String>() {
                  public String apply(Varl indexVarl) {
                     class Visitor implements SVisitor.VarlVisitor<String> {
                        public int i;

                        public String visit(Var var) {
                           GVar gVar = new GVar(gmCallNode.preLabel, var);
                           return "(valOf " + gVar.getFlatName() + ")";
                        }

                        public String visit(Val val) {
                           return val.intLiteral.lexeme;
                        }
                     }
                     Visitor varlVisitor = new Visitor();
                     String index = indexVarl.accept(varlVisitor);
                     if (!type.isTLocal)
                        return objName + " " + index;
                     else
                        return objName + " " + tId + " " + index;
                  }
               }
            );
            if (!s.equals(methodCall.obj.name))
               s = "(" + s + ")";
            seq.put(
               "      (= (obj " + label + ") " + s + ")\n"
            );

            String methodName = methodCall.name.name;
            if (methodName.equals("lock"))
               methodName = "m" + methodName;
            if (methodName.equals("tryLock"))
               methodName = "m" + methodName;
            seq.put(
               "      (= (method " + label + ") " + methodName + ")\n"
            );
            if (methodCall.args.length >= 1) {
               class Visitor implements SVisitor.VarlVisitor<None> {
                  public int i;

                  public None visit(Var var) {
                     GVar gVar = new GVar(gmCallNode.preLabel, var);
                     seq.put(
                        "      (= (arg" + i + " " + label + ") (var " + gVar.getFlatName() + "))\n"
                     );
                     return None.instance();
                  }

                  public None visit(Val val) {
                     seq.put(
                        "      (= (arg" + i + " " + label + ") (val " + val.intLiteral.lexeme + "))" +
                              "\n"
                     );
                     return None.instance();
                  }
               }
               Visitor varlVisitor = new Visitor();
               for (int i = 0; i < methodCall.args.length; i++) {
                  Varl varl = methodCall.args[i];
                  varlVisitor.i = i+1;
                  varl.accept(varlVisitor);
               }
            }
            gmCallNode.getFlatVarName().apply(
               new Fun<String, None>() {
                  public None apply(String flatVarName) {
                     seq.put(
                        "      (= (retv " + label + ") " + flatVarName + ")\n"
                     );
                     return None.instance();
                  }
               }
            );

            gmCallNode.retNodeOption.apply(
               new Fun<RetNode, Object>() {
                  public Object apply(RetNode retNode) {
                     String retLabel = retNode.getFlatLabel();
                     seq.put(
                        "      (= (retEv " + label + ") " + retLabel + ")\n"
                     );
                     return None.instance();
                  }
               }
            );

         } else if (xNode instanceof RetNode) {
            // This is the return node of a method call on a basic object.
            final RetNode retNode = (RetNode) xNode;
            final String retLabel = retNode.getFlatLabel();
            seq.put(
               "      (= (obj " + retLabel + ") " + "noObj" + ")\n"
            );
            GMCallNode callNode = retNode.gmCallNode;
            String invLabel = callNode.getFlatLabel();

            // Method calls in a thread are sequential
            for (GNode node : threadNodes[retNode.tId]) {
               if (node != callNode && node != retNode && !(node instanceof IfNode)) {
                  String nLabel = node.getFlatLabel();
                  seq.put(
                     "      (or\n" +
                     "         (/prec_X " + nLabel + " " + invLabel + ")\n" +
                     "         (/prec_X " + retLabel + " " + nLabel + ")\n" +
                     "      )\n"
                  );
               }
            }

         } else if (xNode instanceof ReturnNode) {
            final ReturnNode returnNode = (ReturnNode) xNode;
            final String label = returnNode.getFlatLabel();
            final Return theReturn = returnNode.theReturn;
            seq.put(
               "      (= (obj " + label + ") " + "returnObj" + ")\n"
            );
            seq.put(
               "      (= (method " + label + ") " + "read" + ")\n"
            );
            final SVisitor.VarlVisitor<None> varlVisitor = new SVisitor.VarlVisitor<None>() {
               public None visit(Var var) {
                  GVar gVar = new GVar(returnNode.preLabel, var);
                  seq.put(
                     "      (= (arg1 " + label + ") (var " + gVar.getFlatName() + "))\n"
                  );
                  return None.instance();
               }

               public None visit(Val val) {
                  seq.put(
                     "      (= (arg1 " + label + ") (val " + val.intLiteral.lexeme + "))" +
                           "\n"
                  );
                  return None.instance();
               }
            };
            theReturn.varl.apply(
               new Fun<Varl, None>() {
                  public None apply(Varl varl) {
                     varl.accept(varlVisitor);
                     return None.instance();
                  }
               }
            );
         } else if (xNode instanceof ThisCallInvNode) {
            ThisCallInvNode invNode = (ThisCallInvNode) xNode;
            final MethodCall methodCall = invNode.methodCall;

            final String label = invNode.getFlatLabel();
            seq.put(
               "      (= (obj " + label + ") " + "thisEvObj" + ")\n"
            );
            seq.put(
               "      (= (method " + label + ") " + methodCall.name.name + ")\n"
            );
            if (methodCall.args.length >= 1) {
               class Visitor implements SVisitor.VarlVisitor<None> {
                  int i;
                  public None visit(Var var) {
                     seq.put(
                        "      (= (arg" + i + " " + label + ") (var " + var.id.name + "))\n"
                     );
                     return None.instance();
                  }

                  public None visit(Val val) {
                     seq.put(
                        "      (= (arg" + i + " " + label + ") (val " + val.intLiteral.lexeme + "))" +
                        "\n"
                     );
                     return None.instance();
                  }
               }
               Visitor visitor = new Visitor();

               for (int i = 0; i < methodCall.args.length; i++) {
                  Varl varl = methodCall.args[i];
                  visitor.i = i + 1;
                  varl.accept(visitor);
               }

            }

         } else if (xNode instanceof ThisCallRetNode) {
            ThisCallRetNode retNode = (ThisCallRetNode) xNode;
            final MethodCall methodCall = retNode.methodCall;

            final String label = retNode.getFlatLabel();
            seq.put(
               "      (= (obj " + label + ") " + "thisEvObj" + ")\n"
            );
            seq.put(
               "      (= (method " + label + ") " + methodCall.name.name + ")\n"
            );
            retNode.getFlatVarName().apply(
                  new Fun<String, None>() {
                     public None apply(String flatVarName) {
                        seq.put(
                              "      (= (retv " + label + ") " + flatVarName + ")\n"
                        );
                        return None.instance();
                     }
                  }
            );
         } else { // if ((xNode instanceof MathOpNode) || (xNode instanceof NewNode))
            final String label = xNode.getFlatLabel();
            seq.put(
               "      (= (obj " + label + ") " + "noObj" + ")\n"
            );
         }
//         if (!(xNode instanceof MathOpNode) && !(xNode instanceof NewNode))
         seq.put(
            "   )\n" +
            ")\n" +
            "\n"
         );
      }

      for (XNode xNode : xNodes) {
         class ExpVisitor implements SVisitor.BoolExpVisitor<Text> {
            public String preLabel = "";
            public Text visit(Op op) {
               OpVisitor<String> z3OpNamer = new OpVisitor<String>() {
                  public String visit(LogicalOp logicalOp) {
                     LogicalOpVisitor<String> visitor = new LogicalOpVisitor<String>() {
                        public String visit(And and) {
                           return "and";
                        }

                        public String visit(Or or) {
                           return "or";
                        }

                        public String visit(Not not) {
                           return "not";
                        }
                     };
                     return logicalOp.accept(visitor);
                  }

                  public String visit(RelationalOp relationalOp) {
                     final String lexeme = relationalOp.getLexeme();
                     return (lexeme.equals("==")? "=" : lexeme);
                  }
               };
               final TextSeq seq = textFact.newText();
               seq.put("(");

               seq.put(op.accept(z3OpNamer) + " ");
               for (int i = 0; i < op.getOperands().length; i++) {
                  BoolExp arg = op.getOperands()[i];
                  seq.put(arg.accept(this));
                  if (i != op.getOperands().length - 1)
                     seq.put(" ");
               }
               seq.put(")");
               return seq.get();
            }

            public Text visit(Varl varl) {
               SVisitor.VarlVisitor<String> varlVisitor = new SVisitor.VarlVisitor<String>() {
                  public String visit(Var var) {
                     String flatName = new GVar(preLabel, var).getFlatName();
                     return "(valOf " + flatName + ")";
                  }

                  public String visit(Val val) {
                     return val.intLiteral.lexeme;
                  }
               };

               return new Snippet(varl.accept(varlVisitor));
            }
         }
         ExpVisitor expVisitor = new ExpVisitor();

         final String label = xNode.getFlatLabel();
         Set<GCond> gConds = xNode.conds;
         boolean empty = true;
         for (GCond gCond : gConds) {
            if (gCond != null &&
                gCond.conds != null &&
                !gCond.conds.isEmpty()) {
               empty = false;
               break;
            }
         }
         final Set<ReturnNode> precReturns = xNode.precReturns;
         if (precReturns.size() != 0)
            empty = false;

         seq.put(
            "(assert\n");
         if (empty) {
            seq.put(
               "   (exec " + label + ")\n"
            );
         } else {
            seq.put(
               "   (iff\n"
            );
            seq.put(
               "      (exec " + label + ")\n"
            );
            seq.put("      (and\n");
            for (GCond gCond : gConds) {
               expVisitor.preLabel = gCond.preLabel;
               for (BoolExp boolExp : gCond.conds) {
                  seq.put(
                     "         "
                  );
                  seq.put(boolExp.accept(expVisitor));
                  //"(eq (var x_1) (val 0))"
                  seq.put("\n");
               }
            }

            // To prevent statements after the return from execution.

            for (ReturnNode precReturn : precReturns) {
               seq.put(
                  "         "
               );
               seq.add(
                  "(not (exec " + precReturn.getFlatLabel() + "))"
               );
               seq.put("\n");
            }

            seq.put("      )\n");

            seq.put(
               "   )\n"
            );
         }
         seq.put(
            ")\n");
         seq.put("\n");

      }

      for (MathOpNode mathOpNode : mathOpNodes) {
         final String preLabel = mathOpNode.preLabel;
         SVisitor.VarlVisitor<String> varlVisitor = new SVisitor.VarlVisitor<String>() {
            public String visit(Var var) {
               String flatName = new GVar(preLabel, var).getFlatName();
               return "(valOf " + flatName + ")";
            }

            public String visit(Val val) {
               return val.intLiteral.lexeme;
            }
         };
         seq.put("(assert\n");
         seq.put("   (=>\n");
         seq.put("      (exec " + mathOpNode.getFlatLabel() + ")\n");
         seq.put("      (=\n");
         seq.put("         " + mathOpNode.mathOp.left.accept(varlVisitor) + "\n");
         seq.put("         (" + mathOpNode.mathOp.getOperator() + "\n");
         seq.put("            " + mathOpNode.mathOp.operand1.accept(varlVisitor) + "\n");
         seq.put("            " + mathOpNode.mathOp.operand2.accept(varlVisitor) + "\n");
         seq.put("         )\n");
         seq.put("      )\n");
         seq.put("   )\n");
         seq.put(")\n");
      }

      int index = 0;
      for (NewNode newNode : newNodes) {
         final String preLabel = newNode.preLabel;
         String flatName = new GVar(preLabel, newNode.theNew.left).getFlatName();

         seq.put("(assert\n");
         seq.put("   (=>\n");
         seq.put("      (exec " + newNode.getFlatLabel() + ")\n");
         seq.put("      (=\n");
         seq.put("         (valOf " + flatName + ")\n");
         seq.put("         " + index + "\n");
         seq.put("      )\n");
         seq.put("   )\n");
         seq.put(")\n");

         index += 1;
      }

      // Print /prec_p order
      seq.add(
         "(assert\n" +
         "   (and\n"
      );

//      for (XNode xNode1 : xNodes.values()) {
////         System.out.println(mCallNode.getFlatLabel() + " " + mCallNode.tId);
//         if (xNode1.tId == 0)
//            for (XNode xNode2 : xNodes.values()) {
//               if (xNode2.tId != 0) {
//                  final String label1 = xNode1.getFlatLabel();
//                  final String label2 = xNode2.getFlatLabel();
//                  seq.put("      ");
//                  seq.put("(/prec_p " + label1 + " " + label2 + ")");
//                  seq.put("\n");
//               }
//            }
//      }
      for (XNode xNode1 : xNodes) {
         Set<GNode> forwardNodes = execGraph.adjacentsOf(xNode1);
         for (GNode forwardNode : forwardNodes) {
            if (forwardNode instanceof XNode) {
               XNode xNode2 = (XNode) forwardNode;

               // The following check prevents precedence of
               // statements in the if statement to the statements
               // after the if statement in \prec_p. Failing to
               // exclude them can result in the introduction of
               // exec of the statements in the if from the exec
               // of the statements after it which is not true.
               // The PP2X rule requires that the first label be
               // exec as well.

//               String label1 = xNode1.getFlatLabel();
//               Set<BoolExp> conds1 = xNode1.conds;
//               String label2 = mCallNode2.getFlatLabel();
//               Set<BoolExp> conds2 = mCallNode2.conds;
//               Set<BoolExp> intersection = new HashSet<BoolExp>(conds1);
//               intersection.retainAll(conds2);
//               seq.put("      ");
//               if (xNode1.level <= mCallNode2.level &&
//                        (xNode1.level == 0) || !intersection.isEmpty())

               String label1 = xNode1.getFlatLabel();
               String label2 = xNode2.getFlatLabel();


               // If the parent of the first one is the (super)parent
               // of the second one, then it is the normal precedence
               // otherwise _pp kind.
//               boolean isPOrd = false;
//               GNode parent1 = xNode1.parent;
//               GNode current = xNode2;
//               while (current != null && current.parent != null) {
//                  current = current.parent;
//                  if (current == parent1) {
//                     isPOrd = true;
//                     break;
//                  }
//               }

               seq.put("      ");
//               if (isPOrd)
//                  seq.put("(/prec_p " + label1 + " " + label2 + ")");
//               else
//                  seq.put("(/prec_pp " + label1 + " " + label2 + ")");
               seq.put("(/prec_p " + label1 + " " + label2 + ")");
               seq.put("\n");
            }
         }
      }

      seq.add(
         "   )\n" +
         ")\n"
      );
      seq.put("; ----------------------------------------------------------------\n");


      return seq.get();
   }

   private Text genThisCallRules() {
      final TextSeq seq = textFact.newText();
      seq.put("; ----------------------------------------------------------------\n");
      class Visitor implements SVisitor.VarlVisitor<String> {
         public String preLabel = "";
         public String visit(Var var) {
            String name = (preLabel.equals("")) ? var.id.name : (preLabel + "." + var.id.name);
            return "(valOf " + name + ")";
         }

         public String visit(Val val) {
            return val.intLiteral.lexeme;
         }
      }
      final Visitor visitor = new Visitor();

      for (ThisCallInvNode invNode : thisCalls) {
         ThisCallRetNode retNode = invNode.retNode;
         final MethodCall methodCall = invNode.methodCall;
         String methodName = methodCall.name.name;
         Def def = name2Defs.get(methodName);
         final String methodLabel = invNode.getMethodCallLabel();
         final String retLabel = retNode.getLabel();
         Varl[] args = methodCall.args;
         Var[] params = def.inParams;
         Set<ReturnNode> returnNodes = retNode.returnNodes;

         seq.println("(assert");
         seq.println("   (and");
         seq.println("      (= " + "(valOf " + methodLabel + ".t" + ") " + invNode.tId + ")");
         for (int i = 0; i < args.length; i++) {
            Varl arg = args[i];
            Var param = params[i];
            final String paramName = param.id.name;
            String argValue = arg.accept(visitor);
            seq.println("      (= " + "(valOf " + methodLabel + "." + paramName + ") " + argValue + ")");
         }
         seq.println("   )");
         seq.println(")");

         seq.println("(assert");
         seq.println("   (iff");
         seq.println("      (exec " + retLabel + ")");
         seq.println("         (or");
         for (final ReturnNode returnNode1 : returnNodes) {
            seq.println("         (and");
            seq.println("            (exec " + returnNode1.getFlatLabel() + ")");
            returnNode1.theReturn.varl.apply(
               new Fun<Varl, None>() {
                  public None apply(Varl varl) {
                     visitor.preLabel = returnNode1.preLabel;
                     final String retArg = varl.accept(visitor);
                     visitor.preLabel = "";
                     methodCall.retv.apply(
                        new Fun<Var, None>() {
                           public None apply(Var var) {
                              visitor.preLabel = "";
                              String retV = var.accept(visitor);
                              visitor.preLabel = "";
                              seq.println("            (= " + retArg + " " + retV + ")");
                              return None.instance();
                           }
                        }
                     );
                     return None.instance();
                  }
               }
            );

            for (ReturnNode returnNode2 : returnNodes) {
               if (returnNode1 != returnNode2)
                  seq.println("            (not (exec " + returnNode2.getFlatLabel() + "))");
            }
            seq.println("            )");
         }
         seq.println("      )");
         seq.println("   )");
         seq.println(")");
         seq.println();

         seq.println("(assert");
         seq.println("   (iff");
         seq.println("      (exec " + invNode.getFlatLabel() + ")");
         seq.println("      (exec " + retNode.getFlatLabel() + ")");
         seq.println("   )");
         seq.println(")");
         seq.println();
      }
      seq.put("; ----------------------------------------------------------------\n");
      return seq.get();
   }

   private Text genPrecX() {
      return new Snippet(
         "; --------------------------------------------------------------\n"+
         "; /prec_X\n"+
         "\n"+
//         "; P2X\n"+
//         "(assert\n"+
//         "   (forall ((l1 Label) (l2 Label))\n"+
//         "      (=> \n"+
//         "         (and\n"+
//         "            (/prec_p l1 l2)\n"+
//         "            (exec l2)\n"+
//         "         )\n"+
//         "         (and\n"+
//         "            (/prec_X l1 l2)\n"+
//         "            (exec l1)\n"+
//         "         )\n"+
//         "      )\n"+
//         "   )\n"+
//         ")\n"+
//         "(assert\n"+
//         "   (forall ((l1 Label) (l2 Label))\n"+
//         "      (=> \n"+
//         "         (and\n"+
//         "            (/prec_p l1 l2)\n"+
//         "            (not (exec l2))\n"+
//         "         )\n"+
//         "         (not (exec l1))\n"+
//         "      )\n"+
//         "   )\n"+
//         ")\n"+
         "; P2X\n"+
         "(assert\n"+
         "   (forall ((l1 Label) (l2 Label))\n"+
         "      (=> \n"+
         "         (and\n"+
         "            (/prec_p l1 l2)\n"+
         "            (exec l1)\n"+
         "            (exec l2)\n"+
         "         )\n"+
         "         (/prec_X l1 l2)\n"+
         "      )\n"+
         "   )\n"+
         ")\n"+
         "\n"+
         "; Total\n"+
         "(assert\n"+
         "   (forall ((l_1 Label) (l_2 Label))\n"+
         "      (=>\n"+
         "         (and\n"+
         "            (not (= l_1 l_2))\n"+
         "            (exec l_1)\n"+
         "            (exec l_2)\n"+
         "         )\n"+
         "         (or \n"+
         "            (/prec_X l_1 l_2)\n"+
         "            (/prec_X l_2 l_1)\n"+
         "         )\n"+
         "      )\n"+
         "   )\n"+
         ")\n"+
         "\n" +
         "; Transitive\n"+
         "(assert\n"+
         "   (forall ((l1 Label) (l2 Label) (l3 Label))\n"+
         "      (=>\n"+
         "         (and\n"+
         "            (/prec_X l1 l2)\n"+
         "            (/prec_X l2 l3)\n"+
         "         )\n"+
         "         (/prec_X l1 l3)\n"+
         "      )\n"+
         "   )\n"+
         ")\n"+
         "\n"+
         "; Asymmetric\n"+
         "(assert\n"+
         "   (forall ((l1 Label) (l2 Label))\n"+
         "      (not\n"+
         "         (and \n"+
         "            (/prec_X l1 l2)\n"+
         "            (/prec_X l2 l1)\n"+
         "         )\n"+
         "      )\n"+
         "   )\n"+
         ")\n" +
         "\n" +
         "; --------------------------------------------------------------\n"
      );
   }

   private Text genBaseObjectsRules() {
      final TextSeq seq = textFact.newText();

      class Visitor implements SVisitor.TypeVisitor<None> {
         public String name;
         String params = "";
         String types = "";
         String typedParams = "";
         String obj = "";

         public void setStrings(Type type) {
            params = "";
            if (type.isStructMember())
               params = params + "m";
            if (type.isTLocal) {
               if (type.isStructMember())
                  params += " ";
               params = params + "t";
            }
            if (type.isArray()) {
               if (type.isTLocal || type.isStructMember())
                  params += " ";
               params = params + "i";
            }
            obj = params.equals("") ? name : "(" + name + " " + params + ")";
            if (type.isStructMember() || type.isTLocal || type.isArray())
               params += " ";
//            if (type.isArray || type.isTLocal)
//               name = "(" + name  + ")";
            types = "";
            if (type.isStructMember())
               types = types + "(Int)";
            if (type.isTLocal) {
               if (type.isStructMember())
                  types = types + " ";
               types = types + "(Int)";
            }
            if (type.isArray()) {
               if (type.isStructMember() || type.isTLocal)
                  types += " ";
               types = types + "(Int)";
            }
            if (type.isStructMember() || type.isTLocal || type.isArray())
               types += " ";

            typedParams = "";
            if (type.isStructMember())
               typedParams = typedParams + "(m Int)";
            if (type.isTLocal) {
               if (type.isStructMember())
                  typedParams = typedParams + " ";
               typedParams = typedParams + "(t Int)";
            }
            if (type.isArray()) {
               if (type.isStructMember() || type.isTLocal)
                  typedParams += " ";
               typedParams = typedParams + "(i Int)";
            }
            if (type.isStructMember() || type.isTLocal || type.isArray())
               typedParams += " ";
         }

         public void genLinRules() {
            seq.put("; ----------------------------------------------------------------\n");
            seq.put(
               "(declare-fun /prec_" + name + " (" + types + "(Label) (Label)) Bool)\n"+
               "\n"
            );
            seq.put(
               "(assert\n"+
               "   (forall (" + typedParams + "(l_1 Label) (l_2 Label))\n"+
               "      (=>\n"+
               "         (and\n"+
               "            (= (obj l_1) " + obj + ")\n"+
               "            (= (obj l_2) " + obj + ")\n"+
               "         )\n"+
               "         (iff\n"+
               "            (/prec_X l_1 l_2)\n"+
               "            (/prec_" + name + " " + params + "l_1 l_2)\n"+
               "         )\n"+
               "      )\n"+
               "   )\n"+
               ")\n"
            );
//            seq.put(
//               "; LTotal\n"+
//               "(assert\n"+
//               "   (forall (" + typedParams + "(l_1 Label) (l_2 Label))\n"+
//               "      (=>\n"+
//               "         (and\n"+
//               "            (= (obj l_1) " + obj + ")\n"+
//               "            (= (obj l_2) " + obj + ")\n"+
//               "            (not (= l_1 l_2))\n"+
//               "            (exec l_1)\n"+
//               "            (exec l_2)\n"+
//               "         )\n"+
//               "         (or \n"+
//               "            (/prec_" + name + " " + params + "l_1 l_2)\n"+
//               "            (/prec_" + name + " " + params + "l_2 l_1)\n"+
//               "         )\n"+
//               "      )\n"+
//               "   )\n"+
//               ")\n"+
//               "\n"
//            );
//            seq.put(
//               "; LTrans\n" +
//               "(assert\n" +
//               "   (forall (" + typedParams + "(l_1 Label) (l_2 Label) (l_3 Label))\n" +
//               "      (=>\n" +
//               "         (and\n" +
//               "            (= (obj l_1) " + obj + ")\n" +
//               "            (= (obj l_2) " + obj + ")\n" +
//               "            (= (obj l_3) " + obj + ")\n" +
//               "            (exec l_1)\n" +
//               "            (exec l_2)\n" +
//               "            (exec l_3)\n" +
//               "            (/prec_" + name + " " + params + "l_1 l_2)\n"+
//               "            (/prec_" + name + " " + params + "l_2 l_3)\n"+
//               "         )\n" +
//               "         (/prec_" + name + " " + params + "l_1 l_3)\n"+
//               "      )\n" +
//               "   )\n" +
//               ")\n"
//            );
//            seq.put(
//               "; LASym Asymmetric\n"+
//               "(assert\n"+
//               "   (forall (" + typedParams + "(l_1 Label) (l_2 Label))\n"+
//               "      (not\n"+
//               "         (and \n"+
//               "            (/prec_" + name + " " + params + "l_1 l_2)\n"+
//               "            (/prec_" + name + " " + params + "l_2 l_1)\n"+
//               "         ) \n"+
//               "      )\n"+
//               "   )\n"+
//               ")\n"+
//               "\n"
//            );
//            seq.put(
//               "; X2L, Real-time order preservation\n"+
//               "(assert\n"+
//               "   (forall (" + typedParams + "(l_1 Label) (l_2 Label))\n"+
//               "      (=>\n"+
//               "         (and\n"+
//               "            (= (obj l_1) " + obj + ") (= (obj l_2) " + obj + ")\n"+
//               "            (/prec_X l_1 l_2)\n"+
//               "         )\n"+
//               "         (/prec_" + name + " " + params + "l_1 l_2)\n"+
//               "      )\n"+
//               "   )\n"+
//               ")\n"
//            );
//            seq.put(
//               "; XLTrans\n" +
//               "(assert\n" +
//               "   (forall (" + typedParams + "\n" +
//               "            (l1 Label) (l2 Label) \n" +
//               "            (l3 Label) (l4 Label))\n" +
//               "      (=>\n" +
//               "         (and\n" +
//               "            (/prec_X l1 l2)\n" +
//               "            (/prec_" + name + " " + params + "l2 l3)\n"+
//               "            (/prec_X l3 l4)\n" +
//               "         )\n" +
//               "         (/prec_X l1 l4)\n" +
//               "      )\n" +
//               "   )\n" +
//               ")\n" +
//               "\n"
//            );
            seq.put("; ----------------------------------------------------------------\n");
         }

         public None visit(AtomicRegister register) {
            setStrings(register);
            genLinRules();

            seq.put(
               "; ----------------------------------------------------------------\n" +
               "\n" +
               "(define-fun isRead_" + name + " (" + typedParams + "(l_r Label)) Bool\n" +
               "   (and\n" +
               "      (exec l_r)\n" +
               "      (= (obj l_r) " + obj + ")\n" +
               "      (= (method l_r) read)\n" +
               "   )\n" +
               ")\n" +
               "(define-fun isCAS_" + name + " (" + typedParams + "(l_c Label)) Bool\n" +
               "   (and\n" +
               "      (exec l_c)\n" +
               "      (= (obj l_c) " + obj + ")\n" +
               "      (= (method l_c) cas)\n" +
               "   )\n" +
               ")\n" +
               "(define-fun isWrite_" + name + " (" + typedParams + "(l_w Label)) Bool\n" +
               "   (and\n" +
               "      (exec l_w)\n" +
               "      (= (obj l_w) " + obj + ")\n" +
//               "      (= (method l_w) write)\n" +
               "      (or\n" +
               "         (= (method l_w) write)\n" +
               "         (and\n" +
               "            (= (method l_w) cas)\n" +
               "            (= (valOf (retv l_w)) 1)\n" +
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n"
            );
            seq.put(
               "(define-fun writtenVarl_" + name + " ((l_w Label)) Varl\n" +
               "   (ite\n" +
               "      (= (method l_w) cas)\n" +
               "      (arg2 l_w)\n" +
               "      (arg1 l_w)\n" +
               "   )\n" +
               ")\n" +
               "\n"
            );
//            seq.put(
//               ";(declare-fun noWriteBetween_" + name + " (" + types + "(Label) (Label)) Bool)\n" +
//               ";(assert\n" +
//               ";   (forall ((l_w Label) (l_r Label))\n" +
//               ";      (iff\n" +
//               ";         (noWriteBetween_" + name + " " + params + "l_w l_r)\n" +
//               ";         (forall ((l_w^ Label))\n" +
//               ";            (=>\n" +
//               ";               (isWrite_" + name + " " + params + "l_w^)\n" +
//               ";               (or\n" +
//               ";                  (/prec_" + name + " " + params + "l_w^ l_w)\n" +
//               ";                  (/prec_" + name + " " + params + "l_r l_w^)\n" +
//               ";                  (= l_w l_w^)\n" +
//               ";               )\n" +
//               ";            )\n" +
//               ";         )\n" +
//               ";      )\n" +
//               ";   )\n" +
//               ";)\n" +
//               "\n"
//            );
            seq.put(
               "(define-fun noWriteBetween_" + name + "_p (" +
                     typedParams + "(l_w Label) (l_r Label) (l_w^ Label)) Bool\n" +
               "   (=>\n" +
               "      (isWrite_" + name + " " + params + "l_w^)\n" +
               "      (or\n" +
               "         (/prec_" + name + " " + params + "l_w^ l_w)\n" +
               "         (/prec_" + name + " " + params + "l_r l_w^)\n" +
               "         (= l_w l_w^)\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(declare-fun noWriteBetween_" + name + " (" + types + "(Label) (Label)) Bool)\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_w Label) (l_r Label))\n" +
               "      (iff\n" +
               "         (noWriteBetween_" + name + " " + params + "l_w l_r)\n" +
               "         (and\n"
            );

            boolean wrote = false;
            for (XNode xNode : xNodes) {
               if (xNode instanceof GMCallNode) {
                  GMCallNode gmCallNode = (GMCallNode) xNode;
                  String objName;
                  if (gmCallNode instanceof MCallNode)
                     objName = gmCallNode.getGMethodCall().obj.name;
                  else //if (gmCallNode instanceof FMCallNode)
                     objName = "mem_" + gmCallNode.getGMethodCall().obj.name;
                  if (objName.equals(name)) {
                     String l_3 = xNode.getFlatLabel();
                     seq.put(
                        "            (noWriteBetween_" + name + "_p " + params + "l_w l_r " + l_3 + ")\n"
                     );
                     wrote = true;
                  }
               }
            }
            if (!wrote)
               seq.put(
                  "            false\n");

            seq.put(
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "\n" +
               "(define-fun isWriter_" + name + " (" + typedParams + "(l_w Label)(l_r Label)) Bool\n" +
               "   (and\n" +
               "      (isWrite_" + name + " " + params + "l_w)\n" +
               "      (/prec_" + name + " " + params + "l_w l_r)\n" +
               "      (noWriteBetween_" + name + " " + params + "l_w l_r)\n" +
               "   )\n" +
               ")\n" +
               "\n" +
//               "(declare-fun writerMethod_" + name + " ((Label)) Label)\n" +
//               "\n" +
//               "(assert\n" +
//               "   (forall ((l_r Label))\n" +
//               "      (=>\n" +
//               "         (isRead_" + name + " l_r)\n" +
//               "         (let ((l_w (writerMethod_" + name + " l_r)))\n" +
//               ";         (exists ((l_w Label))\n" +
//               "            (and\n" +
//               "               (isWriter_" + name + " l_w l_r)\n" +
//               "               (validEq (retv l_r) (arg1 l_w))\n" +
//               "            )\n" +
//               "         )\n" +
//               "      )\n" +
//               "   )\n" +
//               ")\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_r Label)(l_w Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isRead_" + name + " " + params + "l_r)\n" +
               "            (isWriter_" + name + " " + params + "l_w l_r)\n" +
               "         )\n" +
//               "         (validEq (retv l_r) (arg1 l_w))\n" +
               "         (validEq (var (retv l_r)) (writtenVarl_" + name + " l_w))\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_c Label)(l_w Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isCAS_" + name + " " + params + "l_c)\n" +
               "            (isWriter_" + name + " " + params + "l_w l_c)\n" +
               "         )\n" +
               "         (ite\n" +
               "            (validEq (arg1 l_c) (writtenVarl_" + name + " l_w))\n" +
               "            (= (valOf (retv l_c)) 1)\n" +
               "            (= (valOf (retv l_c)) 0)\n" +
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "; ----------------------------------------------------------------\n"
            );
            return None.instance();
         }

         public None visit(BasicRegister register) {
            setStrings(register);
            seq.put(
               "; ----------------------------------------------------------------\n" +
               "\n" +
               "(define-fun isSeq_" + name + " (" + typedParams + ") Bool\n" +
               "   (forall ((l1 Label) (l2 Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (= (obj l1) " + obj + ")\n" +
               "            (= (obj l2) " + obj + ")\n" +
               "         )\n" +
               "         (or\n" +
               "            (= l1 l2)\n" +
               "            (/prec_X (retEv l1) l2)\n" +
               "            (/prec_X (retEv l2) l1)\n" +
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n"
            );

            seq.put(
               "(define-fun isRead_X_" + name + " (" + typedParams + "(l_r Label)) Bool\n" +
               "   (and\n" +
               "      (exec l_r)\n" +
               "      (= (obj l_r) " + obj + ")\n" +
               "      (= (method l_r) read)\n" +
               "   )\n" +
               ")\n" +
               "(define-fun isWrite_X_" + name + " (" + typedParams + "(l_w Label)) Bool\n" +
               "   (and\n" +
               "      (exec l_w)\n" +
               "      (= (obj l_w) " + obj + ")\n" +
               "      (= (method l_w) write)\n" +
               "   )\n" +
               ")\n" +
               "\n"
            );
            seq.put(
               "(define-fun noWriteBetween_X_" + name + "_p (" +
                     typedParams + "(l_w Label) (l_r Label) (l_w^ Label)) Bool\n" +
               "   (=>\n" +
               "      (isWrite_X_" + name + " " + params + "l_w^)\n" +
               "      (or\n" +
               "         (/prec_X " + params + "l_w^ l_w)\n" +
               "         (/prec_X " + params + "l_r l_w^)\n" +
               "         (= l_w l_w^)\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(declare-fun noWriteBetween_X_" + name +
                     " (" + types + "(Label) (Label)) Bool)\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_w Label) (l_r Label))\n" +
               "      (iff\n" +
               "         (noWriteBetween_X_" + name + " " + params + "l_w l_r)\n" +
               "         (and\n"
            );

            boolean wrote = false;
            for (XNode xNode : xNodes) {
               if (xNode instanceof GMCallNode) {
                  GMCallNode gmCallNode = (GMCallNode) xNode;
                  String objName;
                  if (gmCallNode instanceof MCallNode)
                     objName = gmCallNode.getGMethodCall().obj.name;
                  else //if (gmCallNode instanceof FMCallNode)
                     objName = "mem_" + gmCallNode.getGMethodCall().obj.name;
                  if (objName.equals(name)) {
                     String l_3 = xNode.getFlatLabel();
                     seq.put(
                        "            (noWriteBetween_X_" + name + "_p " +
                              params + "l_w l_r " + l_3 + ")\n"
                     );
                     wrote = true;
                  }
               }
            }
            if (!wrote)
               seq.put(
                  "            false\n");

            seq.put(
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "\n" +
               "(define-fun isWriter_X_" + name +
                     " (" + typedParams + "(l_w Label)(l_r Label)) Bool\n" +
               "   (and\n" +
               "      (isWrite_X_" + name + " " + params + "l_w)\n" +
               "      (/prec_X " + params + "l_w l_r)\n" +
               "      (noWriteBetween_X_" + name + " " + params + "l_w l_r)\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_r Label)(l_w Label))\n" +
               "      (=>\n" +
               "         (and\n"
            );
            if (params.equals(""))
               seq.put(
                  "            isSeq_" + name + "\n"
               );
            else
               seq.put(
                  "            (isSeq_" + name + " " + params + ")\n"
               );

            seq.put(
               "            (isRead_X_" + name + " " + params + "l_r)\n" +
               "            (isWriter_X_" + name + " " + params + "l_w l_r)\n" +
               "         )\n" +
               "         (validEq (var (retv l_r)) (arg1 l_w))\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "; ----------------------------------------------------------------\n"
            );
            return None.instance();
         }

         public None visit(Lock lock) {
            setStrings(lock);
            genLinRules();
            seq.put("; ----------------------------------------------------------------\n");
            seq.put(
                  "(define-fun isLock_" + name + " (" + typedParams + "(l_l Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_l)\n" +
                  "      (= (obj l_l) " + obj + ")\n" +
                  "      (= (method l_l) mlock)\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isUnlock_" + name + " (" + typedParams + "(l_u Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_u)\n" +
                  "      (= (obj l_u) " + obj + ")\n" +
                  "      (= (method l_u) unlock)\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isLockOrUnlock_" + name + " (" + typedParams + "(l_u Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_u)\n" +
                  "      (= (obj l_u) " + obj + ")\n" +
                  "   )\n" +
                  ")\n" +
                  "\n" +
                  "(define-fun notBetween_" + name + " (" + typedParams +
                        "(l_1 Label) (l_2 Label) (l_3 Label)) Bool\n" +
                  "   (=>\n" +
                  "      (= (obj l_3) " + obj + ")\n" +
                  "      (or\n" +
                  "         (/prec_" + name + " " + params + "l_3 l_1)\n" +
                  "         (/prec_" + name + " " + params + "l_2 l_3)\n" +
                  "         (= l_1 l_3)\n" +
                  "         (= l_2 l_3)\n" +
                  "      )\n" +
                  "   )\n" +
                  ")\n" +
                  "\n" +
                  "(declare-fun noLockOrUnlockBetween_" + name + " (" + types + "(Label) (Label)) Bool)\n" +
                  "(assert\n" +
                  "   (forall (" + typedParams + "(l_1 Label) (l_2 Label))\n" +
                  "      (iff\n" +
                  "         (noLockOrUnlockBetween_" + name + " " + params + "l_1 l_2)\n" +
                  "         (and\n");
            boolean wrote = false;
            for (XNode xNode : xNodes) {
               if (xNode instanceof GMCallNode) {
                  GMCallNode gmCallNode = (GMCallNode) xNode;
                  String objName;
                  if (gmCallNode instanceof MCallNode)
                     objName = gmCallNode.getGMethodCall().obj.name;
                  else //if (gmCallNode instanceof FMCallNode)
                     objName = "mem_" + gmCallNode.getGMethodCall().obj.name;

                  if (objName.equals(name)) {
                     wrote = true;
                     String l_3 = xNode.getFlatLabel();
                     seq.add(
                        "            (=>\n" +
                        "               (exec " + l_3 + ")\n" +
                        "               (notBetween_" + name + " " + params + "l_1 l_2 " + l_3 + ")\n" +
                        "            )\n"
                     );
                  }
               }
            }
            if (!wrote) {
               seq.add(
                  "            false\n");
            }
            seq.add(
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(define-fun isLastLockOrUnlockBefore_" + name + " (" + typedParams +
                     "(l_1 Label)(l_2 Label)) Bool\n" +
               "   (and\n" +
               "      (isLockOrUnlock_" + name + " " + params + "l_1)\n" +
               "      (isLockOrUnlock_" + name + " " + params + "l_2)\n" +
               "      (/prec_" + name + " " + params + "l_1 l_2)\n" +
               "      (noLockOrUnlockBetween_" + name + " " + params + "l_1 l_2)\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_u Label)(l_l Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isLock_" + name + " " + params + "l_l)\n" +
               "            (isLastLockOrUnlockBefore_" + name + " " + params + "l_u l_l)\n" +
               "         )\n" +
               "         (= (method l_u) unlock) \n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_l Label)(l_u Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isUnlock_" + name + " " + params + "l_u)\n" +
               "            (isLastLockOrUnlockBefore_" + name + " " + params + "l_l l_u)\n" +
               "         )\n" +
               "         (= (method l_l) mlock) \n" +
               "      )\n" +
               "   )\n" +
               ")\n"
            );
            seq.put("; ----------------------------------------------------------------\n");
            return None.instance();
         }

         public None visit(TryLock tryLock) {
            setStrings(tryLock);
            genLinRules();
            seq.put("; ----------------------------------------------------------------\n");
            seq.put(
                  "(define-fun isLock_" + name + " (" + typedParams + "(l_u Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_u)\n" +
                  "      (= (obj l_u) " + obj + ")\n" +
                  "      (= (method l_u) mlock)\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isUnlock_" + name + " (" + typedParams + "(l_u Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_u)\n" +
                  "      (= (obj l_u) " + obj + ")\n" +
                  "      (= (method l_u) unlock)\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isRead_" + name + " (" + typedParams + "(l_u Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_u)\n" +
                  "      (= (obj l_u) " + obj + ")\n" +
                  "      (= (method l_u) read)\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isTryLock_" + name + " (" + typedParams + "(l_u Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_u)\n" +
                  "      (= (obj l_u) " + obj + ")\n" +
                  "      (= (method l_u) mtryLock)\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isSuccessLock_" + name + " (" + typedParams + "(l_l Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_l)\n" +
                  "      (= (obj l_l) " + obj + ")\n" +
                  "      (or\n" +
                  "         (= (method l_l) mlock)\n" +
                  "         (and\n" +
                  "            (= (method l_l) mtryLock)\n" +
                  "            (= (valOf (retv l_l)) 1)\n" +
                  "         )\n" +
                  "      )\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isFailLock_" + name + " (" + typedParams + "(l_l Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_l)\n" +
                  "      (= (obj l_l) " + obj + ")\n" +
                  "      (= (method l_l) mtryLock)\n" +
                  "      (= (valOf (retv l_l)) 0)\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun isLockInterfaceCall_" + name + " (" + typedParams +
                        "(l_u Label)) Bool\n" +
                  "   (and\n" +
                  "      (exec l_u)\n" +
                  "      (= (obj l_u) " + obj + ")\n" +
                  "   )\n" +
                  ")\n" +
                  "(define-fun notBetween_" + name + " (" + typedParams +
                        "(l_1 Label) (l_2 Label) (l_3 Label)) Bool\n" +
                  "   (=>\n" +
                  "      (= (obj l_3) " + obj + ")\n" +
                  "      (or\n" +
                  "         (/prec_" + name + " " + params + "l_3 l_1)\n" +
                  "         (/prec_" + name + " " + params + "l_2 l_3)\n" +
                  "         (= l_1 l_3)\n" +
                  "         (= l_2 l_3)\n" +
                  "         (isFailLock_" + name + " " + params + "l_3)\n" +
                  "         (isRead_" + name + " " + params + "l_3)\n" +
                  "      )\n" +
                  "   )\n" +
                  ")\n" +
                  "\n" +
                  "(declare-fun noSuccessLockOrUnlockBetween_" + name + " (" + types + "(Label) (Label)) Bool)\n" +
                  "(assert\n" +
                  "   (forall (" + typedParams + "(l_1 Label) (l_2 Label))\n" +
                  "      (iff\n" +
                  "         (noSuccessLockOrUnlockBetween_" + name + " " + params + "l_1 l_2)\n" +
                  "         (and\n");
            boolean wrote = false;
            for (XNode xNode : xNodes) {
               if (xNode instanceof GMCallNode) {
                  GMCallNode gmCallNode = (GMCallNode) xNode;
                  String objName;
                  if (gmCallNode instanceof MCallNode)
                     objName = gmCallNode.getGMethodCall().obj.name;
                  else //if (gmCallNode instanceof FMCallNode)
                     objName = "mem_" + gmCallNode.getGMethodCall().obj.name;

                  if (objName.equals(name)) {
                     wrote = true;
                     String l_3 = xNode.getFlatLabel();
                     seq.add(
                        "            (=>\n" +
                        "               (exec " + l_3 + ")\n" +
                        "               (notBetween_" + name + " " + params + "l_1 l_2 " + l_3 + ")\n" +
                        "            )\n"
                     );
                  }
               }
            }
            if (!wrote) {
               seq.add(
                  "            false\n");
            }
            seq.add(
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n");
            seq.add(
               "(define-fun isLastSuccessLockOrUnlockBefore_" + name + " (" + typedParams +
                     "(l_1 Label) (l_2 Label)) Bool\n" +
               "   (and\n" +
               "      (or\n" +
               "         (isSuccessLock_" + name + " " + params + "l_1)\n" +
               "         (isUnlock_" + name + " " + params + "l_1)\n" +
               "      )\n" +
               "      (/prec_" + name + " " + params + "l_1 l_2)\n" +
               "      (noSuccessLockOrUnlockBetween_" + name + " " + params + "l_1 l_2)\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_u Label)(l_l Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isLock_" + name + " " + params + "l_l)\n" +
               "            (isLastSuccessLockOrUnlockBefore_" + name + " " + params + "l_u l_l)\n" +
               "         )\n" +
               "         (= (method l_u) unlock) \n" +
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_l Label)(l_p Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isUnlock_" + name + " " + params + "l_p)\n" +
               "            (isLastSuccessLockOrUnlockBefore_" + name + " " + params + "l_l l_p)\n" +
               "         )\n" +
               "         (isSuccessLock_" + name + " " + params + "l_l)\n"+
               "      )\n" +
               "   )\n" +
               ")\n" +
               "\n" +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_l Label)(l_t Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isTryLock_" + name + " " + params + "l_t)\n" +
               "            (isLastSuccessLockOrUnlockBefore_" + name + " " + params + "l_l l_t)\n" +
               "         )\n" +
               "         (and\n" +
               "            (=>\n" +
               "               (isSuccessLock_" + name + " " + params + "l_l)\n"+
               "               (= (valOf (retv l_t)) 0)\n" +
               "            )\n" +
               "            (=>\n" +
               "               (isUnlock_" + name + " " + params + "l_l)\n"+
               "               (= (valOf (retv l_t)) 1)\n" +
               "            )\n" +
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n"
               +
               "(assert\n" +
               "   (forall (" + typedParams + "(l_l Label)(l_r Label))\n" +
               "      (=>\n" +
               "         (and\n" +
               "            (isRead_" + name + " " + params + "l_r)\n" +
               "            (isLastSuccessLockOrUnlockBefore_" + name + " " + params + "l_l l_r)\n" +
               "         )\n" +
               "         (and\n" +
               "            (=>\n" +
               "               (isSuccessLock_" + name + " " + params + "l_l)\n"+
               "               (= (valOf (retv l_r)) 1)\n" +
               "            )\n" +
               "            (=>\n" +
               "               (isUnlock_" + name + " " + params + "l_l)\n"+
               "               (= (valOf (retv l_r)) 0)\n" +
               "            )\n" +
               "         )\n" +
               "      )\n" +
               "   )\n" +
               ")\n"
            );

            seq.put("; ----------------------------------------------------------------\n");
            return None.instance();
         }
      }
      final Visitor visitor = new Visitor();

      for (Decl decl : specification.decls) {
         Type type = decl.type;
         visitor.name = decl.id.name;
         type.accept(visitor);
      }

      specification.structOption.apply(
         new Fun<Struct, Object>() {
            public Object apply(Struct struct) {
               for (Decl decl : struct.decls) {
                  Type type = decl.type;
                  type.setStructMember();
                  visitor.name = "mem_" + decl.id.name;
                  type.accept(visitor);
               }
               return null;
            }
         }
      );
      return seq.get();
   }

   private Text genConjecture() {
      // Note: This can be general for all assertions


      final TextSeq seq = textFact.newText();
      seq.put(
         "(define-fun bug () Bool\n"+
         "   (not\n"
      );
      SVisitor.AssertionVisitor<String> visitor = new SVisitor.AssertionVisitor<String>() {
         public String visitDispatch(Asser asser) {
            return asser.accept(this);
         }

         SVisitor.VarlVisitor<String> varlVisitor = new SVisitor.VarlVisitor<String>() {
            public String visit(Var var) {
               return "(valOf " + var.id.name + ")";
            }

            public String visit(Val val) {
               return val.intLiteral.lexeme;
            }
         };

         public String visit(OrAsser orAsser) {
            return "(or " + visitDispatch(orAsser.op1) + " " + visitDispatch(orAsser.op2) + ")";
         }

         public String visit(AndAsser andAsser) {
            return "(and " + visitDispatch(andAsser.op1) + " " + visitDispatch(andAsser.op2) + ")";
         }

         public String visit(NotAsser notAsser) {
            return "(not " + visitDispatch(notAsser.op) + ")";
         }

         public String visit(EqAsser eqAssertion) {
            return
               "(= " + eqAssertion.op1.accept(varlVisitor) + " " +
                       eqAssertion.op2.accept(varlVisitor) + ")";
         }

         public String visit(ExecAsser execAssertion) {
            return
               "(exec " + execAssertion.label.id.name + ")";
         }

         public String visit(OrderAsser orderAsser) {
            return "(/prec_X " + orderAsser.label1 + " " + orderAsser.label2 + ")";
         }

         public String visit(False aFalse) {
            return "false";
         }

         public String visit(True aTrue) {
            return "true";
         }
      };
      seq.put("      ");
      seq.put(specification.spec.asser.accept(visitor));
      seq.put("\n");
      seq.put(
         "   )\n"+
         ")\n"+
         "(assert bug)\n" +
         "(check-sat)  ; Should print sat\n" +
         "\n"
      );

      return seq.get();
   }

   private Text genLogs() {
      final TextSeq seq = textFact.newText();

      seq.put("(echo \"--------------------------------------\")\n");
      for (XNode xNode : xNodes) {
         String label = xNode.getFlatLabel();
         seq.put(
            "(eval (exec " + label + "))\n"
         );
      }
      seq.put("(echo \"--------------------------------------\")\n");
      for (GVar var : vars) {
         String label = var.getFlatName();
         seq.put(
            "(eval (valOf " + label + "))\n"
         );
      }
      seq.put("(echo \"--------------------------------------\")\n");
      for (XNode xNode1 : xNodes) {
         for (XNode xNode2 : xNodes) {
            String label1 = xNode1.getFlatLabel();
            String label2 = xNode2.getFlatLabel();
            seq.put(
               "(eval (/prec_X " + label1 + " " + label2 + "))\n"
            );
         }
      }
      /*
      for (final Decl decl : specification.decls) {
         final Type type = decl.type;
         if ((type instanceof Lock) ||
               (type instanceof TryLock) ||
               (type instanceof AtomicRegister)) {
            seq.put("(echo \"--------------------------------------\")\n");
            type.arraySize.apply(
               new Fun0<None>() {
                  public None apply() {
                     if (!type.isTLocal) {
                        String objName = decl.id.name;
                        for (XNode xNode1 : xNodes) {
                           if (xNode1 instanceof MCallNode) {
                              MCallNode mCallNode1 = (MCallNode) xNode1;
                              String mCallObjName1 = mCallNode1.methodCall.obj.name;
                              if (mCallObjName1.equals(objName)) {
                                 for (XNode xNode2 : xNodes) {
                                    if (xNode2 instanceof MCallNode) {
                                       MCallNode mCallNode2 = (MCallNode) xNode2;
                                       String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                       if (mCallObjName2.equals(objName)) {
                                          String label1 = xNode1.getFlatLabel();
                                          String label2 = xNode2.getFlatLabel();
                                          seq.put(
                                             "(eval (/prec_" + objName + " " + label1 + " " + label2 + "))\n"
                                          );
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     } else {
                        String objName = decl.id.name;
                        for (int t = 0; t < specification.main.blocks.length; t++) {
                           seq.put("(echo \"--------------------------------------\")\n");
                           for (XNode xNode1 : xNodes) {
                              if (xNode1 instanceof MCallNode) {
                                 MCallNode mCallNode1 = (MCallNode) xNode1;
                                 String mCallObjName1 = mCallNode1.methodCall.obj.name;
                                 if (mCallObjName1.equals(objName)) {
                                    for (XNode xNode2 : xNodes) {
                                       if (xNode2 instanceof MCallNode) {
                                          MCallNode mCallNode2 = (MCallNode) xNode2;
                                          String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                          if (mCallObjName2.equals(objName)) {
                                             String label1 = xNode1.getFlatLabel();
                                             String label2 = xNode2.getFlatLabel();
                                             seq.put(
                                                "(eval (/prec_" + objName + " " + (t+1) + " " + label1 + " " + label2 + "))\n"
                                             );
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                     return None.instance();
                  }
               },
               new Fun<Integer, None>() {
                  public None apply(Integer size) {
                     if (!type.isTLocal) {
                        for (int i = 0; i < size; i++) {
                           seq.put("(echo \"--------------------------------------\")\n");
                           String objName = decl.id.name;
                           for (XNode xNode1 : xNodes) {
                              if (xNode1 instanceof MCallNode) {
                                 MCallNode mCallNode1 = (MCallNode) xNode1;
                                 String mCallObjName1 = mCallNode1.methodCall.obj.name;
                                 if (mCallObjName1.equals(objName)) {
                                    for (XNode xNode2 : xNodes) {
                                       if (xNode2 instanceof MCallNode) {
                                          MCallNode mCallNode2 = (MCallNode) xNode2;
                                          String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                          if (mCallObjName2.equals(objName)) {
                                             String label1 = xNode1.getFlatLabel();
                                             String label2 = xNode2.getFlatLabel();
                                             seq.put(
                                                "(eval (/prec_" + objName + " " + (i) + " " + label1 + " " + label2 + "))\n"
                                             );
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     } else {
                        for (int t = 0; t < specification.main.blocks.length; t++) {
                           seq.put("(echo \"--------------------------------------\")\n");
                           for (int i = 0; i < size; i++) {
                              seq.put("(echo \"--------------------------------------\")\n");
                              String objName = decl.id.name;
                              for (XNode xNode1 : xNodes) {
                                 if (xNode1 instanceof MCallNode) {
                                    MCallNode mCallNode1 = (MCallNode) xNode1;
                                    String mCallObjName1 = mCallNode1.methodCall.obj.name;
                                    if (mCallObjName1.equals(objName)) {
                                       for (XNode xNode2 : xNodes) {
                                          if (xNode2 instanceof MCallNode) {
                                             MCallNode mCallNode2 = (MCallNode) xNode2;
                                             String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                             if (mCallObjName2.equals(objName)) {
                                                String label1 = xNode1.getFlatLabel();
                                                String label2 = xNode2.getFlatLabel();
                                                seq.put(
                                                   "(eval (/prec_" + objName + " " + (t+1) + " " + (i) + " " + label1 + " " + label2 + "))\n"
                                                );
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                     return None.instance();
                  }
               }
            );
         }
      }
      */
      seq.put("(echo \"--------------------------------------\")\n");
      return seq.get();
   }

   // --------------------------------------------------------------------------------
   public Pair<Boolean, List<String>[]> renderInterleaving(
         final Scanner scanner) {
      // Parse the input, get the exec and lin orders from z3 and add them to the graph.
      // Do topological sort on the graph.
      // Generate the sequence for each thread.

      // Ordering the graph
      // Add exec order. Why exec order? Because of the freedom for reordering
      // in each thread.
      // Add linearization orders for cross-thread ordering
      // Linearization orders are added to strictly order method calls according
      // to their linearization order even if they overlap execution.
      // But we do not have inv and ret for lin objects. So because of
      // real-time order, lin order is the same as exec order.
      // Thus, it seems that we do not need lin orders.
      // Should we consider \preceq as well? If we consider only lin objects
      // it is not needed.
      // inv and ret only for basic registers.

//      System.out.println("The output:");
//      while (scanner.hasNext()) {
//         String line = scanner.nextLine();
//         System.out.println(line);
//      }

      String result = scanner.nextLine();
      System.out.println(result);
      if (result.equals("sat")) {
         String skip = scanner.nextLine();
         System.out.println("Skipped: " + skip);
         System.out.println("exec");
         for (XNode xNode : xNodes) {
            System.out.print(xNode.getFlatLabel() + "\t");
         }
         System.out.println();

         for (XNode xNode : xNodes) {
            String val = scanner.nextLine();
            System.out.print(val + "\t");
            xNode.exec = val.equals("true");
         }
         System.out.println();

         skip = scanner.nextLine();
         System.out.println("Skipped: " + skip);

//         for (GVar var : vars) {
//            System.out.print(var.getFlatName() + "\t");
//         }
//         System.out.println();

         for (GVar var : vars) {
            String val = scanner.nextLine();
//            System.out.print(val + "\t");
            if (val.startsWith("(-"))
               val = val.substring(3, val.length() - 1);
            valOf.put(var.getFlatName(), Integer.parseInt(val));
            System.out.println(var.getFlatName() + " = " + val);
         }
//         System.out.println();

         skip = scanner.nextLine();
         System.out.println("Skipped: " + skip);
         System.out.println("\\prec_X");
         System.out.print("\t\t");
         for (XNode xNode1 : xNodes) {
            System.out.print(xNode1.getFlatLabel() + "\t");
         }
         System.out.println();

         for (XNode xNode1 : xNodes) {
            System.out.print(xNode1.getFlatLabel() + "\t");
            for (XNode xNode2 : xNodes) {
               String val = scanner.nextLine();
               System.out.print(val + "\t");
               if (xNode1.isExec() && xNode2.isExec() && val.equals("true"))
                  execGraph.add(xNode1, xNode2);
            }
            System.out.println();
         }
         /*
         for (final Decl decl : specification.decls) {
            final Type type = decl.type;
            if ((type instanceof Lock) ||
                  (type instanceof TryLock) ||
                  (type instanceof AtomicRegister)) {
               skip = scanner.nextLine();
               System.out.println("Skipped: " + skip);
               type.arraySize.apply(
                  new Fun0<None>() {
                     public None apply() {
                        if (!type.isTLocal) {
                           String objName = decl.id.name;
                           System.out.println("\\prec_" + objName);
                           System.out.print("\t\t");
                           for (XNode xNode : xNodes) {
                              if (xNode instanceof MCallNode) {
                                 MCallNode mCallNode = (MCallNode) xNode;
                                 String mCallObjName1 = mCallNode.methodCall.obj.name;
                                 if (mCallObjName1.equals(objName)) {
                                    System.out.print(xNode.getFlatLabel() + "\t");
                                 }
                              }
                           }
                           System.out.println();

                           for (XNode xNode1 : xNodes) {
                              if (xNode1 instanceof MCallNode) {
                                 MCallNode mCallNode1 = (MCallNode) xNode1;
                                 String mCallObjName1 = mCallNode1.methodCall.obj.name;
                                 if (mCallObjName1.equals(objName)) {
                                    System.out.print(xNode1.getFlatLabel() + "\t");
                                    for (XNode xNode2 : xNodes) {
                                       if (xNode2 instanceof MCallNode) {
                                          MCallNode mCallNode2 = (MCallNode) xNode2;
                                          String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                          if (mCallObjName2.equals(objName)) {
                                             String val = scanner.nextLine();
                                             System.out.print(val + "\t");
                                             if (val.equals("true"))
                                                execGraph.add(xNode1, xNode2);
                                          }
                                       }
                                    }
                                    System.out.println();
                                 }
                              }
                           }
                        } else {
                           String objName = decl.id.name;
                           for (int t = 0; t < specification.main.blocks.length; t++) {
                              String skip = scanner.nextLine();
                              System.out.println("Skipped: " + skip);

                              System.out.println("\\prec_" + objName + " " + (t+1));
                              System.out.print("\t\t");
                              for (XNode xNode : xNodes) {
                                 if (xNode instanceof MCallNode) {
                                    MCallNode mCallNode = (MCallNode) xNode;
                                    String mCallObjName1 = mCallNode.methodCall.obj.name;
                                    if (mCallObjName1.equals(objName) && mCallNode.tId == (t+1)) {
                                       System.out.print(xNode.getFlatLabel() + "\t");
                                    }
                                 }
                              }
                              System.out.println();

                              for (XNode xNode1 : xNodes) {
                                 if (xNode1 instanceof MCallNode) {
                                    MCallNode mCallNode1 = (MCallNode) xNode1;
                                    String mCallObjName1 = mCallNode1.methodCall.obj.name;
                                    if (mCallObjName1.equals(objName)) {
                                       if (mCallNode1.tId == t+1) {
                                          System.out.print(xNode1.getFlatLabel() + "\t");
                                          for (XNode xNode2 : xNodes) {
                                             if (xNode2 instanceof MCallNode) {
                                                MCallNode mCallNode2 = (MCallNode) xNode2;
                                                String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                                if (mCallObjName2.equals(objName)) {
                                                   String val = scanner.nextLine();
                                                   if (mCallNode1.tId == (t+1) && mCallNode2.tId == (t+1)) {
                                                      System.out.print(val + "\t");
                                                      if (val.equals("true"))
                                                         execGraph.add(xNode1, xNode2);
                                                   }
                                                }
                                             }
                                          }
                                          System.out.println();
                                       } else {
                                          for (XNode xNode2 : xNodes) {
                                             if (xNode2 instanceof MCallNode) {
                                                MCallNode mCallNode2 = (MCallNode) xNode2;
                                                String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                                if (mCallObjName2.equals(objName))
                                                   scanner.nextLine();
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                        return None.instance();
                     }
                  },
                  new Fun<Integer, None>() {
                     public None apply(Integer size) {
                        if (!type.isTLocal) {
                           String objName = decl.id.name;
                           for (int i = 0; i < size; i++) {
                              String skip = scanner.nextLine();
                              System.out.println("Skipped: " + skip);

                              System.out.println("\\prec_" + objName + " " + (i));
                              System.out.print("\t\t");
                              for (XNode xNode : xNodes) {
                                 if (xNode instanceof MCallNode) {
                                    MCallNode mCallNode = (MCallNode) xNode;
                                    String mCallObjName1 = mCallNode.methodCall.obj.name;
                                    int index1 = valOfIndex(mCallNode);
                                    if (mCallObjName1.equals(objName) && index1 == (i)) {
                                       System.out.print(xNode.getFlatLabel() + "\t");
                                    }
                                 }
                              }
                              System.out.println();

                              for (XNode xNode1 : xNodes) {
                                 if (xNode1 instanceof MCallNode) {
                                    MCallNode mCallNode1 = (MCallNode) xNode1;
                                    String mCallObjName1 = mCallNode1.methodCall.obj.name;
                                    int index1 = valOfIndex(mCallNode1);
                                    if (mCallObjName1.equals(objName)) {
                                       if (index1 == (i)) {
                                          System.out.print(xNode1.getFlatLabel() + "\t");
                                          for (XNode xNode2 : xNodes) {
                                             if (xNode2 instanceof MCallNode) {
                                                MCallNode mCallNode2 = (MCallNode) xNode2;
                                                int index2 = valOfIndex(mCallNode2);
                                                String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                                if (mCallObjName2.equals(objName)) {
                                                   String val = scanner.nextLine();
                                                   if (index2 == (i)) {
                                                      System.out.print(val + "\t");
                                                      if (val.equals("true"))
                                                         execGraph.add(xNode1, xNode2);
                                                   }
                                                }
                                             }
                                          }
                                          System.out.println();
                                       } else {
                                          for (XNode xNode2 : xNodes) {
                                             if (xNode2 instanceof MCallNode) {
                                                MCallNode mCallNode2 = (MCallNode) xNode2;
                                                String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                                if (mCallObjName2.equals(objName))
                                                   scanner.nextLine();
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        } else {
                           String objName = decl.id.name;
                           for (int t = 0; t < specification.main.blocks.length; t++) {
                              String skip = scanner.nextLine();
                              System.out.println("Skipped: " + skip);

                              for (int i = 0; i < size; i++) {
                                 skip = scanner.nextLine();
                                 System.out.println("Skipped: " + skip);

                                 System.out.println("\\prec_" + objName + " " + (t+1) + " " + (i));
                                 System.out.print("\t\t");
                                 for (XNode xNode : xNodes) {
                                    if (xNode instanceof MCallNode) {
                                       MCallNode mCallNode = (MCallNode) xNode;
                                       String mCallObjName1 = mCallNode.methodCall.obj.name;
                                       Integer index1 = valOfIndex(mCallNode);
                                       if (mCallObjName1.equals(objName) && mCallNode.tId == (t+1) && index1 == (i)) {
                                          System.out.print(xNode.getFlatLabel() + "\t");
                                       }
                                    }
                                 }
                                 System.out.println();

                                 for (XNode xNode1 : xNodes) {
                                    if (xNode1 instanceof MCallNode) {
                                       MCallNode mCallNode1 = (MCallNode) xNode1;
                                       String mCallObjName1 = mCallNode1.methodCall.obj.name;
                                       Integer index1 = valOfIndex(mCallNode1);
                                       if (mCallObjName1.equals(objName)) {
                                          if (mCallNode1.tId == (t+1) && index1 == (i)) {
                                             System.out.print(xNode1.getFlatLabel() + "\t");
                                             for (XNode xNode2 : xNodes) {
                                                if (xNode2 instanceof MCallNode) {
                                                   MCallNode mCallNode2 = (MCallNode) xNode2;
                                                   int index2 = valOfIndex(mCallNode2);
                                                   String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                                   if (mCallObjName2.equals(objName)) {
                                                      String val = scanner.nextLine();
                                                      if (mCallNode1.tId == (t+1) && mCallNode2.tId == (t+1) &&
                                                         index1 == (i) && index2 == (i)) {
                                                         System.out.print(val + "\t");
                                                         if (val.equals("true"))
                                                            execGraph.add(xNode1, xNode2);

                                                      }
                                                   }
                                                }
                                             }
                                             System.out.println();
                                          } else {
                                             for (XNode xNode2 : xNodes) {
                                                if (xNode2 instanceof MCallNode) {
                                                   MCallNode mCallNode2 = (MCallNode) xNode2;
                                                   String mCallObjName2 = mCallNode2.methodCall.obj.name;
                                                   if (mCallObjName2.equals(objName))
                                                      scanner.nextLine();
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                        return None.instance();
                     }
                  }
               );
            }
         }
         */
         skip = scanner.nextLine();
         System.out.println("Skipped: " + skip);


         System.out.println("=========================================================");
         final TopologicalSort sorter = new TopologicalSort(execGraph);
         Option<List<GNode>> sorted = sorter.sort();
         int size = specification.main.blocks.length + 2;
         final List<String>[] lists = new List[size];
         for (int i = 0; i < lists.length; i++)
            lists[i] = new LinkedList<String>();
   //      System.out.println(list);
         sorted.apply(
               new Fun0<None>() {
                  public None apply() {
                     System.out.println("The cycle:");
                     for (Object o : sorter.cycleQueue) {
                        System.out.println(o);
                     }
                     return None.instance();
                  }
               },
               new Fun<List<GNode>, None>() {
                  public None apply(List<GNode> nodes) {
                     for (GNode node : nodes) {
                        for (int i = 0; i < lists.length; i++) {
                           List<String> strings = lists[i];
                           if (node.isExec()) {
                              if (node instanceof MCallNode) {
                                 MCallNode mCallNode = (MCallNode) node;
                                 if (mCallNode.methodCall.obj.name.equals("lastObj"))
                                    continue;
                              }
                              if (node.tId == i) {
                                 String s = node.toString();
//                                 String s = node.print(valOf);
                                 strings.add(s);
                              } else
                                 strings.add("");
                           }
                        }
                     }
                     return None.instance();
                  }
               }
         );
         return new Pair<Boolean, List<String>[]>(false, lists);

      } else if (result.equals("unsat")) {
         return new Pair<Boolean, List<String>[]>(true, null);
      } else {
//         TextSeq seq = textFact.newText();
         System.out.println(result);
//         seq.add(result + "\n");
         while (scanner.hasNext()) {
            String line = scanner.nextLine();
            System.out.println(line);
//            seq.add(line + "\n");
         }
//         return seq.get();
         return new Pair<Boolean, List<String>[]>(false, null);
      }
   }

   private int valOfIndex(MCallNode mCallNode) {
      final String preLabel = mCallNode.preLabel;

      return mCallNode.methodCall.index.apply(
         new Fun0<Integer>() {
            public Integer apply() {
               return 0;
            }
         },
         new Fun<Varl, Integer>() {
            public Integer apply(Varl varl) {
               SVisitor.VarlVisitor<Integer> visitor = new SVisitor.VarlVisitor<Integer>() {
                  public Integer visit(Var var) {
                     GVar gVar = new GVar(preLabel, var);
                     String name = gVar.getFlatName();
                     return valOf.get(name);
                  }

                  public Integer visit(Val val) {
                     return Integer.valueOf(val.intLiteral.lexeme);
                  }
               };
               return varl.accept(visitor);
            }
         }
      );
   }

   // --------------------------------------------------------------------------------
}


