package speclang.spec2smt2;

import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import lesani.collection.option.Option;
import lesani.collection.option.None;
import speclang.spec.ast.tree.statement.If;
import speclang.spec.ast.tree.statement.Statement;
import speclang.spec.ast.visitor.SVisitor;

import java.util.Set;

public class IfNode extends GNode {
   public If theIf;
   public Set<GNode> nesteds;
   public Option<ElseNode> elseNode = None.instance();

   public IfNode(If theIf, int tId, int indent) {
      super(tId, indent);
      this.theIf = theIf;
   }

//   public Statement getStatement() {
//      return theIf;
//   }

   public boolean isExec() {
      for (GNode nested : nesteds) {
         if (!(nested instanceof MathOpNode) && nested.isExec())
            return true;
      }
      return elseNode.apply(
         new Fun0<Boolean>() {
            public Boolean apply() {
               return false;
            }
         },
         new Fun<ElseNode, Boolean>() {
            public Boolean apply(ElseNode theElseNode) {
               return theElseNode.isExec();
            }
         }
      );
   }

   @Override
   public String getLabel() {
      return getLabel(theIf);
   }

   @Override
   public String toString() {
      String s = printFlatLabel();
      for (int i = 0; i < level *3; i++) {
         s += " ";
      }
      ExpPrinter printer = new ExpPrinter(preLabel);
      String condString = printer.visitDistch(theIf.condition);
      return s + "if " + "(" + condString + ")";
   }
}
