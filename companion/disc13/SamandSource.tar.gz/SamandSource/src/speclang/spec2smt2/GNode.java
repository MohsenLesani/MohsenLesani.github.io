package speclang.spec2smt2;

import lesani.collection.func.Fun;
import lesani.collection.func.Fun0;
import speclang.spec.ast.tree.declaration.Label;
import speclang.spec.ast.tree.statement.Statement;

import java.util.HashSet;
import java.util.Set;

public abstract class GNode {
   public int tId;
   public int level;
   public boolean exec = false;
   public String preLabel = "";
   public GNode parent;
   public Set<ReturnNode> precReturns;

   //public List<GNode> dependeds;

   public GNode(int tId, int level) {
      this.tId = tId;
      this.level = level;
      //dependeds = new LinkedList<GNode>();
   }

//   public void addDepended(GNode node) {
//      dependeds.add(node);
//   }
   public boolean isExec() {
      // exec is set for nodes that are put into the z3 file.
      // For the rest, isExec is decided according to the rest.
      return exec;
   }

   public static String getLabel(final Statement statement) {
      return statement.label.apply(
         new Fun0<String>() {
            public String apply() {
               throw new RuntimeException(
                  "Explicit Labels needed for statement " + statement.getLoc());
            }
         },
         new Fun<Label, String>() {
            public String apply(Label label) {
               return label.id.name;
            }
         }
      );

   }

   public String printFlatLabel() {
      String label = getFlatLabel();
      String s = label.equals("") ? (" ") : (label + ">");
      for (int i = 0; i < 14-label.length(); i++) {
         s += " ";
      }
      return s;
   }

   public abstract String getLabel();

   public String getFlatLabel() {
      String name = getLabel();
      return (preLabel.equals("") || name.equals("")) ? name : preLabel + "." + name;

/*
      final Statement statement = getStatement();
      return statement.label.apply(
         new Fun0<String>() {
            public String apply() {
               throw new RuntimeException(
                  "Explicit Labels needed for statement " + statement.getLoc());
            }
         },
         new Fun<Label, String>() {
            public String apply(Label label) {
               String name = label.id.name;
               return (preLabel.equals("")) ? name : preLabel + "." + name;
            }
         }
      );
*/
   }

   public void setPrecReturns(HashSet<ReturnNode> returnNodes) {
      precReturns = returnNodes;
   }

//   public abstract String print(Map<String, Integer> valOf);
}

