package test

object Tester {
  def main(args: Array[String]) {
    println("Hello, world")
  }
}
