module Char   = ExtChar.Char
module String = ExtString.String
module List   = ExtList.List
module Array  = ExtArray.Array

open Fun
